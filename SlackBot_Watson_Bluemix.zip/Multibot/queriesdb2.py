import ibm_db
import ibm_db_dbi
import pandas as pd

def insert_row(INTENT, ENTITY, AREA, PROJECT, ID, SQL, conn):
	
	cadena = "INSERT INTO POWERBOT.QUERIES  VALUES ('" + INTENT + "','" + ENTITY + "','" + AREA + "', " + str(ID) 
	cadena +=  " ,'" + SQL + "')"
	#print (cadena)
	ibm_db.exec_immediate(conn,cadena)


def delete_all():
	conn = ibm_db.pconnect("DATABASE=BLUDB;HOSTNAME=dashdb-txnha-small-yp-dal10-06.services.dal.bluemix.net;PORT=50000;PROTOCOL=TCPIP;UID=chatbot;PWD=Daniela16Manuel.;","","")
	ibm_db.exec_immediate(conn,"DELETE  FROM POWERBOT.QUERIES WHERE ID != 0")

#def delete_all(INTENT, ENTITY, AREA, PROJECT, conn):
#	conn = ibm_db.pconnect("DATABASE=BLUDB;HOSTNAME=dashdb-txnha-small-yp-dal10-06.services.dal.bluemix.net;PORT=50000;PROTOCOL=TCPIP;UID=chatbot;PWD=Daniela16Manuel.;","","")
#	ibm_db.exec_immediate(conn,"DELETE  FROM POWERBOT.QUERIES WHERE ID != 0")

def Data_DB2(SQL):
  conn = ibm_db.pconnect("DATABASE=BLUDB;HOSTNAME=dashdb-txnha-small-yp-dal10-06.services.dal.bluemix.net;PORT=50000;PROTOCOL=TCPIP;UID=chatbot;PWD=Daniela16Manuel.;","","")
  conni = ibm_db_dbi.Connection(conn)
  df = pd.read_sql(SQL, conni)
  return df

file = pd.read_csv('Queries2.csv',header=0)
print (file)
categories = file
categories = categories.drop(['ID', 'SQL'], axis = 1)
categories = categories.groupby(['INTENT', 'ENTITY', 'AREA', 'PROJECT']).size().to_frame('QTY').reset_index()
categories = categories.sort_values(by=['PROJECT', 'AREA'])
categories = categories.reset_index()
categories = categories.drop('index', axis=1)
print (categories)

for index, i  in categories.iterrows():
	print (index)
	print (i)


df = Data_DB2("SELECT * FROM POWERBOT.QUERIES")
if df.shape	[0] > 0:
	delete_all()
print (df)


file = pd.read_csv('Queries2.csv',header=0)
conn = ibm_db.pconnect("DATABASE=BLUDB;HOSTNAME=dashdb-txnha-small-yp-dal10-06.services.dal.bluemix.net;PORT=50000;PROTOCOL=TCPIP;UID=chatbot;PWD=Daniela16Manuel.;","","")
#print (file)
for index, i  in file.iterrows():
	SQL = "SELECT * FROM POWERBOT.QUERIES WHERE INTENT = '" + i['INTENT'] + "' AND ENTITY = '" + i['ENTITY'] + "' AND AREA = '" + i['AREA'] +  "' AND PROJECT = '" + i['PROJECT'] + "' AND ID = " + str(i['ID']) 
	print (str(index) + "/" + str(file.shape[0]))
	#if Data_DB2(SQL).shape[0] == 0:
		#print ("No se encontro registro")
	insert_row (i['INTENT'], i['ENTITY'], i['AREA'], i['PROJECT'], i['ID'],i['SQL'], conn )

	#print (i['INTENT'])
#ibm_db.exec_immediate(conn,"INSERT INTO powerbot.queries  VALUES ('ESTATUS','GENERAL','TEST', '1','CASE ')")
#CREATE SCHEMA INVENTRY
#create_tables()