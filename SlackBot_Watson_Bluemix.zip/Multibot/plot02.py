import random
import time
import threading
import matplotlib.pyplot as plt

lock = threading.Lock()




if __name__ == '__main__':
    class Plot:

        def __init__(self):
            lock.acquire()
            plt.ion()
            plt.show()
            lock.release()
            self.start = time.time()
            self.xdata = []
            self.ydata = []
            self.running = None
            self.axis = plt.figure().add_subplot(111)
            self.line, = self.axis.plot([])
            threading.Thread(target=self.worker).start()
            
        def worker(self):
            for _ in range(50):
                self.xdata.append(len(self.xdata))
                self.ydata.append(random.random())
                lock.acquire()
                self.axis.set_xlim(0, len(self.xdata))
                lock.release()
                self.axis.set_ylim(0, max(self.ydata))
                self.line.set_data(self.xdata, self.ydata)
                time.sleep(0.1)
            print(time.time() - self.start)
    
    plot1 = Plot()
    #plot1 = Plot()