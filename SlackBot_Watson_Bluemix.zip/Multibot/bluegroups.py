import requests
from xml.etree import ElementTree

requestURL = 'https://bluepages.ibm.com/tools/groups/groupsxml.wss?task=inAGroup&email=manuelar@mx1.ibm.com&group=powerbot_power_test'
#print (requestURL)

response = requests.get(requestURL)
#print (response.content)
tree = ElementTree.fromstring(response.content)
#print (tree.iter('group').text())
for child in tree.iter('*'):
    if child.tag == 'rc':
    	if child.text == '0':
    		print ("El usuario pertenece al grupo")
    	else:
    		print ("El usuario no pertenece al grupo")
    	