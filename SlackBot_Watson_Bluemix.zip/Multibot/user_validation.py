import requests
from xml.etree import ElementTree
import pandas as pd
import csv_data as cd
def validate_bg(Bot):
	print (Bot.Name + ": I'm validating user")
	Groups = cd.Read_BG_Could (Bot)
	#print (Groups)
	
	for Group in Groups['BLUEGROUP']:
		requestURL = 'https://bluepages.ibm.com/tools/groups/groupsxml.wss?task=inAGroup&email=' + Bot.Email + '&group=' + Group
		#print (requestURL)
		response = requests.get(requestURL)
		tree = ElementTree.fromstring(response.content)
		
		for root in tree.iter('*'):
		    if root.tag == 'rc':
		    	if root.text == '0':
		    		#print ("El usuario pertenece al grupo")
		    		return True
		    	#else:
		    		#print ("El usuario no pertenece al grupo")
		 

	return False
