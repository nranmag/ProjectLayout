import datetime
import pytz
horau = datetime.datetime.utcnow()
print(horau)
tz = pytz.timezone('America/Mexico_City')
hora = tz.localize(horau)
hora = hora.astimezone(tz)
print(hora)

"""
utc_now = pytz.utc.localize(datetime.datetime.utcnow())
pst_now = utc_now.astimezone(pytz.timezone("America/Mexico_City"))

print (utc_now)
print (pst_now)

diff = utc_now != pst_now
print (diff)
""
#diff = hora - horau
"""
diff = str(hora).replace(str(horau), '')
print (diff.split(':')[0])
diff = int(diff.split(':')[0])
diff *= -1
print (diff)
#diff = horau - hora
#print (diff)
