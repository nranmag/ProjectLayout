SQL = "INSERT INTO POWERBOT.QUERIES  VALUES ('ESTATUS','GENERAL','TEST', 5 ,'WHEN (physical.wunmbr = ¬0970¬) THEN ¬COMPLETED¬ WHEN (physical.wunmbr = ¬0850¬) THEN ¬COMPLETED¬ WHEN (physical.wunmbr = ¬VI20¬) THEN ¬COMPLETED¬ WHEN (physical.wunmbr = ¬VI25¬) THEN ¬COMPLETED¬  WHEN (physical.wunmbr = ¬QIAF¬) THEN ¬COMPLETED¬ ')"
print (SQL)
print (len(SQL))