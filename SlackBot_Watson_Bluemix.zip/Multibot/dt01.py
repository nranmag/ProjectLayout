#import ibm_db
#import ibm_db_dbi
import pandas as pd
import pyodbc
import matplotlib.pyplot as plt

from pandas.tools.plotting import scatter_matrix

def Data_DB2(SQL):
	cnxn = pyodbc.connect("DSN=QRYPROD;Database=QRYPROD;UID=manuelare;PWD=zaq12wsx")
	df = pd.read_sql(SQL,cnxn)
	return df


#SQL = ""
#SQL = "SELECT TSMFGN, TSMCTL, TSNMBR, TSSTEP, TSELAP  FROM MFS2P010G.FCSPTS10 WHERE TSMCTL IN (SELECT WUMCTL FROM MFS2P010G.FCSPWU10 INNER JOIN MFS2P010G.FCSPOR10 ON ORORNO = WUWORN WHERE WUWTYP = 'X' AND ORMATP IN ('8286', '8284') ) AND TSEPNM = '' AND TSRCD1 = 'PASS' AND TSSTEP = 'A100'"
SQL = "SELECT TSMFGN, TSMCTL, MODEL.ORMATP, MODEL.ORMMDL, TSNMBR, TSSTEP, TSELAP  FROM MFS2P010G.FCSPTS10 INNER JOIN (SELECT ORMATP, ORMMDL,  WUMCTL FROM MFS2P010G.FCSPWU10 "
SQL += "INNER JOIN MFS2P010G.FCSPOR10 ON ORORNO = WUWORN WHERE WUWTYP = 'X' AND ORMATP IN ('8286', '8284') ) MODEL ON TSMCTL = MODEL.WUMCTL WHERE TSMCTL IN "
SQL += "(SELECT WUMCTL FROM MFS2P010G.FCSPWU10 INNER JOIN MFS2P010G.FCSPOR10 ON ORORNO = WUWORN WHERE WUWTYP = 'X' AND ORMATP IN ('8286', '8284') " 
SQL += ") AND TSEPNM = '' AND TSRCD1 = 'PASS' AND TSSTEP = 'A100' AND TSNMBR = 'T111' "
SQL += " FETCH FIRST 100 ROWS ONLY"
df = Data_DB2(SQL)
#print (df)
#df2 = df['ORMATP', 'ORMMDL']
#print (df['ORMATP', 'ORMMDL'])
print (pd.get_dummies(df, dummy_na=False, columns=['ORMATP', 'ORMMDL']))
#print (df.describe())
df2 = pd.get_dummies(df, dummy_na=False, columns=['ORMATP', 'ORMMDL'])
#df2 = df2.drop(['ORMATP_8286'], axis = 1)
#df2 = df2.drop(['ORMMDL_22A'], axis = 1)

scatter_matrix(df2, figsize=(10,10))

#df.info()
plt.show()