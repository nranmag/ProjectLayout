from time import sleep

print("Hola 01")

sleep(5)
#input("Esperando...")