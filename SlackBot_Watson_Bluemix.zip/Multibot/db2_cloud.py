import ibm_db
import ibm_db_dbi
import pandas as pd
#conn = ibm_db.pconnect("DATABASE=BLUDB;HOSTNAME=dashdb-txnha-small-yp-dal10-06.services.dal.bluemix.net;PORT=50000;PROTOCOL=TCPIP;UID=****;PWD=******;","","")
conn = ibm_db.pconnect("DATABASE=BLUDB;HOSTNAME=dashdb-txnha-small-yp-dal10-06.services.dal.bluemix.net;PORT=50000;PROTOCOL=TCPIP;UID=chatbot;PWD=Daniela16Manuel.;","","")

def connection():    
   #if conn:
       #return json.dumps({'message': 'Connection success'})
  #return conn
   #else:
       #return json.dumps({'message': 'Error Connection'})
  
  ibm_db.exec_immediate(conn, "SET SCHEMA = CLEAN")
   #ibm_db.exec_immediate(conn, "SET SCHEMA = CLEAN")
   #ibm_db.exec_immediate(conn,"CREATE SCHEMA Clean")





def create_tables():
   ibm_db.exec_immediate(conn,"CREATE TABLE IF NOT EXIST POWERBOT.USER (NAME VARCHAR(30) NOT NULL,USER VARCHAR(20) NOT NULL, EMPLOYEE_NUM VARCHAR(10) NOT NULL PRIMARY KEY, MANAGER VARCHAR(30) NOT NULL, DEPT_ID INT NOT NULL REFERENCES AREAS (DEPT_ID), QR_TEXT VARCHAR(30))")
   #ibm_db.exec_immediate(conn,"CREATE TABLE IF NOT EXIST Clean.CHECK (CHECK_ID INT NOT NULL PRIMARY KEY, DATE DATE, VACATIONS INT, USER_TO_CHECK VARCHAR(20), DRAWERS INT, ENERGY INT, PAPERS INT, EMPLOYEE_NUM VARCHAR(10) NOT NULL REFERENCES USER (EMPLOYEE_NUM), POS INT)")
   #ibm_db.exec_immediate(conn,"CREATE TABLE IF NOT EXIST Clean.VACATIONS (VACATIONS_ID INT NOT NULL PRIMARY KEY, START_DATE DATE, END_DATE DATE, EMPLOYEE_NUM INT NOT NULL REFRENCES USER (EMPLOYEE_NUM))")
   #ibm_db.exec_immediate(conn,"CREATE TABLE IF NOT EXIST CLEAN.AREAS (DEPT_ID INTEGER NOT NULL, LOCATION VARCHAR(20) NOT NULL, NAME VARCHAR(20) NOT NULL, PRIMARY KEY DEPT_ID)")

def insert_user():
   ibm_db.exec_immediate(conn,"INSERT INTO Clean.USER  VALUES ('AYRTON','ayrtonm','053243', 'MOISES','5','12345678')")

def modify_user():
   ibm_db.exec_immediate(conn,"UPDATE INTO Clean.USER  VALUES ('AYRTON','ayrtonm','053243', 'MOISES','5','12345678')")

def delete(ID):
   ibm_db.exec_immediate(conn,"DELETE  FROM USER WHERE EMPLOYEE_NUM =%s", ID)

def Data_DB2(SQL):
  conn = ibm_db.pconnect("DATABASE=BLUDB;HOSTNAME=dashdb-txnha-small-yp-dal10-06.services.dal.bluemix.net;PORT=50000;PROTOCOL=TCPIP;UID=chatbot;PWD=Daniela16Manuel.;","","")
  #conn = ibm_db.connect("DSN=QUALITY9;Database=QUALITY9;UID=flame01;PWD=flmdev.db2",'', '')
  conni = ibm_db_dbi.Connection(conn)
  df = pd.read_sql(SQL, conni)
  return df

conn = ibm_db.pconnect("DATABASE=BLUDB;HOSTNAME=dashdb-txnha-small-yp-dal10-06.services.dal.bluemix.net;PORT=50000;PROTOCOL=TCPIP;UID=chatbot;PWD=Daniela16Manuel.;","","")
print (conn)
df = Data_DB2("SELECT * FROM POWERBOT.QUERIES")
print (df)
#ibm_db.exec_immediate(conn,"INSERT INTO powerbot.queries  VALUES ('ESTATUS','GENERAL','TEST', '1','CASE ')")
#CREATE SCHEMA INVENTRY
#create_tables()