from datetime import datetime
import time
print (datetime.strptime("5:00:00", "%H:%M:%S"))
print (time.tzname)
print (datetime.now())
print (datetime.utcnow())

print ( datetime.utcnow() - datetime.now())
print ( datetime.utcnow() - datetime.utcnow())

