import random
import time
import threading
#import matplotlib.pyplot as plt
import pylab as plt
from datetime import datetime, timedelta


lock = threading.Lock()

class Plot(threading.Thread):

    def __init__(self, threadID, Name):
        threading.Thread.__init__(self)
        
        self.threadID = threadID
        self.Name = Name
        self.xdata = []
        self.ydata = []
        self.running = None
        self.axis = plt.figure().add_subplot(111)
        self.line, = self.axis.plot([])

    def start(self):
        lock.acquire()
        plt.ion()
        plt.show()
        lock.release()
        self.running = True
        threading.Thread(target=self.worker).start()
        while self.running:
            lock.acquire()
            self.axis.set_xlim(0, len(self.xdata))
            self.axis.set_ylim(0, max(self.ydata))
            self.line.set_data(self.xdata, self.ydata)
            
            #plt.draw()
            #plt.pause(0.001)
            print (self.Name)
            plt.savefig(self.Name+'.png')
            lock.release()
            time.sleep(1)


    def worker(self):
        for _ in range(50):
            self.xdata.append(len(self.xdata))
            self.ydata.append(random.random())
            time.sleep(0.1)
        self.running = False
        


if __name__ == '__main__':
    start = time.time()
    now = datetime.now()
    #lock.acquire()
    plot1 = Plot(1, "Hilo1").start()
    plot2 = Plot(1, "Hilo2").start()
    #plot3 = Plot(3, "Hilo3").start()
    
    #plot1.start()
    #plot2.start()
    #plot3.start()    
    #Thread.append (PowerBot(1, "PowerBot_" + str(now.year) + "_" + str(now.month) + "_" + str(now.day) + "_" + str(now.hour) + "_" + str(now.minute) + "_" + str(now.second) + "_" + str(now.microsecond), command,channel, real_name)) 
    #Thread[len(Thread) -1].start()
    print(time.time() - start)