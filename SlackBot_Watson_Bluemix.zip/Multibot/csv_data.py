import pandas as pd
import numpy as np

import ibm_db
import ibm_db_dbi

import requests
import urllib3
import io

import sys
import datetime



pd.options.mode.chained_assignment = None 
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

def Data_DB2(SQL, Bot):
	print (Bot.Name + ": I'm executing SQL string")
	sys.stdout.flush()
	#dsn = cf_misc.get_credentials('QUALITY9')['dsn']
	#print(dsn)
	#conn = ibm_db.connect(dsn, '', '')
	conn = ibm_db.connect("DSN=QUALITY9;Database=QUALITY9;UID=flame01;PWD=flmdev.db2",'', '')
	conni = ibm_db_dbi.Connection(conn)
	df = pd.read_sql(SQL, conni)
	#df = df.replace('°',"'")

	#df.to_csv("DB2.csv")
	#print (df)
	return df

def Read_SQL_Could(Intent,Entity,Area, Bot):
	print (Bot.Name + ": I'm reading SQL string from DB2 Cloud")
	sys.stdout.flush()
	#dsn = cf_misc.get_credentials('BLUDB')['dsn']
	#print(dsn)
	#conn = ibm_db.connect(dsn, '', '')
	conn = ibm_db.connect("DATABASE=BLUDB;HOSTNAME=dashdb-txnha-small-yp-dal10-06.services.dal.bluemix.net;PORT=50000;PROTOCOL=TCPIP;UID=chatbot;PWD=Daniela16Manuel.;","","")
	conni = ibm_db_dbi.Connection(conn)
	SQL = "SELECT * FROM POWERBOT.QUERIES WHERE INTENT = '" + Intent + "' AND ENTITY = '" + Entity + "' AND AREA = '" + Area + "' "
	#SQL = ""
	#print (SQL)
	df = pd.read_sql(SQL, conni)
	df = df['SQL'].str.replace('^',"'")
	#print (df)
	SQL = ''
	for x in df[:]:
		SQL += x
	
	#print (SQL)
	return SQL

def Read_BG_Could(Bot):
	print (Bot.Name + ": I'm reading Bluegroups from DB2 Cloud")
	sys.stdout.flush()
	#dsn = cf_misc.get_credentials('BLUDB')['dsn']
	#print(dsn)
	#conn = ibm_db.connect(dsn, '', '')
	conn = ibm_db.connect("DATABASE=BLUDB;HOSTNAME=dashdb-txnha-small-yp-dal10-06.services.dal.bluemix.net;PORT=50000;PROTOCOL=TCPIP;UID=chatbot;PWD=Daniela16Manuel.;","","")
	conni = ibm_db_dbi.Connection(conn)
	#print (Bot.Intent)
	#	print (Bot.Area)
	SQL = "SELECT * FROM POWERBOT.BLUEGROUPS WHERE INTENT = '" + Bot.Intent[0] +  "' AND AREA = '" + Bot.Area[0] + "' "
	#SQL = ""
	#print (SQL)
	df = pd.read_sql(SQL, conni)
	return df


def Read_SQL(Intent,Entity,Area, Bot):
	print (Bot.Name + ": I'm reading SQL string")
	sys.stdout.flush()
	df = pd.read_csv('Queries.csv',header=0)#, names = ['MFGN', 'Order', 'Model', 'MT', 'PRLN', 'Cell', 'Status', 'OP', 'STEP', 'PROGRAM', 'P', 'TC', 'CEC', 'Ship date', 'Country', 'tco', 'ettc', 'ettc date'])
	
	df = Filter_Data(df, ['INTENT', 'ENTITY', 'AREA'], [[Intent],[Entity],[Area]], Bot)
	df = df.sort_values('ID', ascending=True)
	SQL = ""
	for x in df['SQL']:
		SQL += x
	#print (SQL)
	return SQL

def Create_List_DB2(Name, Systems, Bot):
	"""
	Create a list with the interest systems
	"""
	print (Bot.Name + ": I'm creating a list on DB2")
	sys.stdout.flush()
	#dsn = cf_misc.get_credentials('BLUDB')['dsn']
	#print(dsn)
	#conn = ibm_db.connect(dsn, '', '')
	conn = ibm_db.pconnect("DATABASE=BLUDB;HOSTNAME=dashdb-txnha-small-yp-dal10-06.services.dal.bluemix.net;PORT=50000;PROTOCOL=TCPIP;UID=chatbot;PWD=Daniela16Manuel.;","","")
	ibm_db.exec_immediate(conn,"DELETE  FROM POWERBOT.LIST WHERE NAME = '" + Name + "'")
	#print (str(int(time.time())))
	for x in Systems:
		cadena = "INSERT INTO POWERBOT.LIST  VALUES ('" + Name + "','" + x.upper() + "','" + str(datetime.datetime.utcnow()) + "')"
		#print (cadena)
		ibm_db.exec_immediate(conn,cadena)
	
	file = open(Name.lower() + ".bot","w") 
	[file.write(x.upper()+"\n") for x in Systems]
	file.close()
	return True

def Read_List_DB2(Name, Bot):
	"""
	Read a file list and return a list with the systems inside 
	"""
	print (Bot.Name + ": I'm reading a list")
	sys.stdout.flush()
	conn = ibm_db.pconnect("DATABASE=BLUDB;HOSTNAME=dashdb-txnha-small-yp-dal10-06.services.dal.bluemix.net;PORT=50000;PROTOCOL=TCPIP;UID=chatbot;PWD=Daniela16Manuel.;","","")
	conni = ibm_db_dbi.Connection(conn)
	SQL = "SELECT * FROM POWERBOT.LIST WHERE NAME = '" + Name + "'"
	df = pd.read_sql(SQL, conni)
	systems =list(df['MFGN'])
	
	if len(systems) > 0: 
		for index, x in df.iterrows():
			SQL = "UPDATE POWERBOT.LIST SET NAME = '" + x['NAME'] + "', MFGN = '" + x['MFGN'].upper() + "', LAST = '" + str(datetime.datetime.utcnow()) + "' WHERE NAME = '" + x['NAME'] + "' AND MFGN = '" + x['MFGN'].upper() + "'"
			#print (SQL)
			ibm_db.exec_immediate(conn,SQL)
	
		return systems 
	else:
		return False

def Data_Vcc(Save):
	"""
	Get all the data from VCC web
	"""

	#url = "https://cio-sg-02.integration.ibmcloud.com:15370/~vccuser/prod/csv/ettc_GDA.csv"
	url = "https://rchdist.rch.stglabs.ibm.com/~vccuser/prod/csv/ettc_GDA.csv"

	html = requests.get(url, verify=False).content
	df_list = pd.read_csv(io.StringIO(html.decode('utf-8')), error_bad_lines=False, header=None, names = ['MFGN', 'Order', 'Model', 'MT', 'PRLN', 'Cell', 'Status', 'OP', 'STEP', 'PROGRAM', 'P', 'TC', 'CEC', 'Ship date', 'Country', 'tco', 'ettc', 'ettc date'])
	df = df_list[2:]
	
	if Save == True:
		df.to_csv('data_tool.csv')
	
	df.fillna("")
	return df

def Add_Hold_Info(df, Bot):
	print (Bot.Name + ": I'm adding Hold info")
	sys.stdout.flush()
	df.insert(21, 'Owner', "")
	df.insert(22, 'Time', "")
	#df.loc[df[ColsF[x]].isin(ValsF[x])]
	#for index, i in df.iterrows():
	#print (df[df['Status']=='HOLD      '])
	for index, i in df[df['Status']=='HOLD      '].iterrows():
		SQL = Read_SQL("BOT","HOLD", "TEST", Bot)
		SQL = SQL.replace('#1#', "'" + i['Order'] + "'")
		SQL = SQL.replace('#2#', "'" + i['MFG #'] + "'")
		#print (i['Order'])
		#print (i['MFG #'])
		
		hold_info = Data_DB2(SQL, Bot)
		hold_info =hold_info.drop(['PRMCTL', 'PRPRDT', 'PRPRTM', 'USER'], 1) 
		#print(index)
		#print (hold_info['OUSER'])
		#print (len(hold_info['OUSER']))
		if len(hold_info['OUSER']) > 0:
			df['Owner'][index] = hold_info['OUSER'][0].strip()
			df['Time'][index] = hold_info['TIME'][0].strip()
			#print ("'" + hold_info['COMMENT'][0].strip() + "'")
			#print (len(hold_info['COMMENT'][0].strip()))
			df['ETTC'][index] = hold_info['COMMENT'][0].strip()[:25]
			#df['Owner'][i] = hold_info['OUSER'][0]
			#print (hold_info)
		else:
			df['Owner'][index] = ""
			df['Time'][index] = ""
			df['ETTC'][index] = ""
			#print (hold_info)
		#print (SQL)
	return df 

def Add_VCC (df, Bot):
	print (Bot.Name + ": I'm adding VCC data")
	sys.stdout.flush()
	
	df_vcc = Data_Vcc(False)
	
	MfgnL = []
	MfgnL = df_vcc[['MFGN','Order']]
	
	for index, i in MfgnL.iterrows():
		for j in df.index[(df['MFG #'] == i['MFGN']) & (df['Order'] == i['Order'])]:
			#if j 
			df['Preload'][j] = str(df_vcc.loc[df_vcc['MFGN'].isin([i['MFGN']]) & df_vcc['Order'].isin([i['Order']])]['P'].values)[2:-2]
			df['Status'][j] = str(df_vcc.loc[df_vcc['MFGN'].isin([i['MFGN']]) & df_vcc['Order'].isin([i['Order']])]['Status'].values)[2:-2]
			df['Step'][j] = str(df_vcc.loc[df_vcc['MFGN'].isin([i['MFGN']]) & df_vcc['Order'].isin([i['Order']])]['STEP'].values)[2:-2]
			df['TCO'][j] = str(df_vcc.loc[df_vcc['MFGN'].isin([i['MFGN']]) & df_vcc['Order'].isin([i['Order']])]['tco'].values)[2:-2]
			df['ETTC'][j] = str(df_vcc.loc[df_vcc['MFGN'].isin([i['MFGN']]) & df_vcc['Order'].isin([i['Order']])]['ettc date'].values)[2:-2]
			if df['ETTC'][j] == 'a':
				df['ETTC'][j] = ""
			
	return df

def Filter_Data(df, ColsF, ValsF, Bot):
	print (Bot.Name + ": I'm filtering the data")
	sys.stdout.flush()
	if len(ColsF) > 0:
		for x in range(len(ColsF)):
			df = df.loc[df[ColsF[x]].isin(ValsF[x])] 
	sys.stdout.flush()
	return df 

def Remove_Yorders(df):
	df = df[df['Order'].str.startswith("Y")==False]
	return df

def Remove_IPRorders(df):
	df = df[df['Order'].str.startswith("$")==False]
	return df

def Summary(df, Bot):
	print (Bot.Name + ": I'm creating a summary data frame")
	sys.stdout.flush()
	#print (df.shape[0])
	df.drop_duplicates(subset=['MFG #'], keep='first', inplace=True)
	#print (df.shape[0])
	#print (df)
	df = Status_Checker(df)
	#df['Revenue'] = df['Revenue'].apply(lambda x: 0 if x == '' or x == 'NaN' or np.isnan(x) else x)
	df['Revenue'] = df['Revenue'].apply(lambda x: 0 if x == '' or x == 'NaN' else x)
	df.fillna(0)
	#df['Revenue'] = df['Revenue'].astype(int)
	df['Revenue'] = df['Revenue'].astype(float)
	#df = Filter_Data(df, ['Status'], [['HOLD', 'REWORK', 'COMPLETED', 'RUNNING', "DOWN"]], Bot)
	df = df.groupby(['Status'])['Revenue', 'MFG #'].agg(['sum', 'count'])
	df = df.drop(columns=[('Revenue', 'count'), ('MFG #', 'sum')])

	df.columns = ['Revenue', 'Systems']

	basic_status = ['COMPLETED', 'DOWN      ', 'HOLD      ','REWORK    ','RUNNING   ']#Tentativo

	for i in basic_status:
		if i not in df.index.values:
			df.loc[i] = [0,0]  

	total = df.apply(np.sum)
	df.loc['TOTAL'] = [total['Revenue'], total['Systems']]
	df['Systems'] = df['Systems'].astype(int)
	
	return df

def Status_Checker(df):
	X = 0
	Y = 0
	Width= []
	
	for i in df:
		for j in df[i]: 
			if i == 'Status':
				if j == 'QUAL_ENG':
					df[i][df.index[df[i] == j].tolist()] = 'HOLD      '
				elif j == 'ABORT': 
					df[i][df.index[df[i] == j].tolist()] = 'REWORK    '
				elif j == 'ATTENTION' or j == 'ATTN' or j == 'PASS':
					if df.iat[Y,X+1] == 'TVAL':
						df.iat[Y,X] = 'COMPLETED'
					else:
						df.iat[Y,X] = 'RUNNING   '
				elif j == 'START' or j == 'PASS':
					df.iat[Y,X] = 'RUNNING   '
				
			Y += 1
		Y = 0
		X += 1

	return df


#print (Read_SQL_Could("ESTATUS", "GENERAL", "TEST",  ""))

#df = Data_Vcc(False)
#print (df)
#SQL=Read_SQL("ESTATUS","GENERAL")
#df = Data_DB2(SQL)

#df = Add_VCC(df, False)
#print (df)
#df.to_csv("DB2.csv")
"""
sql = "select distinct physical.wumfgn, physical.wuschd, physical.wuworn, geo, custname, ctry, rev, est, commit, firm, ettc, commentc, ormatp, ormmdl, orsysn, physical.wunmbr, physical.wuopst, physical.wutwrc, test.wucell, test.wunmbr, test.wuprln "
sql += "from qryq.MFSGWU10_GRC physical "
sql += "left join qryq.MFSGOR10_GRC on physical.wumfgn = ormfgn and physical.wuworn = ororno "
sql += "left join idmq.siidmtool_IDMOUT1970_urc on physical.wumfgn = mfgn and physical.wuworn = orno "
sql += "left join qryq.MFSGWU10_GRC test on physical.wumfgn = test.wumfgn and ororno = test.wuworn and test.wuwtyp = 'X' "
sql += "where physical.wuwtyp = 'R'"
sql += "and physical.wuidss in ('0000','IPRC') "
sql += "and physical.wunmbr = 'TEST' "
sql += "and orceci = 'Y' "
df = Data_DB2(sql)


print(df)
df.to_csv("DB2.csv")
"""