import os
#os.environ['POWERBOTTOKEN'] = "xoxb-267672714900-JTqqAcHQpYY51HoRlsOP6UBs"
#print (os.environ['POWERBOTTOKEN'])
#os.environ['POWERBOTNAME'] = 'qrytestbot'
print (os.environ['POWERBOTNAME'])

