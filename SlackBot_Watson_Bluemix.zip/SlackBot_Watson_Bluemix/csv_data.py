import requests
import pandas as pd
import numpy as np
import urllib3
import sys
import os
import pyodbc

pd.options.mode.chained_assignment = None 

def Data_DB2(SQL):
	cnxn = pyodbc.connect("DSN=QRYPROD;Database=QRYPROD;UID=manuelare;PWD=zaq12wsx")
	 
	print("Espera")
	df = pd.read_sql(SQL,cnxn)
	#lista = ['WUMFGN', 'WUPROD']
	return df
	#print(df)


def Data_Tool_All(Save):
	#print ("Ejecutando Data_Tool...")
	#http://maunaloa.rchland.ibm.com//SIIDMQMF/970boxbldydet.htm 	Nom_Build
	#http://maunaloa.rchland.ibm.com//SIIDMQMF/970boxbldndet.htm 	Nom_DNB
	#http://maunaloa.rchland.ibm.com//SIIDMQMF/970boxnnomdet.htm 	Not_Nom 
	#http://maunaloa.rchland.ibm.com//SIIDMQMF/970boxkblddet.htm 	450, 500, 600
	#http://maunaloa.rchland.ibm.com//SIIDMQMF/970boxcccdet.htm 	850
	#http://maunaloa.rchland.ibm.com//SIIDMQMF/970boxcladet.htm 	970
	

	urls = []
	urls.append('http://maunaloa.rchland.ibm.com//SIIDMQMF/970boxbldydet.htm')
	urls.append('http://maunaloa.rchland.ibm.com//SIIDMQMF/970boxbldndet.htm')
	urls.append('http://maunaloa.rchland.ibm.com//SIIDMQMF/970boxnnomdet.htm')
	urls.append('http://maunaloa.rchland.ibm.com//SIIDMQMF/970boxkblddet.htm')
	urls.append('http://maunaloa.rchland.ibm.com//SIIDMQMF/970boxcccdet.htm')
	urls.append('http://maunaloa.rchland.ibm.com//SIIDMQMF/970boxcladet.htm')

	#General = pd.concat([General,Complete], axis=0)
	print (urls)
	All = pd.DataFrame()
	for i in urls:
		#print(i)
		html = requests.get(i).content
		df_list = pd.read_html(html, header=0)
		df = df_list[-1]
		df = df.drop(['Class.1', 'Firm.1', 'MFGN.1', 'Est.1', 'Rev.1'], 1)
		All = pd.concat([All,df], axis=0)	

	All = All.fillna("")
	#print (All)

	if Save == True:
		All.to_csv('data_tool.csv')
	
	return All

def Data_Tool(Save):
	print ("Ejecutando Data_Tool...")
	
	url = 'http://maunaloa.rchland.ibm.com//SIIDMQMF/970boxtstdet.htm'
	html = requests.get(url).content
	
	df_list = pd.read_html(html, header=0)
	df = df_list[-1]
	df = df.drop(['Class.1', 'Firm.1', 'MFGN.1', 'Est.1', 'Rev.1'], 1)
	

	if Save == True:
		df.to_csv('data_tool.csv')
	df.fillna("")
	return df

def Data_Vcc(Save):
	print ("Ejecutando Data_Vcc...")
	
	url = "https://rchdist.rch.stglabs.ibm.com/~vccuser/prod/csv/ettc_GDA.csv"
	http = urllib3.PoolManager()
	r = http.request('GET', url, preload_content=False)
	
	with open("data_vcc.csv", 'wb') as out:
		while True:
			data = r.read()
			if not data:
				break
			out.write(data)
	
	r.release_conn()

	df = pd.read_csv('data_vcc.csv',header=None, names = ['MFGN', 'Order', 'Model', 'MT', 'PRLN', 'Cell', 'Status', 'OP', 'STEP', 'PROGRAM', 'P', 'TC', 'CEC', 'Ship date', 'Country', 'tco', 'ettc', 'ettc date'])
	df = df[:][2:]
	
	if Save == False:
		os.remove('data_vcc.csv')
	df.fillna("")
	return df

def Data_Tool_General(Save,Btool):
	Vcc = Data_Vcc(True)
	Tool = Data_Tool(True)
	Vcc.fillna("")
	Tool.fillna("")
	if Btool == True:
		Systems = Tool['MFGN'].tolist() 
		Vcc = Filter_Data(Vcc, ['MFGN'], [Systems])
	General = pd.DataFrame()
	Qty = Tool.shape[0] 
	Tool_Complete = Tool[(Tool['CurOp'] == "Complete")]
	Tool_Complete = Tool_Complete[~(Tool_Complete['TCO'] == 0.00)]
	
	General['Ship Date'] = Vcc['Ship date']
	General['Country'] = "" 
	General['Customer Name'] = ""
	General['WU Qty'] = ""
	General['Classify'] = ""
	General['Revenue'] = ""
	General['Prod. Line'] = Vcc['PRLN']
	General['MT'] = Vcc['MT']
	General['Preload'] = Vcc['P']
	General['MFG #'] = Vcc['MFGN']
	General['Order'] = Vcc['Order']
	General['TestCell'] = Vcc['Cell']
	General['Status'] = Vcc['Status']
	General['Op'] = Vcc['OP']
	General['Step'] = Vcc['STEP']
	General['TCO'] = Vcc['tco']
	General['ETTC Date'] = Vcc['ettc date']
	General = General.sort_values(['MFG #'], ascending=[True])
	
	MfgnL = []
	MfgnL = Vcc[['MFGN','Order']]
	

	for index, i in MfgnL.iterrows():
		for j in General.index[(General['MFG #'] == i['MFGN'])]:
			#print (str(Tool.loc[Tool['MFGN'].isin([i['MFGN']])]['Country'].values)[2:-2])
			General['Country'][j] = str(Tool.loc[Tool['MFGN'].isin([i['MFGN']])]['Country'].values)[2:-2]
			General['Customer Name'][j] = str(Tool.loc[Tool['MFGN'].isin([i['MFGN']])]['Custname'].values)[2:-2]
			if General['Customer Name'][j] == "a": General['Customer Name'][j] = ""
			General['WU Qty'][j] = str(Tool.loc[Tool['MFGN'].isin([i['MFGN']])]['WUs'].values)[1:-1]
			General['Classify'][j] = str(Tool.loc[Tool['MFGN'].isin([i['MFGN']])]['Class'].values + "-" + Tool.loc[Tool['MFGN'].isin([i['MFGN']])]['Firm'].values)[2:-2]
			General['Revenue'][j] = str(Tool.loc[Tool['MFGN'].isin([i['MFGN']])]['Rev'].values)[1:-1]

	MfgnL = Tool_Complete['MFGN'].tolist()

	#VCC=		['MFGN', 'Order', 'Model', 'MT', 'PRLN', 'Cell', 'Status', 'OP', 'STEP', 'PROGRAM', 'P', 'TC', 'CEC', 'Ship date', 'Country', 'tco', 'ettc', 'ettc date']
	#Tool = 	Class	Firm	MFGN	Custname	Country	Ords	Ororno	Rev	Est	Mdl	Rack	WUs	P/L	MType	RSSD	PSSD	Stat	TimeStamp	CurOp	OpNum	TCO	Cell	ETTC	Comment
	#General = 	Ship Date	Country	Customer Name	WU Qty	Classify	Revenue	Prod. Line	MT	Preload	MFG #	Order	TestCell	Status	Op	Step	TCO	ETTC Date
	Complete = pd.DataFrame()
	Complete['Ship Date'] = Tool_Complete['PSSD']
	Complete['Country'] = Tool_Complete['Country']
	Complete['Customer Name'] = Tool_Complete['Custname']
	Complete['WU Qty'] = Tool_Complete['WUs']
	Complete['Classify'] = Tool_Complete['Class'] + "-" + Tool_Complete['Firm']
	Complete['Revenue'] = Tool_Complete['Rev']
	Complete['Prod. Line'] = Tool_Complete['MType']
	Complete['MT'] = "" #* len(MfgnL)
	Complete['Preload'] = "" #* len(MfgnL)
	Complete['MFG #'] = Tool_Complete['MFGN']
	Complete['Order'] = Tool_Complete['Ororno']
	Complete['TestCell'] = Tool_Complete['Cell']
	Complete['Status'] = "" 
	Complete['Op'] = Tool_Complete['OpNum']
	Complete['Step'] = "" * len(MfgnL)
	Complete['TCO'] = "" #Tool_Complete['TCO']
	Complete['ETTC Date'] = Tool_Complete['ETTC']

	General = pd.concat([General,Complete], axis=0)
	
	

	General.reset_index(drop=True, inplace=True)

	General.fillna("")

	#General = General.infer_objects()

	if Save == True:
		General.to_csv('data_general.csv')	
	
	#General.to_csv('test.csv')
	return General

def Data_List(Save, Systems):
	#Headers
	#VCC=		['MFGN', 'Order', 'Model', 'MT', 'PRLN', 'Cell', 'Status', 'OP', 'STEP', 'PROGRAM', 'P', 'TC', 'CEC', 'Ship date', 'Country', 'tco', 'ettc', 'ettc date']
	#Tool = 	Class	Firm	MFGN	Custname	Country	Ords	Ororno	Rev	Est	Mdl	Rack	WUs	P/L	MType	RSSD	PSSD	Stat	TimeStamp	CurOp	OpNum	TCO	Cell	ETTC	Comment
	#General = 	Ship Date	Country	Customer Name	WU Qty	Classify	Revenue	Prod. Line	MT	Preload	MFG #	Order	TestCell	Status	Op	Step	TCO	ETTC Date
	Vcc = Data_Vcc(True)
	Tool = Data_Tool(True)
	Tool_All = Data_Tool_All(True)
	
	Tool = Filter_Data (Tool, ['MFGN'], [Systems])
	List_Tool = Tool['MFGN'].tolist()
	
	Systems_All =[x for x in Systems if x not in List_Tool]

	Tool_All = Filter_Data (Tool_All, ['MFGN'], [Systems_All]) 
	Vcc = Filter_Data(Vcc, ['MFGN'], [Systems])
	
	General = pd.DataFrame()
	
	Tool_Complete=Tool
	
	if 'CurOp' in list(Tool_Complete) and 'TCO' in list(Tool_Complete):
		Tool_Complete = Tool[(Tool['CurOp'] == "Complete")]
		Tool_Complete = Tool_Complete[~(Tool['TCO'] == 0.00)]

	Qty = Tool.shape[0] 	
	
	General['Ship Date'] = Vcc['Ship date']
	General['Country'] = "" 
	General['Customer Name'] = ""
	General['WU Qty'] = ""
	General['Classify'] = ""
	General['Revenue'] = 0
	General['Prod. Line'] = Vcc['PRLN']
	General['MT'] = Vcc['MT']
	General['OP #'] = ""
	General['Preload'] = Vcc['P']
	General['MFG #'] = Vcc['MFGN']
	General['Order'] = Vcc['Order']
	General['TestCell'] = Vcc['Cell']
	General['Status'] = Vcc['Status']
	General['Op'] = Vcc['OP']
	General['Step'] = Vcc['STEP']
	General['TCO'] = Vcc['tco']
	General['ETTC Date'] = Vcc['ettc date']
	General = General.sort_values(['MFG #'], ascending=[True])
	
	MfgnL = []
	MfgnL = Vcc[['MFGN','Order']]
	
	for index, i in MfgnL.iterrows():
		for j in General.index[(General['MFG #'] == i['MFGN'])]:
			General['Country'][j] = str(Tool.loc[Tool['MFGN'].isin([i['MFGN']])]['Country'].values)[2:-2]
			General['Customer Name'][j] = str(Tool.loc[Tool['MFGN'].isin([i['MFGN']])]['Custname'].values)[2:-2]
			if General['Customer Name'][j] == "a": General['Customer Name'][j] = ""
			General['WU Qty'][j] = str(Tool.loc[Tool['MFGN'].isin([i['MFGN']])]['WUs'].values)[1:-1]
			General['Classify'][j] = str(Tool.loc[Tool['MFGN'].isin([i['MFGN']])]['Class'].values + "-" + Tool.loc[Tool['MFGN'].isin([i['MFGN']])]['Firm'].values)[2:-2]
			General['Revenue'][j] = str(Tool.loc[Tool['MFGN'].isin([i['MFGN']])]['Rev'].values)[1:-1]

	Complete = pd.DataFrame()
	Complete['Ship Date'] = Tool_Complete['PSSD']
	Complete['Country'] = Tool_Complete['Country']
	Complete['Customer Name'] = Tool_Complete['Custname']
	Complete['WU Qty'] = Tool_Complete['WUs']
	Complete['Classify'] = Tool_Complete['Class'] + "-" + Tool_Complete['Firm']
	Complete['Revenue'] = Tool_Complete['Rev']
	Complete['Prod. Line'] = Tool_Complete['MType']
	Complete['MT'] = "" 
	Complete['OP #'] = ""
	Complete['Preload'] = "" 
	Complete['MFG #'] = Tool_Complete['MFGN']
	Complete['Order'] = Tool_Complete['Ororno']
	Complete['TestCell'] = Tool_Complete['Cell']
	Complete['Status'] = "COMPLETED" 
	Complete['Op'] = Tool_Complete['OpNum']
	Complete['Step'] = "" 
	Complete['TCO'] = "" 
	Complete['ETTC Date'] = Tool_Complete['ETTC']

	General = pd.concat([General,Complete], axis=0)
	General.reset_index(drop=True, inplace=True)

	Unique_General = General['MFG #'].drop_duplicates().values.tolist()
	Remaining = [x for x in Systems if x not in Unique_General]
	
	SQL = "SELECT DISTINCT WUSCHD, TLCTRY, WUTWRC, WUPROD, TLCMAT, WUMFGN, WUWORN, WUCELL, WUNMBR, WUOPST  FROM MFS2P010G.FCSPWU10 INNER JOIN MFS2P010G.FCSPTL10 ON WUMFGN = TLMFGN WHERE WUMFGN IN ("
	for x in Systems:
		SQL += "'"+x+"',"  
	SQL = SQL[:-1]
	SQL += ") AND WUWUNM = '0001'"
	
	df_db2 = Data_DB2(SQL)

	temp=[1]*(df_db2.shape[0])
	df_db2['WUTWRC'] = pd.to_numeric(df_db2['WUTWRC'])
	df_db2['WUTWRC'] = df_db2['WUTWRC'].sub(temp,axis=0)

	Tool_All = Filter_Data (Tool_All, ['MFGN'], [df_db2['WUMFGN']])
	
	Complement = pd.DataFrame()
	Complement['Ship Date'] = Tool_All['PSSD']
	Complement['Country'] = Tool_All['Country']
	Complement['Customer Name'] = Tool_All['Custname']
	Complement['WU Qty'] = Tool_All['WUs']
	Complement['Classify'] = Tool_All['Class'] + "-" + Tool_All['Firm']
	Complement['Revenue'] = Tool_All['Rev']
	Complement['Prod. Line'] = Tool_All['MType']
	Complement['MT'] = "" 
	Complement['OP #'] = ""
	Complement['Preload'] = "" 
	Complement['MFG #'] = Tool_All['MFGN']
	Complement['Order'] = Tool_All['Ororno']
	Complement['TestCell'] = ""
	Complement['Status'] = "" 
	Complement['Op'] = ""
	Complement['Step'] = "" 
	Complement['TCO'] = "" 
	Complement['ETTC Date'] = ""

	General = pd.concat([General,Complement], axis=0)
	
	General.reset_index(drop=True, inplace=True)

	General.fillna("", inplace=True)
	
	MfgnL = []
	MfgnL = df_db2[['WUMFGN','WUWORN']]
	
	for index, i in MfgnL.iterrows():
		for j in General.index[(General['MFG #'] == i['WUMFGN'])]:
			General['Ship Date'][j] = str(df_db2.loc[df_db2['WUMFGN'].isin([i['WUMFGN']])]['WUSCHD'].values)[2:-2]
			General['Country'][j] = str(df_db2.loc[df_db2['WUMFGN'].isin([i['WUMFGN']])]['TLCTRY'].values)[2:-2]
			General['WU Qty'][j] = str(df_db2.loc[df_db2['WUMFGN'].isin([i['WUMFGN']])]['WUTWRC'].values)[1:-1]
			General['Prod. Line'][j] = str(df_db2.loc[df_db2['WUMFGN'].isin([i['WUMFGN']])]['WUPROD'].values)[2:-2]
			General['MT'][j] = str(df_db2.loc[df_db2['WUMFGN'].isin([i['WUMFGN']])]['TLCMAT'].values)[2:-2]
			General['OP #'][j] = str(df_db2.loc[df_db2['WUMFGN'].isin([i['WUMFGN']])]['WUNMBR'].values)[2:-2] + "-" + str(df_db2.loc[df_db2['WUMFGN'].isin([i['WUMFGN']])]['WUOPST'].values)[2:-2]
			General['TestCell'][j] = str(df_db2.loc[df_db2['WUMFGN'].isin([i['WUMFGN']])]['WUCELL'].values)[2:-2]
	
	Unique_General = General['MFG #'].drop_duplicates().values.tolist()
	df_db2_2 = Filter_Data (df_db2, ['WUMFGN'], [Unique_General])
	df_db2_2 = df_db2_2.sort_values(['WUMFGN'], ascending=[True])
	General = General.sort_values(['MFG #'], ascending=[True])
	conditions = [
		(df_db2_2['WUNMBR'] == '0450') | (df_db2_2['WUNMBR'] == '0500') | (df_db2_2['WUNMBR'] == '0600'),
		(df_db2_2['WUNMBR'] == '0850') | (df_db2_2['WUNMBR'] == '0970') | (df_db2_2['WUNMBR'] == 'VI25') | (df_db2_2['WUNMBR'] == 'VI20')
		]
	choices = ['BUILD', 'COMPLETED']
	General['Status'] = np.select(conditions, choices, default=General['Status'])		 

	Unique_General = General['MFG #'].drop_duplicates().values.tolist()
	Remaining = [x for x in Systems if x not in Unique_General]
	
	df_db2 = Filter_Data (df_db2, ['WUMFGN'], [Remaining])
	
	DB2 = pd.DataFrame()
	DB2['Ship Date'] = df_db2['WUSCHD']
	DB2['Country'] = df_db2['TLCTRY']
	DB2['Customer Name'] = ""
	
	df_db2['WUTWRC'] = pd.to_numeric(df_db2['WUTWRC'])
	DB2['WU Qty'] = df_db2['WUTWRC']
	
	DB2['Classify'] = ""
	DB2['Revenue'] = 0
	DB2['Prod. Line'] = df_db2['WUPROD']
	DB2['MT'] = df_db2['TLCMAT']
	DB2['OP #'] = df_db2['WUNMBR'] + "-" + df_db2['WUOPST']
	DB2['Preload'] = "" 
	DB2['MFG #'] = df_db2['WUMFGN']
	DB2['Order'] = df_db2['WUWORN']
	DB2['TestCell'] = df_db2['WUCELL']
	
	conditions = [
		(df_db2['WUNMBR'] == '0450') | (df_db2['WUNMBR'] == '0500') | (df_db2['WUNMBR'] == '0600'),
		(df_db2['WUNMBR'] == '0850') | (df_db2['WUNMBR'] == '0970') | (df_db2['WUNMBR'] == 'VI25') | (df_db2['WUNMBR'] == 'VI20')
		]
	
	choices = ['BUILD', 'COMPLETED']
	DB2['Status'] = np.select(conditions, choices, default="NEED TO CHECK") 
	
	DB2['Op'] = ""
	DB2['Step'] = "" 
	DB2['TCO'] = "" 
	DB2['ETTC Date'] = ""
	
	General = pd.concat([General,DB2], axis=0)
	General['Revenue'] = General['Revenue'].apply(lambda x: 0 if x == '' else x)
	
	#Generar funcion
	General['CAT'] = pd.Categorical(General['Status'], categories=['HOLD','REWORK','RUNNING','BUILD','COMPLETED','NEED TO CHECK'], ordered=True)
	General.sort_values('CAT', inplace=True)
	General.drop('CAT', 1, inplace=True)
	General.reset_index(drop=True, inplace=True)
	
	General.fillna("", inplace=True)

	if Save == True:
		General.to_csv('data_general.csv')	
	
	return General


def Filter_Data(df, ColsF, ValsF):
	print ("Ejecutando Filter_Data...")
	if len(ColsF) > 0:
		for x in range(len(ColsF)):
			df = df.loc[df[ColsF[x]].isin(ValsF[x])]
	return df 

def Remove_Yorders(df):
	df = df[df['Order'].str.startswith("Y")==False]
	return df

def Remove_IPRorders(df):
	df = df[df['Order'].str.startswith("$")==False]
	return df

def Witherspoon_Table_1(df):
	print ("Witherspoon table 1")

def Status_Checker(df):
	X = 0
	Y = 0
	Width= []
	
	for i in df:
		for j in df[i]: 
			if i == 'Status':
				if j == 'QUAL_ENG':
					df[i][df.index[df[i] == j].tolist()] = 'HOLD'
				elif j == 'ABORT': 
					df[i][df.index[df[i] == j].tolist()] = 'REWORK'
				elif j == 'ATTENTION' or j == 'ATTN' or j == 'PASS':
					if df.iat[Y,X+1] == 'TVAL':
						df.iat[Y,X] = 'COMPLETED'
					else:
						df.iat[Y,X] = 'RUNNING'
				elif j == 'START' or j == 'PASS':
					df.iat[Y,X] = 'RUNNING'
				
			Y += 1
		Y = 0
		X += 1

	#df = df.sort_values(ColSort, ascending=OrdSort)

	return df

def Summary(df):
	df = Status_Checker(df)
	df['Revenue'] = df['Revenue'].apply(lambda x: 0 if x == '' else x)
	df['Revenue'] = df['Revenue'].astype(int)
	df = Filter_Data(df, ['Status'], [['HOLD', 'REWORK', 'COMPLETED', 'RUNNING', "DOWN"]])
	df = df.groupby(['Status'])['Revenue', 'MFG #'].agg(['sum', 'count'])
	df = df.drop(columns=[('Revenue', 'count'), ('MFG #', 'sum')])

	df.columns = ['Revenue', 'Systems']

	basic_status = ['COMPLETED','HOLD','REWORK','RUNNING', 'SUSPEND']#Tentativo

	for i in basic_status:
		if i not in df.index.values:
			df.loc[i] = [0,0]  

	total = df.apply(np.sum)
	df.loc['TOTAL'] = [total['Revenue'], total['Systems']]
	
	return df


#Data_Tool_All(True)

#Sumario
#df = Data_Tool_General(True,False)
#df = Summary(df)
#print(df)
#df_ima.Generate_Table_Summary(df, "Sumario", "PNG")



#Data_DB2("SELECT * FROM MFS2P010G.FCSPPR10 WHERE PRPRDT = '2018-01-22' and (PRTXCD = 'HOWN' or PRTXCD = 'HUSR' or PRTXCD = 'HCMT')")
#df = Data_DB2("SELECT WUMFGN, WUIDSS, WUMCTL,WUWTYP, WUPWUN, WUPRLN, WUPROD, WUNMBR, WUOPST, WUCSDS, WUCSTS, WUCELL, WUTWRC, WUWUNM FROM MFS2P010G.FCSPWU10 WHERE (WUPROD = 'WSP4AGUA' OR WUPROD = 'ORNLBULK' OR WUPROD = 'LLNLBULK') AND WUNMBR = 'TEST'")

#df = Data_DB2("SELECT WUMFGN, WUIDSS, WUMCTL,WUWTYP, WUPWUN, WUPRLN, WUPROD, WUNMBR, WUOPST, WUCSDS, WUCSTS, WUCELL, WUTWRC, WUWUNM FROM MFS2P010G.FCSPWU10 WHERE WUMFGN IN ('1AUEL27', '1AUEL28', '1AUEHJ6', '1AUEL38', '1AUEL39', '1AUEL41', '1AUEL42')")

#print(df)
#df.to_csv("DB2.csv")

#Data_List 
Systems = ['1AUEL27', '1AUEL28', '1AUEHJ6', '1AUEL38', '1AUEL39', '1AUEL41', '1AUEL42', '1AUCTA3', '1AUCTA6', '1AUCTA7', '1AUEJZ9', '1AUBWR4', '1AUEQN9', 'BBB5ALW', '1AUC411', '1AUEVZ4', '1AUEQG3', '1AUEUE1', '1AUC4R3', '1AUETW1', '1AUEUW9', '1AUEU09']
df = Data_List (True, Systems)
print(df)
#df.to_csv("DB2.csv")

#df = Data_Tool_General(True,False)
#print (df)

#df=Data_General (True)
#df = Data_Tool(False)
#print (df)