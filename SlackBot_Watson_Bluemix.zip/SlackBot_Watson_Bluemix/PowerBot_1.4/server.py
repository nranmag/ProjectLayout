import os
from slackclient import SlackClient
import time

from datetime import datetime, timedelta

import watson_bot as wb
import commands as cmms

import multiprocessing
from multiprocessing import Pool

import sys				

import pandas as pd

#SLACK information
Token = os.environ['POWERBOTTOKEN']
Slack_Client = SlackClient(Token)
Bot_Name = os.environ['POWERBOTNAME']




def Get_ID(Name):
	"""
		Get the SLack ID with the user name
	"""
	api_call = Slack_Client.api_call("users.list")
	if api_call.get('ok'):
		users = api_call.get('members')
		for user in users:
			if 'name' in user and user.get('name') == Name:
				return user.get('id')
	return "Null"

#Constants
At_Bot = "<@" + Get_ID(Bot_Name) + ">"

def Get_Name(user_name):
	api_call = Slack_Client.api_call("users.list")
	if api_call.get('ok'):
		users = api_call.get('members')
		for user in users:
			if user ['id'] == user_name:
				return user['real_name']

class PowerBot ():
		def __init__(self, Name, Input, Channel, Dad):
			self.Name = Name
			self.Input = Input
			self.Channel = Channel
			self.Dad = Dad
			self.Output = []
			self.Intent = []
			self.Product = []
			self.Subprod = []
			self.Area = []
			self.Format = ""
			self.Tiempo = []
			self.List = ""
			self.Systems = []
			self.Message_to_Dad = ""
			self.Path = []
			self.File = ""
			self.File_Title = []
			self.File_Text = ""
			self.Notification = ""

			print (self.Name + ": I'm alive :D")
			sys.stdout.flush()

		def run(self):
			if self.Input != "":
				self.Intent, self.Product, self.Subprod, self.Area, self.Format, self.Tiempo, self.List, self.Systems, self.Output = wb.Watson_to_Bot(self)
			
			for x in self.Output:
				Slack_Client.api_call("chat.postMessage", channel=self.Channel, text=x, as_user=True)
			

			if "ALAS" in self.Tiempo:
				columns	= ['Index', 'Botname', 'Channel', 'Real Name', 'Intent', 'Product', 'Area', 'Format', 'List', 'Systems', 'Time', 'Hour']
				Requests = pd.read_csv('Requests.csv',names=columns, skiprows=1, index_col=0)
				Requests.fillna("", inplace=True)
				my_time = datetime.strptime(datetime.now().strftime("%d-%m-%y %H:%M:%S"), '%d-%m-%y %H:%M:%S')

				today = datetime.now().strftime("%d-%m-%y")
				today = datetime.strptime(str(today) + " " + self.Tiempo[1], '%d-%m-%y %H:%M:%S') 
				
				if my_time <  today:
					my_time = today
				else:
					my_time = today + timedelta(hours=24)
				
				my_time = my_time.strftime('%d-%m-%y %H:%M:%S')

				if Requests.shape[0] == 0:
					row = {'Index':0, 'Botname':self.Name, 'Channel':self.Channel, 'Real Name':self.Dad, 'Intent': self.Intent[0], 'Product': self.Product[0], 'Area':self.Area[0], 'Format':self.Format[0], 'List':self.List, 'Systems':self.Systems, 'Time':"24:00:00", 'Hour':my_time}
					Requests = Requests.append(row,ignore_index=True)
				else:
					row = {'Index':int(Requests.tail(1).index.tolist()[0]) + 1, 'Botname':self.Name, 'Channel':self.Channel, 'Real Name':self.Dad, 'Intent': self.Intent[0], 'Product': self.Product[0], 'Area':self.Area[0], 'Format':self.Format[0], 'List':self.List, 'Systems':self.Systems, 'Time':"24:00:00", 'Hour':my_time}
					Requests = Requests.append(row,ignore_index=True)
				Requests.to_csv('Requests.csv', columns=columns)
			elif "PERIODO" in self.Tiempo:
				columns	= ['Index', 'Botname', 'Channel', 'Real Name', 'Intent', 'Product', 'Area', 'Format', 'List', 'Systems', 'Time', 'Hour']
				Requests = pd.read_csv('Requests.csv',names=columns, skiprows=1, index_col=0)
				Requests.fillna("", inplace=True)
				my_time = datetime.strptime(datetime.now().strftime("%d-%m-%y %H:%M:%S"), '%d-%m-%y %H:%M:%S')
				my_time = my_time + timedelta(hours=int(self.Tiempo[2].split(':')[0]), minutes=int(self.Tiempo[2].split(':')[1]), seconds=int(self.Tiempo[2].split(':')[2])) 
				my_time = my_time.strftime('%d-%m-%y %H:%M:%S')
				if Requests.shape[0] == 0:
					row = {'Index':0, 'Botname':self.Name, 'Channel':self.Channel, 'Real Name':self.Dad, 'Intent': self.Intent[0], 'Product': self.Product[0], 'Area':self.Area[0], 'Format':self.Format[0], 'List':self.List, 'Systems':self.Systems, 'Time':self.Tiempo[2], 'Hour':my_time}
					Requests = Requests.append(row,ignore_index=True)
				else:
					row = {'Index':int(Requests.tail(1).index.tolist()[0]) + 1, 'Botname':self.Name, 'Channel':self.Channel, 'Real Name':self.Dad, 'Intent': self.Intent[0], 'Product': self.Product[0], 'Area':self.Area[0], 'Format':self.Format[0], 'List':self.List, 'Systems':self.Systems, 'Time':self.Tiempo[2], 'Hour':my_time}
					Requests = Requests.append(row,ignore_index=True)
				Requests.to_csv('Requests.csv', columns=columns)
				
			sys.stdout.flush()
			
			cmms.Interpret_Command(self)
			
			if self.File != "":
				test = Slack_Client.api_call('files.upload', channels=self.Channel, filename=self.File + "." + self.Format[0].lower(), file=open(self.Path + "/" + self.File + "." + self.Format[0].lower(), 'rb'), initial_comment = self.File_Text , title= self.File_Title)
				if test['ok'] == True:
					os.remove (self.Path + "/" + self.File + "." + self.Format[0].lower())
			
			if self.Message_to_Dad != "":
				Slack_Client.api_call("chat.postMessage", channel=self.Channel, text=self.Message_to_Dad, as_user=True)	
			

			print (self.Name + ": I'm dying :(")
			sys.stdout.flush()


def parse_slack_output(Slack_Rtm_Output):
	"""
		The Slack Real Time Messaging API is an events firehose.
		this parsing function returns None unless a message is
		directed at the Bot, based on its ID.
	"""
	output_list = Slack_Rtm_Output
	if output_list and len(output_list) > 0:
		for output in output_list:
			if 'desktop_notification' in output['type']:
				if ("@" + Bot_Name) in output['content']:
					# return text after the @ mention, whitespace removed
					real_name = output['subtitle'] 
					return output['content'].split(("@" + Bot_Name))[1].strip().lower(), \
						   output['channel'], real_name
	return None, None, None

if __name__ == "__main__":
	READ_WEBSOCKET_DELAY = 1 # 1 second delay between reading from firehose
	
	columns	= ['Index', 'Botname', 'Channel', 'Real Name', 'Intent', 'Product', 'Area', 'Format', 'List', 'Systems', 'Time', 'Hour']
	Requests = pd.DataFrame(columns=columns)
	Requests.set_index('Index', inplace=True)
	Requests.to_csv('Requests.csv')
	if Slack_Client.rtm_connect():
		print(Bot_Name.upper() + " connected and running!")
		while True:
			command, channel, real_name = parse_slack_output(Slack_Client.rtm_read())
			
			if command and channel:
				if real_name != Bot_Name:
					now = datetime.now()
					
					botname = "PowerBot_" + format(now.year, '03x').upper() + format(now.month, '01x').upper() + format(now.day, '02x').upper() + format(now.hour, '02x').upper() + format(now.minute, '02x').upper()+ format(now.second, '02x').upper() + format(now.microsecond, '02x').upper()
					power = PowerBot(botname, command, channel, real_name)
					Bot = multiprocessing.Process(target=power.run)
					Bot.start()

				time.sleep(READ_WEBSOCKET_DELAY)
			else:
				Requests = pd.read_csv('Requests.csv', names= columns, skiprows=1, index_col=0)
				
				for index, i in Requests.iterrows():
					my_time = datetime.strptime(i['Hour'], '%d-%m-%y %H:%M:%S')
					now = datetime.now()
					now = now.strftime('%d-%m-%y %H:%M:%S')
					now = datetime.strptime(now, '%d-%m-%y %H:%M:%S')
					if now >= my_time:
						Requests['Hour'][index] = (my_time + timedelta(hours=int(i['Time'].split(':')[0]), minutes=int(i['Time'].split(':')[1]), seconds=int(i['Time'].split(':')[2]))).strftime('%d-%m-%y %H:%M:%S')
						Requests.to_csv('Requests.csv', columns=columns)

						Systems = i['Systems']
						Systems = Systems.replace("[","")
						Systems = Systems.replace("]","")
						Systems = Systems.replace("'","")
						Systems = Systems.split(",")
						System = ""
						
						for x in Systems:
							System +=  x.upper() + "\n"
							System = System.replace(" ","")
						
						Lista = i['List']
						Lista = str(Lista)
						Lista = Lista.replace("[","")
						Lista = Lista.replace("]","")
						Lista = Lista.replace("'","")
						Lista = '"' + Lista + '"'

						command = str(i['Intent']) + " " + str(i['Product']) + " " + Lista +  " " + str(i['Area']) + " " + str(i['Format']) + "\n" +  System
						
						power = PowerBot(i['Botname'], command, i['Channel'], i['Real Name'])
						Bot = multiprocessing.Process(target=power.run)
						Bot.start()
				
	else:
		print("Connection failed. Invalid Slack token or bot ID?")