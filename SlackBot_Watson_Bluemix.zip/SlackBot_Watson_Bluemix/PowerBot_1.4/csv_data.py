import pandas as pd
import numpy as np

import ibm_db
import ibm_db_dbi

import requests
import urllib3
import io

import sys
import cf_misc

pd.options.mode.chained_assignment = None 
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

def Data_DB2(SQL, Bot):
	print (Bot.Name + ": I'm executing SQL string")
	sys.stdout.flush()
	dsn = cf_misc.get_credentials('QUALITY9')['dsn']
	conn = ibm_db.connect(dsn, '', '')
	conni = ibm_db_dbi.Connection(conn)
	df = pd.read_sql(SQL, conni)
	
	return df

def Read_SQL(Intent,Entity,Area, Bot):
	print (Bot.Name + ": I'm reading SQL string")
	sys.stdout.flush()
	df = pd.read_csv('Queries.csv',header=0)
	df = Filter_Data(df, ['INTENT', 'ENTITY', 'AREA'], [[Intent],[Entity],[Area]], Bot)
	df = df.sort_values('ID', ascending=True)
	
	SQL = ""
	for x in df['SQL']:
		SQL += x
	return SQL


def Filter_Data(df, ColsF, ValsF, Bot):
	print (Bot.Name + ": I'm filtering the data")
	sys.stdout.flush()
	if len(ColsF) > 0:
		for x in range(len(ColsF)):
			df = df.loc[df[ColsF[x]].isin(ValsF[x])]
	sys.stdout.flush()
	return df 

def Remove_Yorders(df):
	df = df[df['Order'].str.startswith("Y")==False]
	return df

def Remove_IPRorders(df):
	df = df[df['Order'].str.startswith("$")==False]
	return df

def Summary(df, Bot):
	print (Bot.Name + ": I'm creating a summary data frame")
	sys.stdout.flush()
	print (df.shape[0])
	df.drop_duplicates(subset=['MFG #'], keep='first', inplace=True)
	print (df.shape[0])
	print (df)
	df = Status_Checker(df)
	df['Revenue'] = df['Revenue'].apply(lambda x: 0 if x == '' or x == 'NaN' else x)
	df.fillna(0)
	df['Revenue'] = df['Revenue'].astype(float)
	df = df.groupby(['Status'])['Revenue', 'MFG #'].agg(['sum', 'count'])
	df = df.drop(columns=[('Revenue', 'count'), ('MFG #', 'sum')])

	df.columns = ['Revenue', 'Systems']

	basic_status = ['COMPLETED', 'DOWN      ', 'HOLD      ','REWORK    ','RUNNING   ']#Tentativo

	for i in basic_status:
		if i not in df.index.values:
			df.loc[i] = [0,0]  

	total = df.apply(np.sum)
	df.loc['TOTAL'] = [total['Revenue'], total['Systems']]
	df['Systems'] = df['Systems'].astype(int)
	
	return df

def Status_Checker(df):
	X = 0
	Y = 0
	Width= []
	
	for i in df:
		for j in df[i]: 
			if i == 'Status':
				if j == 'QUAL_ENG':
					df[i][df.index[df[i] == j].tolist()] = 'HOLD      '
				elif j == 'ABORT': 
					df[i][df.index[df[i] == j].tolist()] = 'REWORK    '
				elif j == 'ATTENTION' or j == 'ATTN' or j == 'PASS':
					if df.iat[Y,X+1] == 'TVAL':
						df.iat[Y,X] = 'COMPLETED'
					else:
						df.iat[Y,X] = 'RUNNING   '
				elif j == 'START' or j == 'PASS':
					df.iat[Y,X] = 'RUNNING   '
				
			Y += 1
		Y = 0
		X += 1

	return df
