import os
from slackclient import SlackClient
import time
#import datetime , timedelta
from datetime import datetime, timedelta

import watson_bot as wb
import commands as cmms

#import tkinter as Tk
				

#SLACK information
Token = "xoxb-301657063959-c4VHT8yXJKa0K9HERMeYGEMO" #Oficial token 
#Token = "xoxb-267672714900-JTqqAcHQpYY51HoRlsOP6UBs"#Test token
Slack_Client = SlackClient(Token)
Bot_Name = 'powertestbot' #Oficial name
#Bot_Name = 'qrytestbot' #Test name

exitFlag = 0
Thread = []



def print_wait(self):
	Slack_Client.api_call("chat.postMessage", channel=channel, text=self.name + " inicio", as_user=True)
	#time.sleep(3)
	Slack_Client.api_call("chat.postMessage", channel=channel, text=self.name + " fin", as_user=True)
	#Slack_Client.api_call("chat.postMessage", channel=channel, text=self.name + " fin", as_user=True)
	return True

def Get_ID(Name):
	"""
		Get the SLack ID with the user name
	"""
	api_call = Slack_Client.api_call("users.list")
	if api_call.get('ok'):
		users = api_call.get('members')
		for user in users:
			if 'name' in user and user.get('name') == Name:
				return user.get('id')
	return "Null"

#Constants
At_Bot = "<@" + Get_ID(Bot_Name) + ">"

def Get_Name(user_name):
	api_call = Slack_Client.api_call("users.list")
	if api_call.get('ok'):
		users = api_call.get('members')
		for user in users:
			if user ['id'] == user_name:
				return user['real_name']



def parse_slack_output(Slack_Rtm_Output):
	"""
		The Slack Real Time Messaging API is an events firehose.
		this parsing function returns None unless a message is
		directed at the Bot, based on its ID.
	"""
	output_list = Slack_Rtm_Output
	if output_list and len(output_list) > 0:
		for output in output_list:
			if output and 'text' in output and At_Bot in output['text']:
				# return text after the @ mention, whitespace removed
				real_name = Get_Name (output['user'])
				return output['text'].split(At_Bot)[1].strip().lower(), \
					   output['channel'], real_name
	return None, None, None

if __name__ == "__main__":
	READ_WEBSOCKET_DELAY = 1 # 1 second delay between reading from firehose
	###
	#root = Tk.Tk()
	#root.wm_title("Embedding in TK")
	#app = PowerBot(root)
	###
	
	class PowerBot ():
		def __init__(self, Name, Input, Real_Name, Channel):
			self.Name = Name
			self.Input = Input
			self.Real_Name = Real_Name
			self.Channel = Channel
			
	      
		def run(self):
		    print ("Starting " + self.Name)
		    #print_wait(self)
		    ListComms1, ListComms2, ListComms3, ListComms4, ListComms5, List_Name, Systems, Output = wb.Watson_to_Bot(self.Input)
		    cmms.Interpret_Command(ListComms1, ListComms2, ListComms3, ListComms4, ListComms5, List_Name, Systems, Output, self.Real_Name, self.Channel, Slack_Client)
		    print ("Exiting " + self.Name)
		    #checker = Thread
		    time.sleep(1)
		    
	if Slack_Client.rtm_connect():
		print(Bot_Name.upper() + " connected and running!")
		#lock = threading.Lock()

		while True:
			command, channel, real_name = parse_slack_output(Slack_Client.rtm_read())
			
			if command and channel:
				if real_name != Bot_Name:
					now = datetime.now()
					powerbot = PowerBot("PowerBot_" + str(now.year) + "_" + str(now.month) + "_" + str(now.day) + "_" + str(now.hour) + "_" + str(now.minute) + "_" + str(now.second) + "_" + str(now.microsecond), command,channel, real_name) 
					#powerbot = PowerBot()
					#powerbot.Name = 
					#PowerBot(1, "PowerBot_" + str(now.year) + "_" + str(now.month) + "_" + str(now.day) + "_" + str(now.hour) + "_" + str(now.minute) + "_" + str(now.second) + "_" + str(now.microsecond), command,channel, real_name)) 
					powerbot.run()
	
			time.sleep(READ_WEBSOCKET_DELAY)
	else:
		print("Connection failed. Invalid Slack token or bot ID?")