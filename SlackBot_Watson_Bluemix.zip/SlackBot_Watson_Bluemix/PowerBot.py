from __future__ import print_function
import json
from watson_developer_cloud import ConversationV1
import os
import sys
import time
from slackclient import SlackClient
import csv_data as cd
import df_ima
import pandas as pd

#SLACK information

#Token = "xoxb-301657063959-c4VHT8yXJKa0K9HERMeYGEMO" #Oficial token 
Token = "xoxb-267672714900-JTqqAcHQpYY51HoRlsOP6UBs"#Test token
Slack_Client = SlackClient(Token)
#Bot_Name = 'powertestbot' #Oficial name
Bot_Name = 'qrytestbot' #Test name

#Watson information
conversation = ConversationV1(
	username='38a164e2-0e16-4a45-83de-57504f915318',
	password='RlXgqcM0zAwz',
	version='2017-05-26')

# replace with your own workspace_id
workspace_id = '4e05ead6-9cb6-4cb1-b893-9bc74af1a0e4'
if os.getenv("conversation_workspace_id") is not None:
	workspace_id = os.getenv("conversation_workspace_id")


Command_List = []





#Get user id 
def Get_ID(Name):
	"""
		Get the SLack ID with the user name
	"""
	api_call = Slack_Client.api_call("users.list")
	if api_call.get('ok'):
		# retrieve all users so we can find our bot
		users = api_call.get('members')
		for user in users:
			if 'name' in user and user.get('name') == Name:
				return user.get('id')
	return "Null"

#Constants
At_Bot = "<@" + Get_ID(Bot_Name) + ">"
CommandsLvl1 = ["ESTATUS", "STATUS", "GENERAR", "ELIMINAR", "HELP", "AYUDA", "SUMARIO"]
CommandsLvl2 = ["GENERAL", "BRAZO", "BRAZOS", "ALPINE" , "ZZ", "TULETA", "EASTWOOD", "SOLUTION", "WITHERSPOON", "TCO", "TOOL", "LISTA", "VENTANA"]
CommandsLvl3 = ["HOLD", "RUNNING", "REWORK", "COMPLETED", "TABLA"]
CommandsLvl4 = ["PDF", "PNG", "XLSX", "EXCEL"]

def Get_Name(user_name):
	api_call = Slack_Client.api_call("users.list")
	if api_call.get('ok'):
		users = api_call.get('members')
		for user in users:
			if user ['id'] == user_name:
				return user['real_name']


def Watson_to_Bot(Input,Channel, Real_Name):
	ListComms1 = []
	ListComms2 = []
	ListComms3 = []
	ListComms4 = []
	ListComms5 = []
	Output = []
	Input_R = []
	Systems = []
	Input = Input.upper()
	List_Name = ""

	if "\n" in Input:
		Input = Input.split("\n")
		Input_R = Input[1:]
		Input = Input[0]
		 
	response = conversation.message(workspace_id=workspace_id, input={
	'text': Input})
	
	"""
	CommandsLvl1 = ["ESTATUS", "STATUS", "GENERAR", "ELIMINAR", "HELP", "AYUDA", "SUMARIO"]
	CommandsLvl2 = ["GENERAL", "BRAZO", "BRAZOS", "ALPINE" , "ZZ", "TULETA", "EASTWOOD", "SOLUTION", "WITHERSPOON", "TCO", "TOOL", "LISTA", "VENTANA"]
	CommandsLvl3 = ["HOLD", "RUNNING", "REWORK", "COMPLETED", "TABLA"]
	CommandsLvl4 = ["PDF", "PNG", "XLSX", "EXCEL"]

	"""
	#print(json.dumps(response, indent=2))
	data = json.loads(json.dumps(response, indent=2))

	for x in data['intents']:
		ListComms1.append(x['intent'])
	
	print (len(data['entities'])) 
	if len(data['entities']) == 0:
		List_Name = Input.split('"')[1::2]
		Systems = Input_R

	for x in data['entities']:
		if x['entity'] == 'Producto':
			ListComms2.append(x['value'])
			if x['value'] == 'Lista':
				#print (Input.split('"')[1::2])
				List_Name = Input.split('"')[1::2]
				Systems = Input_R


		elif x['entity'] == 'Formato':
			ListComms4.append(x['value'])
	for x in data['output']['text']:
		Output.append(x)

	print (data)
	
	Interpret_Command(ListComms1, ListComms2, ListComms3, ListComms4, ListComms5, Real_Name, List_Name, Systems, Output)
	#return data



def handle_command(Command, Channel, Real_Name):
	"""
		Receives commands directed at the bot and determines if they
		are valid commands. If so, then acts on the commands. If not,
		returns back what it needs for clarification.
	"""
	#Lists to load the commands
	ListComms1 = []
	ListComms2 = []
	ListComms3 = []
	ListComms4 = []
	ListComms5 = []

	Command =  Command.split()
	Command = [x.upper() for x in Command]
	
	for j in Command: 
		for i in CommandsLvl1:
			if i.upper() == j.upper():
				ListComms1.append(i.upper())
		for i in CommandsLvl2:
			if i.upper() == j.upper():
				ListComms2.append(i.upper())
		for i in CommandsLvl3:
			if i.upper() == j.upper():
				ListComms3.append(i.upper())
		for i in CommandsLvl4:
			if i.upper() == j.upper():
				ListComms4.append(i.upper())

	[Command.remove(x.upper()) for x in ListComms1]
	[Command.remove(x.upper()) for x in ListComms2]
	[Command.remove(x.upper()) for x in ListComms3]
	[Command.remove(x.upper()) for x in ListComms4]

	ListComms5 = Command
	
	Interpret_Command(ListComms1, ListComms2, ListComms3, ListComms4, ListComms5, Real_Name, Output)

def Interpret_Command(ListComms1, ListComms2, ListComms3, ListComms4, ListComms5, Real_Name, List_Name, Systems, Output):
	print ("Ejecutando Interpret_Command...")
	Intents = ["ESTATUS", "GENERAR", "SUMARIO"]
	#Detect the OS to use the correct command
	if sys.platform == "win32":
		Path = os.path.dirname(__file__)
	elif sys.platform == "linux":
		Path = os.path.dirname(os.path.realpath(__file__)) 
	
	SQL_String = ""
	if len(ListComms1) > 1:
		Slack_Client.api_call("chat.postMessage", channel=channel, text="Se recibio mas de un comando primario, se tomara en cuenta solo el primero.", as_user=True)
	if len(ListComms1) > 0:
		if ListComms1[0].upper() == "ESTATUS" or ListComms1[0].upper() == "STATUS":
			if len(ListComms2) > 0:
				for i in ListComms2:
					#General status
					if i.upper() == "GENERAL":
						for x in Output:
							Slack_Client.api_call("chat.postMessage", channel=channel, text=x, as_user=True)
						#df = cd.Data_General(False,False)
						df = cd.Data_Tool_General(False,False)
						df = cd.Remove_Yorders(df)
						if df.shape[0] > 0:
							if len(ListComms4) > 0:
								if "PNG" in ListComms4:	
									Send_File(df, "General", "png",Path,"Estatus General", "There you go " + Real_Name, ['Status', 'MFG #', 'TestCell'], [True, True, True])		
								elif "PDF" in ListComms4:
									Send_File(df, "General", "pdf",Path,"Estatus General", "There you go " + Real_Name, ['Status', 'MFG #', 'TestCell'], [True, True, True])
								elif "XLSX" in ListComms4 or "EXCEL" in ListComms4:
									Send_File(df, "General", "xlsx",Path,"Estatus de General", "There you go " + Real_Name, ['Status', 'MFG #', 'TestCell'], [True, True, True])		
							else:
								Send_File(df, "General", "png",Path,"", "There you go " + Real_Name, ['Status', 'MFG #', 'TestCell'], [True, True, True])
						else:
							Slack_Client.api_call("chat.postMessage", channel=channel, text="El estatus deseado no contiene ningun elemento", as_user=True)
					
					#Brazos status
					
					elif i.upper() == "BRAZO" or i.upper() == "BRAZOS":
						for x in Output:
							Slack_Client.api_call("chat.postMessage", channel=channel, text=x, as_user=True)
						df = cd.Data_Tool_General(True,False)
						df, Width = df_ima.Order_Df(df, ['Status', 'MFG #', 'TestCell'], [True, True, True])
						df = cd.Filter_Data(df, ['MT'], [['9117', '9080', '9119', '9179']])
						if df.shape[0] > 0:
							if len(ListComms4) > 0:
								if "PNG" in ListComms4:	
									Send_File(df, "Brazos", "png",Path,"Estatus de Brazos", "There you go " + Real_Name, ['Status', 'MFG #', 'TestCell'], [True, True, True])		
								elif "PDF" in ListComms4:
									Send_File(df, "Brazos", "pdf",Path,"Estatus de Brazos", "There you go " + Real_Name, ['Status', 'MFG #', 'TestCell'], [True, True, True])	
								elif "XLSX" in ListComms4 or "EXCEL" in ListComms4:
									Send_File(df, "Brazos", "xlsx",Path,"Estatus de Brazos", "There you go " + Real_Name, ['Status', 'MFG #', 'TestCell'], [True, True, True])
							else:
								Send_File(df, "Brazos", "png",Path,"Estatus de Brazos", "There you go " + Real_Name, ['Status', 'MFG #', 'TestCell'], [True, True, True])
						else:
							Slack_Client.api_call("chat.postMessage", channel=channel, text="El estatus deseado no contiene ningun elemento", as_user=True)
					#Alpine status
					elif i.upper() == "ALPINE":
						for x in Output:
							Slack_Client.api_call("chat.postMessage", channel=channel, text=x, as_user=True)
						df = cd.Data_Tool_General(True,False)
						df, Width = df_ima.Order_Df(df, ['Status', 'MFG #', 'TestCell'], [True, True, True])
						df = cd.Filter_Data(df, ['MT'], [['8408']])
						if df.shape[0] > 0:
							if len(ListComms4) > 0:
								if "PNG" in ListComms4:	
									Send_File(df, "Alpine", "png",Path,"Estatus de Alpine", "There you go " + Real_Name, ['Status', 'MFG #', 'TestCell'], [True, True, True])		
								elif "PDF" in ListComms4:
									Send_File(df, "Alpine", "pdf",Path,"Estatus de Alpine", "There you go " + Real_Name, ['Status', 'MFG #', 'TestCell'], [True, True, True])
								elif "XLSX" in ListComms4 or "EXCEL" in ListComms4:
									Send_File(df, "Alpine", "xlsx",Path,"Estatus de Alpine", "There you go " + Real_Name, ['Status', 'MFG #', 'TestCell'], [True, True, True])	
							else:
								Send_File(df, "Alpine", "png",Path,"Estatus de Alpine", "There you go " + Real_Name, ['Status', 'MFG #', 'TestCell'], [True, True, True])
						else:
							Slack_Client.api_call("chat.postMessage", channel=channel, text="El estatus deseado no contiene ningun elemento", as_user=True)
					#ZZ status
					elif i.upper() == "ZZ":
						for x in Output:
							Slack_Client.api_call("chat.postMessage", channel=channel, text=x, as_user=True)
						df = cd.Data_Tool_General(True,False)
						df, Width = df_ima.Order_Df(df, ['Status', 'MFG #', 'TestCell'], [True, True, True])
						df = cd.Filter_Data(df, ['MT'], [['9008', '9009']])
						if df.shape[0] > 0:
							if len(ListComms4) > 0:
								if "PNG" in ListComms4:	
									Send_File(df, "ZZ", "png",Path,"Estatus de ZZ", "There you go " + Real_Name, ['Status', 'MFG #', 'TestCell'], [True, True, True])		
								elif "PDF" in ListComms4:
									Send_File(df, "ZZ", "pdf",Path,"Estatus de ZZ", "There you go " + Real_Name, ['Status', 'MFG #', 'TestCell'], [True, True, True])
								elif "XLSX" in ListComms4 or "EXCEL" in ListComms4:
									Send_File(df, "ZZ", "xlsx",Path,"Estatus de ZZ", "There you go " + Real_Name, ['Status', 'MFG #', 'TestCell'], [True, True, True])	
							else:
								Send_File(df, "ZZ", "png",Path,"Estatus de ZZ", "There you go " + Real_Name, ['Status', 'MFG #', 'TestCell'], [True, True, True])
						else:
							Slack_Client.api_call("chat.postMessage", channel=channel, text="El estatus deseado no contiene ningun elemento", as_user=True)
					#Tuleta status
					elif i.upper() == "TULETA":
						for x in Output:
							Slack_Client.api_call("chat.postMessage", channel=channel, text=x, as_user=True)
						df = cd.Data_Tool_General(True,False)
						df, Width = df_ima.Order_Df(df, ['Status', 'MFG #', 'TestCell'], [True, True, True])
						df = cd.Filter_Data(df, ['MT'], [['8286', '8284']])
						if df.shape[0] > 0:
							if len(ListComms4) > 0:
								if "PNG" in ListComms4:	
									Send_File(df, "Tuleta", "png",Path,"Estatus de Tuleta", "There you go " + Real_Name, ['Status', 'MFG #', 'TestCell'], [True, True, True])		
								elif "PDF" in ListComms4:
									Send_File(df, "Tuleta", "pdf",Path,"Estatus de Tuleta", "There you go " + Real_Name, ['Status', 'MFG #', 'TestCell'], [True, True, True])
								elif "XLSX" in ListComms4 or "EXCEL" in ListComms4:
									Send_File(df, "Tuleta", "xlsx",Path,"Estatus de Tuleta", "There you go " + Real_Name, ['Status', 'MFG #', 'TestCell'], [True, True, True])	
							else:
								Send_File(df, "Tuleta", "png",Path,"Estatus de Tuleta", "There you go " + Real_Name, ['Status', 'MFG #', 'TestCell'], [True, True, True])
						else:
							Slack_Client.api_call("chat.postMessage", channel=channel, text="El estatus deseado no contiene ningun elemento", as_user=True)
					#Eastwood status
					elif i.upper() == "EASTWOOD" or i.upper() == "SOLUTION":
						for x in Output:
							Slack_Client.api_call("chat.postMessage", channel=channel, text=x, as_user=True)
						df = cd.Data_Tool_General(True,False)
						df, Width = df_ima.Order_Df(df, ['Status', 'MFG #', 'TestCell'], [True, True, True])
						df = cd.Filter_Data(df, ['MT'], [['5148', '8247', '5104']])
						if df.shape[0] > 0:
							if len(ListComms4) > 0:
								if "PNG" in ListComms4:	
									Send_File(df, "Solutions", "png",Path,"Estatus de Solutions", "There you go " + Real_Name, ['Status', 'MFG #', 'TestCell'], [True, True, True])		
								elif "PDF" in ListComms4:
									Send_File(df, "Solutions", "pdf",Path,"Estatus de Solutions", "There you go " + Real_Name,['Status', 'MFG #', 'TestCell'], [True, True, True])	
								elif "XLSX" in ListComms4 or "EXCEL" in ListComms4:
									Send_File(df, "Solutions", "xlsx",Path,"Estatus de Solutions", "There you go " + Real_Name, ['Status', 'MFG #', 'TestCell'], [True, True, True])
							else:
								Send_File(df, "Solutions", "png",Path,"Estatus de Solutions", "There you go " + Real_Name,['Status', 'MFG #', 'TestCell'], [True, True, True])
						else:
							Slack_Client.api_call("chat.postMessage", channel=channel, text="El estatus deseado no contiene ningun elemento", as_user=True)
					#Witherspoon status
					elif i.upper() == "WITHERSPOON":
						for x in Output:
							Slack_Client.api_call("chat.postMessage", channel=channel, text=x, as_user=True)
						df = cd.Data_Tool_General(True,False)
						df, Width = df_ima.Order_Df(df, ['Status', 'MFG #', 'TestCell'], [True, True, True])
						df = cd.Filter_Data(df, ['MT'], [['8335']])
						if df.shape[0] > 0:
							if len(ListComms4) > 0:
								if "PNG" in ListComms4:	
									Send_File(df, "Witherspoon", "png",Path,"Estatus de Witherspoon", "There you go " + Real_Name, ['Status', 'MFG #', 'TestCell'], [True, True, True])		
								elif "PDF" in ListComms4:
									Send_File(df, "Witherspoon", "pdf",Path,"Estatus de Witherspoon", "There you go " + Real_Name, ['Status', 'MFG #', 'TestCell'], [True, True, True])	
								elif "XLSX" in ListComms4 or "EXCEL" in ListComms4:
									Send_File(df, "Witherspoon", "xlsx",Path,"Estatus de Witherspoon", "There you go " + Real_Name, ['Status', 'MFG #', 'TestCell'], [True, True, True])	
							else:
								Send_File(df, "Witherspoon", "png",Path,"Estatus de Witherspoon", "There you go " + Real_Name, ['Status', 'MFG #', 'TestCell'], [True, True, True])
						else:
							Slack_Client.api_call("chat.postMessage", channel=channel, text="El estatus deseado no contiene ningun elemento", as_user=True)
					#Criticas status
					elif i.upper() == "CRITICAS":
						for x in Output:
							Slack_Client.api_call("chat.postMessage", channel=channel, text=x, as_user=True)
						Systems = Read_List(i.upper())
						df = cd.Data_List(True,Systems)
						df, Width = df_ima.Order_Df(df, ['Status', 'MFG #', 'TestCell'], [True, True, True])
						if df.shape[0] > 0:
							if len(ListComms4) > 0:
								if "PNG" in ListComms4:	
									#Send_File(df, i.upper(), "png",Path,"Estatus de " + i.upper(), "There you go " + Real_Name, ['Status', 'MFG #', 'TestCell'], [True, True, True])
									Send_File(df, i.upper(), "png",Path,"Estatus de " + i.upper(), "There you go " + Real_Name, ['Status', 'MFG #', 'TestCell'], [True, True, True])		
								elif "PDF" in ListComms4:
									Send_File(df, i.upper(), "pdf",Path,"Estatus de " + i.upper(), "There you go " + Real_Name, ['Status', 'MFG #', 'TestCell'], [True, True, True])	
								elif "XLSX" in ListComms4 or "EXCEL" in ListComms4:
									Send_File(df, i.upper(), "xlsx",Path,"Estatus de " + i.upper(), "There you go " + Real_Name, ['Status', 'MFG #', 'TestCell'], [True, True, True])	
							else:
								Send_File(df, i.upper(), "png",Path,"Estatus de " + List_Name[0], "There you go " + Real_Name, ['Status', 'MFG #', 'TestCell'], [True, True, True])
						else:
							Slack_Client.api_call("chat.postMessage", channel=channel, text="El estatus deseado no contiene ningun elemento", as_user=True)		
					#TCO status
					elif i.upper() == "TCO":
						for x in Output:
							Slack_Client.api_call("chat.postMessage", channel=channel, text=x, as_user=True)
						Tcos = Generate_TCO_List(20)
						df = cd.Data_Tool_General(True,False)
						df, Width = df_ima.Order_Df(df, ['Status', 'MFG #', 'TestCell'], [True, True, True])
						df = cd.Filter_Data(df, ['TCO'], [Tcos])
						df = cd.Remove_Yorders(df)
						if df.shape[0] > 0:
							if len(ListComms4) > 0:
								if "PNG" in ListComms4:	
									Send_File(df, "TCO", "png",Path,"Estatus de TCO", "There you go " + Real_Name, ['TCO'], [False])		
								elif "PDF" in ListComms4:
									Send_File(df, "TCO", "pdf",Path,"Estatus de TCO", "There you go " + Real_Name, ['TCO'], [False])
								elif "XLSX" in ListComms4 or "EXCEL" in ListComms4:
									Send_File(df, "TCO", "xlsx",Path,"Estatus de TCO", "There you go " + Real_Name, ['TCO'], [False])	
							else:
								Send_File(df, "TCO", "png",Path,"Estatus de TCO", "There you go " + Real_Name, ['TCO'], [False])
						else:
							Slack_Client.api_call("chat.postMessage", channel=channel, text="El estatus deseado no contiene ningun elemento", as_user=True)
					#Window status
					elif i.upper() == "VENTANA":
						for x in Output:
							Slack_Client.api_call("chat.postMessage", channel=channel, text=x, as_user=True)
						Window = Generate_Window_List(7)
						df = cd.Data_Tool_General(True,False)
						df, Width = df_ima.Order_Df(df, ['Status', 'MFG #', 'TestCell'], [True, True, True])
						df = cd.Filter_Data(df, ['Ship Date'], [Window])
						df = cd.Remove_Yorders(df)
						if df.shape[0] > 0:
							if len(ListComms4) > 0:
								if "PNG" in ListComms4:	
									Send_File(df, "Ventana", "png",Path,"Estatus de Ventana", "There you go " + Real_Name, ['Ship Date'], [True])		
								elif "PDF" in ListComms4:
									Send_File(df, "Ventana", "pdf",Path,"Estatus de Ventana", "There you go " + Real_Name, ['Ship Date'], [True])
								elif "XLSX" in ListComms4 or "EXCEL" in ListComms4:
									Send_File(df, "Ventana", "xlsx",Path,"Estatus de Ventana", "There you go " + Real_Name, ['Ship Date'], [False])	
							else:
								Send_File(df, "Ventana", "png",Path,"Estatus de Ventana", "There you go " + Real_Name, ['Ship Date'], [True])
						else:
							Slack_Client.api_call("chat.postMessage", channel=channel, text="El estatus deseado no contiene ningun elemento", as_user=True)
					#Tool status
					
					elif i.upper() == "TOOL":
						for x in Output:
							Slack_Client.api_call("chat.postMessage", channel=channel, text=x, as_user=True)
						df = cd.Data_Tool_General(False,True)
						df = cd.Remove_Yorders(df)
						if df.shape[0] > 0:
							if len(ListComms4) > 0:
								if "PNG" in ListComms4:	
									Send_File(df, "Tool", "png",Path,"Estatus Tool", "There you go " + Real_Name, ['Status', 'MFG #', 'TestCell'], [True, True, True])		
								elif "PDF" in ListComms4:
									Send_File(df, "Tool", "pdf",Path,"Tool", "There you go " + Real_Name, ['Status', 'MFG #', 'TestCell'], [True, True, True])
								elif "XLSX" in ListComms4 or "EXCEL" in ListComms4:
									Send_File(df, "Tool", "xlsx",Path,"Estatus de Tool", "There you go " + Real_Name, ['Status', 'MFG #', 'TestCell'], [True, True, True])		
							else:
								Send_File(df, "Tool", "png",Path,"Estatus Tool", "There you go " + Real_Name, ['Status', 'MFG #', 'TestCell'], [True, True, True])
						else:
							Slack_Client.api_call("chat.postMessage", channel=channel, text="El estatus deseado no contiene ningun elemento", as_user=True)
					
					#Estatus listas
					elif i.upper() == "LISTA":
						for x in Output:
							Slack_Client.api_call("chat.postMessage", channel=channel, text=x, as_user=True)
						print (List_Name)
						Systems = Read_List(List_Name[0])
						#df = cd.Data_Tool_General(True,False)
						df = cd.Data_List(True,Systems)
						df, Width = df_ima.Order_Df(df, ['Status', 'MFG #', 'TestCell'], [True, True, True])
						#df = cd.Filter_Data(df, ['MFG #'], [Systems])
						if df.shape[0] > 0:
							if len(ListComms4) > 0:
								if "PNG" in ListComms4:	
									#Send_File(df, i.upper(), "png",Path,"Estatus de " + i.upper(), "There you go " + Real_Name, ['Status', 'MFG #', 'TestCell'], [True, True, True])
									Send_File(df, List_Name[0], "png",Path,"Estatus de " + List_Name[0], "There you go " + Real_Name, ['Status', 'MFG #', 'TestCell'], [True, True, True])		
								elif "PDF" in ListComms4:
									Send_File(df, List_Name[0], "pdf",Path,"Estatus de " + List_Name[0], "There you go " + Real_Name, ['Status', 'MFG #', 'TestCell'], [True, True, True])	
								elif "XLSX" in ListComms4 or "EXCEL" in ListComms4:
									Send_File(df, List_Name[0], "xlsx",Path,"Estatus de " + List_Name[0], "There you go " + Real_Name, ['Status', 'MFG #', 'TestCell'], [True, True, True])	
							else:
								print(List_Name[0])
								Send_File(df, List_Name[0], "png",Path,"Estatus de " + List_Name[0], "There you go " + Real_Name, ['Status', 'MFG #', 'TestCell'], [True, True, True])
						else:
							Slack_Client.api_call("chat.postMessage", channel=channel, text="El estatus deseado no contiene ningun elemento", as_user=True)		

					
		elif ListComms1[0].upper() == "GENERAR":
			Slack_Client.api_call("chat.postMessage", channel=channel, text="Quieren generar una lista", as_user=True)
			for i in ListComms2:
				if i.upper() == "LISTA":
					if len(ListComms2) > 1:
						ListComms5.insert(0,ListComms2[1])
						Create_List(ListComms5)
					else:
						Create_List( ListComms5)
				"""
				if i.upper() == "WITHERSPOON":
					for i in ListComms3:
						if i.upper() == "TABLA":
							Slack_Client.api_call("chat.postMessage", channel=channel, text="Quieren generar una tabla de WITHERSPOON", as_user=True)
				"""
		elif ListComms1[0].upper() == "SUMARIO":
			for i in ListComms2:
				if i.upper() == "GENERAL":
					for x in Output:
							Slack_Client.api_call("chat.postMessage", channel=channel, text=x, as_user=True)
					df = cd.Data_Tool_General(False,False)
					df = cd.Remove_Yorders(df)
					df = cd.Summary(df)
								
					if df.shape[0] > 0:
						if len(ListComms4) > 0:
							if "PNG" in ListComms4:	
								Send_Sumarry(df, "General_Summary", "png",Path,"Sumario General", "There you go " + Real_Name)	
							elif "PDF" in ListComms4:
								Send_Sumarry(df, "General_Summary", "pdf",Path,"Sumario General", "There you go " + Real_Name)
							elif "XLSX" in ListComms4 or "EXCEL" in ListComms4:
								Send_Sumarry(df, "General_Summary", "xlsx",Path,"Sumario General", "There you go " + Real_Name)
						else:
							Send_Sumarry(df, "General_Summary", "png",Path,"Sumario General", "There you go " + Real_Name)
					else:
						Slack_Client.api_call("chat.postMessage", channel=channel, text="El estatus deseado no contiene ningun elemento", as_user=True)
				
				elif i.upper() == "BRAZO" or i.upper() == "BRAZOS":
					for x in Output:
							Slack_Client.api_call("chat.postMessage", channel=channel, text=x, as_user=True)
					df = cd.Data_Tool_General(True,False)
					df, Width = df_ima.Order_Df(df, ['Status', 'MFG #', 'TestCell'], [True, True, True])
					df = cd.Filter_Data(df, ['MT'], [['9117', '9080', '9119', '9179']])
					df = cd.Summary(df)
					
					if df.shape[0] > 0:
						if len(ListComms4) > 0:
							if "PNG" in ListComms4:	
								Send_Sumarry(df, "Brazos_Summary", "png",Path,"Sumario de Brazos", "There you go " + Real_Name)	
							elif "PDF" in ListComms4:
								Send_Sumarry(df, "Brazos_Summary", "pdf",Path,"Sumario de Brazos", "There you go " + Real_Name)
							elif "XLSX" in ListComms4 or "EXCEL" in ListComms4:
								Send_Sumarry(df, "Brazos_Summary", "xlsx",Path,"Sumario de Brazos", "There you go " + Real_Name)
							
						else:
							Send_Sumarry(df, "Brazos_Summary", "png",Path,"Sumario de Brazos", "There you go " + Real_Name)
					else:
						Slack_Client.api_call("chat.postMessage", channel=channel, text="El estatus deseado no contiene ningun elemento", as_user=True)

				elif i.upper() == "ALPINE":
					for x in Output:
							Slack_Client.api_call("chat.postMessage", channel=channel, text=x, as_user=True)
					df = cd.Data_Tool_General(True,False)
					df, Width = df_ima.Order_Df(df, ['Status', 'MFG #', 'TestCell'], [True, True, True])
					df = cd.Filter_Data(df, ['MT'], [['8408']])
					df = cd.Summary(df)
					
					if df.shape[0] > 0:
						if len(ListComms4) > 0:
							if "PNG" in ListComms4:	
								Send_Sumarry(df, "Alpine_Summary", "png",Path,"Sumario de Alpine", "There you go " + Real_Name)	
							elif "PDF" in ListComms4:
								Send_Sumarry(df, "Alpine_Summary", "pdf",Path,"Sumario de Alpine", "There you go " + Real_Name)
							elif "XLSX" in ListComms4 or "EXCEL" in ListComms4:
								Send_Sumarry(df, "Alpine_Summary", "xlsx",Path,"Sumario de Alpine", "There you go " + Real_Name)
							
						else:
							Send_Sumarry(df, "Alpine_Summary", "png",Path,"Sumario de Alpine", "There you go " + Real_Name)
					else:
						Slack_Client.api_call("chat.postMessage", channel=channel, text="El estatus deseado no contiene ningun elemento", as_user=True)

				elif i.upper() == "ZZ":
					for x in Output:
							Slack_Client.api_call("chat.postMessage", channel=channel, text=x, as_user=True)
					df = cd.Data_Tool_General(True,False)
					df, Width = df_ima.Order_Df(df, ['Status', 'MFG #', 'TestCell'], [True, True, True])
					df = cd.Filter_Data(df, ['MT'], [['9008', '9009']])
					df = cd.Summary(df)
					
					if df.shape[0] > 0:
						if len(ListComms4) > 0:
							if "PNG" in ListComms4:	
								Send_Sumarry(df, "ZZ_Summary", "png",Path,"Sumario de ZZ", "There you go " + Real_Name)	
							elif "PDF" in ListComms4:
								Send_Sumarry(df, "ZZ_Summary", "pdf",Path,"Sumario de ZZ", "There you go " + Real_Name)
							elif "XLSX" in ListComms4 or "EXCEL" in ListComms4:
								Send_Sumarry(df, "ZZ_Summary", "xlsx",Path,"Sumario de ZZ", "There you go " + Real_Name)
							
						else:
							Send_Sumarry(df, "ZZ_Summary", "png",Path,"Sumarion de ZZ", "There you go " + Real_Name)
					else:
						Slack_Client.api_call("chat.postMessage", channel=channel, text="El estatus deseado no contiene ningun elemento", as_user=True)

				elif i.upper() == "TULETA":
					for x in Output:
							Slack_Client.api_call("chat.postMessage", channel=channel, text=x, as_user=True)
					df = cd.Data_Tool_General(True,False)
					df, Width = df_ima.Order_Df(df, ['Status', 'MFG #', 'TestCell'], [True, True, True])
					df = cd.Filter_Data(df, ['MT'], [['8286', '8284']])
					df = cd.Summary(df)
					
					if df.shape[0] > 0:
						if len(ListComms4) > 0:
							if "PNG" in ListComms4:	
								Send_Sumarry(df, "Tuleta_Summary", "png",Path,"Sumario de Tuletas", "There you go " + Real_Name)	
							elif "PDF" in ListComms4:
								Send_Sumarry(df, "Tuleta_Summary", "pdf",Path,"Sumario de Tuletas", "There you go " + Real_Name)
							elif "XLSX" in ListComms4 or "EXCEL" in ListComms4:
								Send_Sumarry(df, "Tuleta_Summary", "xlsx",Path,"Sumario de Tuletas", "There you go " + Real_Name)
							
						else:
							Send_Sumarry(df, "Tuleta_Summary", "png",Path,"Sumarion de Tuletas", "There you go " + Real_Name)
					else:
						Slack_Client.api_call("chat.postMessage", channel=channel, text="El estatus deseado no contiene ningun elemento", as_user=True)
				elif i.upper() == "EASTWOOD" or i.upper() == "SOLUTION":
					for x in Output:
							Slack_Client.api_call("chat.postMessage", channel=channel, text=x, as_user=True)
					df = cd.Data_Tool_General(True,False)
					df, Width = df_ima.Order_Df(df, ['Status', 'MFG #', 'TestCell'], [True, True, True])
					df = cd.Filter_Data(df, ['MT'], [['5148', '8247', '5104']])
					df = cd.Summary(df)
					
					if df.shape[0] > 0:
						if len(ListComms4) > 0:
							if "PNG" in ListComms4:	
								Send_Sumarry(df, "Solution_Summary", "png",Path,"Sumario de Solutions", "There you go " + Real_Name)	
							elif "PDF" in ListComms4:
								Send_Sumarry(df, "Solution_Summary", "pdf",Path,"Sumario de Solutions", "There you go " + Real_Name)
							elif "XLSX" in ListComms4 or "EXCEL" in ListComms4:
								Send_Sumarry(df, "Solution_Summary", "xlsx",Path,"Sumario de Solution", "There you go " + Real_Name)
							
						else:
							Send_Sumarry(df, "Solution_Summary", "png",Path,"Sumarion de Solutions", "There you go " + Real_Name)
					else:
						Slack_Client.api_call("chat.postMessage", channel=channel, text="El estatus deseado no contiene ningun elemento", as_user=True)

				elif i.upper() == "WITHERSPOON":
					for x in Output:
							Slack_Client.api_call("chat.postMessage", channel=channel, text=x, as_user=True)
					df = cd.Data_Tool_General(True,False)
					df, Width = df_ima.Order_Df(df, ['Status', 'MFG #', 'TestCell'], [True, True, True])
					df = cd.Filter_Data(df, ['MT'], [['8335']])
					df = cd.Summary(df)
					
					if df.shape[0] > 0:
						if len(ListComms4) > 0:
							if "PNG" in ListComms4:	
								Send_Sumarry(df, "Witherspoon_Summary", "png",Path,"Sumario de Witherspoon", "There you go " + Real_Name)	
							elif "PDF" in ListComms4:
								Send_Sumarry(df, "Witherspoon_Summary", "pdf",Path,"Sumario de Witherspoon", "There you go " + Real_Name)
							elif "XLSX" in ListComms4 or "EXCEL" in ListComms4:
								Send_Sumarry(df, "Witherspoon_Summary", "xlsx",Path,"Sumario de Witherspoon", "There you go " + Real_Name)
							
						else:
							Send_Sumarry(df, "Witherspoon_Summary", "png",Path,"Sumarion de Witherspoon", "There you go " + Real_Name)
					else:
						Slack_Client.api_call("chat.postMessage", channel=channel, text="El estatus deseado no contiene ningun elemento", as_user=True)
				
				#Missing criticas cause I need to make the code to the lists
				elif i.upper() == "TCO":
					for x in Output:
							Slack_Client.api_call("chat.postMessage", channel=channel, text=x, as_user=True)
					Tcos = Generate_TCO_List(20)
					df = cd.Data_Tool_General(True,False)
					df, Width = df_ima.Order_Df(df, ['Status', 'MFG #', 'TestCell'], [True, True, True])
					df = cd.Filter_Data(df, ['TCO'], [Tcos])
					df = cd.Remove_Yorders(df)
					df = cd.Summary(df)
					
					if df.shape[0] > 0:
						if len(ListComms4) > 0:
							if "PNG" in ListComms4:	
								Send_Sumarry(df, "TCO_Summary", "png",Path,"Sumario de TCO", "There you go " + Real_Name)	
							elif "PDF" in ListComms4:
								Send_Sumarry(df, "TCO_Summary", "pdf",Path,"Sumario de TCO", "There you go " + Real_Name)
							elif "XLSX" in ListComms4 or "EXCEL" in ListComms4:
								Send_Sumarry(df, "TCO_Summary", "xlsx",Path,"Sumario de TCO", "There you go " + Real_Name)
							
						else:
							Send_Sumarry(df, "TCO_Summary", "png",Path,"Sumarion de TCO", "There you go " + Real_Name)
					else:
						Slack_Client.api_call("chat.postMessage", channel=channel, text="El estatus deseado no contiene ningun elemento", as_user=True)

				elif i.upper() == "VENTANA":
					for x in Output:
							Slack_Client.api_call("chat.postMessage", channel=channel, text=x, as_user=True)
					Window = Generate_Window_List(7)
					df = cd.Data_Tool_General(True,False)
					df, Width = df_ima.Order_Df(df, ['Status', 'MFG #', 'TestCell'], [True, True, True])
					df = cd.Filter_Data(df, ['Ship Date'], [Window])
					df = cd.Remove_Yorders(df)
					df = cd.Summary(df)
				
					if df.shape[0] > 0:
						if len(ListComms4) > 0:
							if "PNG" in ListComms4:	
								Send_Sumarry(df, "Ventana_Summary", "png",Path,"Sumario de Ventana", "There you go " + Real_Name)	
							elif "PDF" in ListComms4:
								Send_Sumarry(df, "Ventana_Summary", "pdf",Path,"Sumario de Ventana", "There you go " + Real_Name)
							elif "XLSX" in ListComms4 or "EXCEL" in ListComms4:
								Send_Sumarry(df, "Ventana_Summary", "xlsx",Path,"Sumario de Ventana", "There you go " + Real_Name)
							
						else:
							Send_Sumarry(df, "Ventana_Summary", "png",Path,"Sumarion de Ventana", "There you go " + Real_Name)
					else:
						Slack_Client.api_call("chat.postMessage", channel=channel, text="El estatus deseado no contiene ningun elemento", as_user=True)

				elif i.upper() == "TOOL":
					for x in Output:
							Slack_Client.api_call("chat.postMessage", channel=channel, text=x, as_user=True)
					df = cd.Data_Tool_General(False,True)
					df = cd.Remove_Yorders(df)
					df = cd.Summary(df)
			
					if df.shape[0] > 0:
						if len(ListComms4) > 0:
							if "PNG" in ListComms4:	
								Send_Sumarry(df, "Tool_Summary", "png",Path,"Sumario de Tool", "There you go " + Real_Name)	
							elif "PDF" in ListComms4:
								Send_Sumarry(df, "Ventana_Summary", "pdf",Path,"Sumario de Tool", "There you go " + Real_Name)
							elif "XLSX" in ListComms4 or "EXCEL" in ListComms4:
								Send_Sumarry(df, "Ventana_Summary", "xlsx",Path,"Sumario de Tool", "There you go " + Real_Name)
							
						else:
							Send_Sumarry(df, "Ventana_Summary", "png",Path,"Sumarion de Tool", "There you go " + Real_Name)
					else:
						Slack_Client.api_call("chat.postMessage", channel=channel, text="El estatus deseado no contiene ningun elemento", as_user=True)

		elif ListComms1[0].upper() == "ELIMINAR":
			for i in ListComms2:
				if i.upper() == "LISTA":
					Delete_List(ListComms2)
					#Slack_Client.api_call("chat.postMessage", channel=channel, text=ListComms2, as_user=True)

			Slack_Client.api_call("chat.postMessage", channel=channel, text="Quieren eliminar una lista", as_user=True)
		#Help
		elif ListComms1[0].upper() == "HELP" or ListComms1[0].upper() == "AYUDA":
			#Slack_Client.api_call("chat.postMessage", channel=channel, text=i, as_user=True)
			for x in Output:
							Slack_Client.api_call("chat.postMessage", channel=channel, text=x, as_user=True)
			
		elif (ListComms1[0].upper() not in Intents):
			for x in Output:
				Slack_Client.api_call("chat.postMessage", channel=channel, text=x, as_user=True)
	
	elif (len(ListComms1) == 0):
			for x in Output:
				Slack_Client.api_call("chat.postMessage", channel=channel, text=x, as_user=True)

	print (ListComms1)
	print (len(ListComms1))				
	print ("Terminando Interpret_Command...")

def Send_File(df, Name, Ext, Path, Title, Text, ColSort, OrdSort):
	print ("Sending a file...")
	#Slack_Client.api_call("chat.postMessage", channel=channel, text="Procesando estatus general, espera  un momento por favor...", as_user=True)
	df = df_ima.Generate_Table(False, Name, df, Ext	, ColSort,OrdSort)
	Slack_Client.api_call('files.upload', channels=channel, filename=Name + "." + Ext, file=open(Path + "/" + Name + "." + Ext, 'rb'), initial_comment = Text	, title= Title	)

def Send_Sumarry(df, Name, Ext, Path, Title, Text):
	print ("Sending a file...")
	#Slack_Client.api_call("chat.postMessage", channel=channel, text="Procesando estatus general, espera  un momento por favor...", as_user=True)
	#df = df_ima.Generate_Table(False, Name, df, Ext	, ColSort,OrdSort)
	df_ima.Generate_Table_Summary(df, Name, Ext)
	Slack_Client.api_call('files.upload', channels=channel, filename=Name + "." + Ext, file=open(Path + "/" + Name + "." + Ext, 'rb'), initial_comment = Text	, title= Title	)

def Generate_TCO_List(Hour):
	hours = list(range(Hour,1000))
	minutes = list(range(60))
	data = []
	for x in hours:
		for y in minutes:
			data.append(str(x).zfill(3)  + ":" + str(y).zfill(2))
	return data

def Generate_Window_List(Days):
	dates = [d.strftime('%Y-%m-%d') for d in pd.date_range(pd.datetime.today(), periods=Days)]
	return dates

def Create_List(ListComms5):
	if ListComms5[0].upper() not in CommandsLvl2: 
		CommandsLvl2.append(ListComms5[0].upper())
	
	file = open(ListComms5[0] + ".bot","w") 
	[file.write(x+"\n") for x in ListComms5[1:]]
	#else:

	file.close()

	#Slack_Client.api_call("chat.postMessage", channel=channel, text=CommandsLvl2, as_user=True)

def Delete_List(ListComms2):
	[os.remove(x + ".bot") for x in ListComms2[1:] if os.path.isfile(x + ".bot")]
	[CommandsLvl2.remove(x) for x in ListComms2[1:] if x in CommandsLvl2]
	

def Read_List(Name):
	file = open(Name + ".bot","r")
	systems = file.read()#.split()
	systems = systems.replace("\n", ", ")
	systems = systems.replace(" ", "")
	systems = systems.split(",")
	systems = systems[:-1]
	#Slack_Client.api_call("chat.postMessage", channel=channel, text=systems, as_user=True)
	return systems 

def parse_slack_output(Slack_Rtm_Output):
	"""
		The Slack Real Time Messaging API is an events firehose.
		this parsing function returns None unless a message is
		directed at the Bot, based on its ID.
	"""
	output_list = Slack_Rtm_Output
	if output_list and len(output_list) > 0:
		for output in output_list:
			if output and 'text' in output and At_Bot in output['text']:
				# return text after the @ mention, whitespace removed
				real_name = Get_Name (output['user'])
				return output['text'].split(At_Bot)[1].strip().lower(), \
					   output['channel'], real_name
	return None, None, None

def Check_Lists():
	Name = ""
	for File in os.listdir("."):
		if File.endswith(".bot"):
			Name = File.split(".")
			Name = Name[0]
			CommandsLvl2.append(Name.upper()) 


if __name__ == "__main__":
	READ_WEBSOCKET_DELAY = 1 # 1 second delay between reading from firehose
	Check_Lists()
	if Slack_Client.rtm_connect():
		print("StarterBot connected and running!")

		while True:
			command, channel, real_name = parse_slack_output(Slack_Client.rtm_read())
			
			if command and channel:
				if real_name != 'qrytestbot':
					Watson_to_Bot(command,channel, real_name)
				#handle_command(command, channel, real_name)
			time.sleep(READ_WEBSOCKET_DELAY)
	else:
		print("Connection failed. Invalid Slack token or bot ID?")

