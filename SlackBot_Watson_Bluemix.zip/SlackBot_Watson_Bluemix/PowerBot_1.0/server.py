from __future__ import print_function
import json
from watson_developer_cloud import ConversationV1
import os
import sys
import time
from slackclient import SlackClient
import csv_data as cd
import df_ima
import pandas as pd

#SLACK information
Token = "xoxb-301657063959-c4VHT8yXJKa0K9HERMeYGEMO" #Oficial token 
#Token = "xoxb-267672714900-JTqqAcHQpYY51HoRlsOP6UBs"#Test token
Slack_Client = SlackClient(Token)
Bot_Name = 'powertestbot' #Oficial name
#Bot_Name = 'qrytestbot' #Test name

#Watson information
conversation = ConversationV1(
	username='38a164e2-0e16-4a45-83de-57504f915318',
	password='RlXgqcM0zAwz',
	version='2017-05-26')

# replace with your own workspace_id
workspace_id = '4e05ead6-9cb6-4cb1-b893-9bc74af1a0e4'
if os.getenv("conversation_workspace_id") is not None:
	workspace_id = os.getenv("conversation_workspace_id")

def Get_ID(Name):
	"""
		Get the SLack ID with the user name
	"""
	api_call = Slack_Client.api_call("users.list")
	if api_call.get('ok'):
		# retrieve all users so we can find our bot
		users = api_call.get('members')
		for user in users:
			if 'name' in user and user.get('name') == Name:
				return user.get('id')
	return False

#Constants
At_Bot = "<@" + Get_ID(Bot_Name) + ">"

def Get_Name(user_name):
	"""
	Get the name of who make a request from Slack.
	"""
	api_call = Slack_Client.api_call("users.list")
	if api_call.get('ok'):
		users = api_call.get('members')
		for user in users:
			if user ['id'] == user_name:
				return user['real_name']
	return False


def Watson_to_Bot(Input,Channel, Real_Name):
	"""
	Send the input from Slack to Watson and classify the Watson output
	"""
	ListComms1 = []
	ListComms2 = []
	ListComms3 = []
	ListComms4 = []
	ListComms5 = []
	Output = []
	Input_R = []
	Systems = []
	Input = Input.upper()
	List_Name = ""

	if "\n" in Input:
		Input = Input.split("\n")
		Input_R = Input[1:]
		Input = Input[0]
		 
	response = conversation.message(workspace_id=workspace_id, input={
	'text': Input})
	
	data = json.loads(json.dumps(response, indent=2))
	print (data) #Dejo esto para validacion quitar despues
	
	for x in data['intents']:
		ListComms1.append(x['intent'].upper())
	
	if len(data['entities']) == 0:
		List_Name = Input.split('"')[1::2]
		Systems = Input_R

	for x in data['entities']:
		if x['entity'] == 'Producto':
			ListComms2.append(x['value'].upper())
			if x['value'] == 'Lista':
				List_Name = Input.split('"')[1::2]
				Systems = Input_R
		elif x['entity'] == 'Formato':
			ListComms4.append(x['value'].upper())
	
	for x in data['output']['text']:
		Output.append(x)
	
	Interpret_Command(ListComms1, ListComms2, ListComms3, ListComms4, ListComms5, Real_Name, List_Name, Systems, Output)
	return True


def Interpret_Command(ListComms1, ListComms2, ListComms3, ListComms4, ListComms5, Real_Name, List_Name, Systems, Output):
	"""
	Execute the commands from Watson
	"""
	print ("Ejecutando Interpret_Command...")
	Intents = ["ESTATUS", "GENERAR", "SUMARIO"]
	#Detect the OS to use the correct command
	if sys.platform == "win32":
		Path = os.path.dirname(__file__)
	elif sys.platform == "linux":
		Path = os.path.dirname(os.path.realpath(__file__))
	elif sys.platform == "linux2":
		Path = os.path.dirname(os.path.realpath(__file__)) 
	
	SQL_String = ""
	
	if len(ListComms1) > 0:
		#Status section
		if ListComms1[0].upper() == "ESTATUS":
			if len(ListComms2) > 0:
				for i in ListComms2:
					#General status
					if i.upper() == "GENERAL":
						for x in Output:
							Slack_Client.api_call("chat.postMessage", channel=channel, text=x, as_user=True)
						
						df = cd.Data_Tool_General(False,False)
						df = cd.Remove_Yorders(df)
						if df.shape[0] > 0:
							if len(ListComms4) > 0:
								if "PNG" in ListComms4:	
									Send_File(df, "General_Status", "png",Path,"General Status", "There you go " + Real_Name, ['Status', 'MFG #', 'TestCell'], [True, True, True])		
								elif "PDF" in ListComms4:
									Send_File(df, "General_Status", "pdf",Path,"General Status", "There you go " + Real_Name, ['Status', 'MFG #', 'TestCell'], [True, True, True])
								elif "XLSX" in ListComms4:
									Send_File(df, "General_Status", "xlsx",Path,"General Status", "There you go " + Real_Name, ['Status', 'MFG #', 'TestCell'], [True, True, True])		
							else:
								Send_File(df, "General_Status", "png",Path,"", "There you go " + Real_Name, ['Status', 'MFG #', 'TestCell'], [True, True, True])
						else:
							Slack_Client.api_call("chat.postMessage", channel=channel, text="The desired sumarry does not contain any element :disappointed:", as_user=True)
					
					#Brazos status
					elif i.upper() == "BRAZOS":
						for x in Output:
							Slack_Client.api_call("chat.postMessage", channel=channel, text=x, as_user=True)
						df = cd.Data_Tool_General(True,False)
						df, Width = df_ima.Order_Df(df, ['Status', 'MFG #', 'TestCell'], [True, True, True])
						df = cd.Filter_Data(df, ['MT'], [['9117', '9080', '9119', '9179']])
						if df.shape[0] > 0:
							if len(ListComms4) > 0:
								if "PNG" in ListComms4:	
									Send_File(df, "Brazos_Status", "png",Path,"Brazos Status", "There you go " + Real_Name, ['Status', 'MFG #', 'TestCell'], [True, True, True])		
								elif "PDF" in ListComms4:
									Send_File(df, "Brazos_Status", "pdf",Path,"Brazos Status", "There you go " + Real_Name, ['Status', 'MFG #', 'TestCell'], [True, True, True])	
								elif "XLSX" in ListComms4:
									Send_File(df, "Brazos_Status", "xlsx",Path,"Brazos Status", "There you go " + Real_Name, ['Status', 'MFG #', 'TestCell'], [True, True, True])
							else:
								Send_File(df, "Brazos_Status", "png",Path,"Brazos Status", "There you go " + Real_Name, ['Status', 'MFG #', 'TestCell'], [True, True, True])
						else:
							Slack_Client.api_call("chat.postMessage", channel=channel, text="The desired status does not contain any element :disappointed:", as_user=True)
					
					#Alpine status
					elif i.upper() == "ALPINE":
						for x in Output:
							Slack_Client.api_call("chat.postMessage", channel=channel, text=x, as_user=True)
						df = cd.Data_Tool_General(True,False)
						df, Width = df_ima.Order_Df(df, ['Status', 'MFG #', 'TestCell'], [True, True, True])
						df = cd.Filter_Data(df, ['MT'], [['8408']])
						if df.shape[0] > 0:
							if len(ListComms4) > 0:
								if "PNG" in ListComms4:	
									Send_File(df, "Alpine_Status", "png",Path,"Alpine Status", "There you go " + Real_Name, ['Status', 'MFG #', 'TestCell'], [True, True, True])		
								elif "PDF" in ListComms4:
									Send_File(df, "Alpine_Status", "pdf",Path,"Alpine Status", "There you go " + Real_Name, ['Status', 'MFG #', 'TestCell'], [True, True, True])
								elif "XLSX" in ListComms4:
									Send_File(df, "Alpine_Status", "xlsx",Path,"Alpine Status", "There you go " + Real_Name, ['Status', 'MFG #', 'TestCell'], [True, True, True])	
							else:
								Send_File(df, "Alpine_Status", "png",Path,"Alpine Status", "There you go " + Real_Name, ['Status', 'MFG #', 'TestCell'], [True, True, True])
						else:
							Slack_Client.api_call("chat.postMessage", channel=channel, text="The desired status does not contain any element :disappointed:", as_user=True)
					
					#ZZ status
					elif i.upper() == "ZZ":
						for x in Output:
							Slack_Client.api_call("chat.postMessage", channel=channel, text=x, as_user=True)
						df = cd.Data_Tool_General(True,False)
						df, Width = df_ima.Order_Df(df, ['Status', 'MFG #', 'TestCell'], [True, True, True])
						df = cd.Filter_Data(df, ['MT'], [['9008', '9009', '9223']])
						if df.shape[0] > 0:
							if len(ListComms4) > 0:
								if "PNG" in ListComms4:	
									Send_File(df, "ZZ_Status", "png",Path,"ZZ Status", "There you go " + Real_Name, ['Status', 'MFG #', 'TestCell'], [True, True, True])		
								elif "PDF" in ListComms4:
									Send_File(df, "ZZ_Status", "pdf",Path,"ZZ Status", "There you go " + Real_Name, ['Status', 'MFG #', 'TestCell'], [True, True, True])
								elif "XLSX" in ListComms4:
									Send_File(df, "ZZ_Status", "xlsx",Path,"ZZ Status", "There you go " + Real_Name, ['Status', 'MFG #', 'TestCell'], [True, True, True])	
							else:
								Send_File(df, "ZZ_Status", "png",Path,"ZZ Status", "There you go " + Real_Name, ['Status', 'MFG #', 'TestCell'], [True, True, True])
						else:
							Slack_Client.api_call("chat.postMessage", channel=channel, text="The desired status does not contain any element :disappointed:", as_user=True)
					
					#Tuleta status
					elif i.upper() == "TULETA":
						for x in Output:
							Slack_Client.api_call("chat.postMessage", channel=channel, text=x, as_user=True)
						df = cd.Data_Tool_General(True,False)
						df, Width = df_ima.Order_Df(df, ['Status', 'MFG #', 'TestCell'], [True, True, True])
						df = cd.Filter_Data(df, ['MT'], [['8286', '8284']])
						if df.shape[0] > 0:
							if len(ListComms4) > 0:
								if "PNG" in ListComms4:	
									Send_File(df, "Tuleta_Status", "png",Path,"Tuleta Status", "There you go " + Real_Name, ['Status', 'MFG #', 'TestCell'], [True, True, True])		
								elif "PDF" in ListComms4:
									Send_File(df, "Tuleta_Status", "pdf",Path,"Tuleta Status", "There you go " + Real_Name, ['Status', 'MFG #', 'TestCell'], [True, True, True])
								elif "XLSX" in ListComms4:
									Send_File(df, "Tuleta_Status", "xlsx",Path,"Tuleta Status", "There you go " + Real_Name, ['Status', 'MFG #', 'TestCell'], [True, True, True])	
							else:
								Send_File(df, "Tuleta_Status", "png",Path,"Tuleta Status", "There you go " + Real_Name, ['Status', 'MFG #', 'TestCell'], [True, True, True])
						else:
							Slack_Client.api_call("chat.postMessage", channel=channel, text="The desired status does not contain any element :disappointed:", as_user=True)
					
					#Eastwood status
					elif i.upper() == "SOLUTION":
						for x in Output:
							Slack_Client.api_call("chat.postMessage", channel=channel, text=x, as_user=True)
						df = cd.Data_Tool_General(True,False)
						df, Width = df_ima.Order_Df(df, ['Status', 'MFG #', 'TestCell'], [True, True, True])
						df = cd.Filter_Data(df, ['MT'], [['5148', '8247', '5104']])
						if df.shape[0] > 0:
							if len(ListComms4) > 0:
								if "PNG" in ListComms4:	
									Send_File(df, "Solutions_Status", "png",Path,"Solutions Status", "There you go " + Real_Name, ['Status', 'MFG #', 'TestCell'], [True, True, True])		
								elif "PDF" in ListComms4:
									Send_File(df, "Solutions_Status", "pdf",Path,"Solutions Status", "There you go " + Real_Name,['Status', 'MFG #', 'TestCell'], [True, True, True])	
								elif "XLSX" in ListComms4:
									Send_File(df, "Solutions_Status", "xlsx",Path,"Solutions Status", "There you go " + Real_Name, ['Status', 'MFG #', 'TestCell'], [True, True, True])
							else:
								Send_File(df, "Solutions_Status", "png",Path,"Solutions Status", "There you go " + Real_Name,['Status', 'MFG #', 'TestCell'], [True, True, True])
						else:
							Slack_Client.api_call("chat.postMessage", channel=channel, text="The desired status does not contain any element :disappointed:", as_user=True)
					
					#Witherspoon status
					elif i.upper() == "WITHERSPOON":
						for x in Output:
							Slack_Client.api_call("chat.postMessage", channel=channel, text=x, as_user=True)
						df = cd.Data_Tool_General(True,False)
						df, Width = df_ima.Order_Df(df, ['Status', 'MFG #', 'TestCell'], [True, True, True])
						df = cd.Filter_Data(df, ['MT'], [['8335']])
						if df.shape[0] > 0:
							if len(ListComms4) > 0:
								if "PNG" in ListComms4:	
									Send_File(df, "Witherspoon_Status", "png",Path,"Witherspoon Status", "There you go " + Real_Name, ['Status', 'MFG #', 'TestCell'], [True, True, True])		
								elif "PDF" in ListComms4:
									Send_File(df, "Witherspoon_Status", "pdf",Path,"Witherspoon Status", "There you go " + Real_Name, ['Status', 'MFG #', 'TestCell'], [True, True, True])	
								elif "XLSX" in ListComms4:
									Send_File(df, "Witherspoon_Status", "xlsx",Path,"Witherspoon Status", "There you go " + Real_Name, ['Status', 'MFG #', 'TestCell'], [True, True, True])	
							else:
								Send_File(df, "Witherspoon_Status", "png",Path,"Witherspoon Status", "There you go " + Real_Name, ['Status', 'MFG #', 'TestCell'], [True, True, True])
						else:
							Slack_Client.api_call("chat.postMessage", channel=channel, text="The desired status does not contain any element :disappointed:", as_user=True)
					
					#TCO status
					elif i.upper() == "TCO":
						for x in Output:
							Slack_Client.api_call("chat.postMessage", channel=channel, text=x, as_user=True)
						Tcos = Generate_TCO_List(20)
						df = cd.Data_Tool_General(True,False)
						df, Width = df_ima.Order_Df(df, ['Status', 'MFG #', 'TestCell'], [True, True, True])
						df = cd.Filter_Data(df, ['TCO'], [Tcos])
						df = cd.Remove_Yorders(df)
						if df.shape[0] > 0:
							if len(ListComms4) > 0:
								if "PNG" in ListComms4:	
									Send_File(df, "TCO_Status", "png",Path,"TCO Status", "There you go " + Real_Name, ['TCO'], [False])		
								elif "PDF" in ListComms4:
									Send_File(df, "TCO_Status", "pdf",Path,"TCO Status", "There you go " + Real_Name, ['TCO'], [False])
								elif "XLSX" in ListComms4:
									Send_File(df, "TCO_Status", "xlsx",Path,"TCO Status", "There you go " + Real_Name, ['TCO'], [False])	
							else:
								Send_File(df, "TCO_Status", "png",Path,"TCO Status", "There you go " + Real_Name, ['TCO'], [False])
						else:
							Slack_Client.api_call("chat.postMessage", channel=channel, text="The desired status does not contain any element :disappointed:", as_user=True)
					
					#Window status
					elif i.upper() == "VENTANA":
						for x in Output:
							Slack_Client.api_call("chat.postMessage", channel=channel, text=x, as_user=True)
						Window = Generate_Window_List(7)
						df = cd.Data_Tool_General(True,False)
						df, Width = df_ima.Order_Df(df, ['Status', 'MFG #', 'TestCell'], [True, True, True])
						df = cd.Filter_Data(df, ['Ship Date'], [Window])
						df = cd.Remove_Yorders(df)
						if df.shape[0] > 0:
							if len(ListComms4) > 0:
								if "PNG" in ListComms4:	
									Send_File(df, "Window_Status", "png",Path,"Window Status", "There you go " + Real_Name, ['Ship Date'], [True])		
								elif "PDF" in ListComms4:
									Send_File(df, "Window_Status", "pdf",Path,"Window Status", "There you go " + Real_Name, ['Ship Date'], [True])
								elif "XLSX" in ListComms4:
									Send_File(df, "Window_Status", "xlsx",Path,"Window Status", "There you go " + Real_Name, ['Ship Date'], [False])	
							else:
								Send_File(df, "Window_Status", "png",Path,"Window Status", "There you go " + Real_Name, ['Ship Date'], [True])
						else:
							Slack_Client.api_call("chat.postMessage", channel=channel, text="The desired status does not contain any element :disappointed:", as_user=True)
					
					#Tool status
					elif i.upper() == "TOOL":
						for x in Output:
							Slack_Client.api_call("chat.postMessage", channel=channel, text=x, as_user=True)
						df = cd.Data_Tool_General(False,True)
						df = cd.Remove_Yorders(df)
						if df.shape[0] > 0:
							if len(ListComms4) > 0:
								if "PNG" in ListComms4:	
									Send_File(df, "Tool_Status", "png",Path,"Tool Status", "There you go " + Real_Name, ['Status', 'MFG #', 'TestCell'], [True, True, True])		
								elif "PDF" in ListComms4:
									Send_File(df, "Tool_Status", "pdf",Path,"Tool Status", "There you go " + Real_Name, ['Status', 'MFG #', 'TestCell'], [True, True, True])
								elif "XLSX" in ListComms4s:
									Send_File(df, "Tool_Status", "xlsx",Path,"Tool Status", "There you go " + Real_Name, ['Status', 'MFG #', 'TestCell'], [True, True, True])		
							else:
								Send_File(df, "Tool_Status", "png",Path,"Tool Status", "There you go " + Real_Name, ['Status', 'MFG #', 'TestCell'], [True, True, True])
						else:
							Slack_Client.api_call("chat.postMessage", channel=channel, text="The desired status does not contain any element :disappointed:", as_user=True)
					
					#Criticas status
					elif i.upper() == "CRITICAS":
						#print (os.listdir(Path))
						Systems = Read_List("CRITICAS")
						if Systems != False:	
							for x in Output:
								Slack_Client.api_call("chat.postMessage", channel=channel, text=x, as_user=True)
							
							df = cd.Data_List(True,Systems)
							df, Width = df_ima.Order_Df(df, ['Status', 'MFG #', 'TestCell'], [True, True, True])
							
							if df.shape[0] > 0:
								if len(ListComms4) > 0:
									if "PNG" in ListComms4:	
										Send_File(df, i.upper() + "_Status", "png",Path,i.upper() + " Status", "There you go " + Real_Name, ['Status', 'MFG #', 'TestCell'], [True, True, True])		
									elif "PDF" in ListComms4:
										Send_File(df, i.upper() + "_Status", "pdf",Path,i.upper() + " Status", "There you go " + Real_Name, ['Status', 'MFG #', 'TestCell'], [True, True, True])	
									elif "XLSX" in ListComms4:
										Send_File(df, i.upper() + "_Status", "xlsx",Path,i.upper() + " Status", "There you go " + Real_Name, ['Status', 'MFG #', 'TestCell'], [True, True, True])	
								else:
									Send_File(df, i.upper() + "_Status", "png",Path,i.upper() + " Status", "There you go " + Real_Name, ['Status', 'MFG #', 'TestCell'], [True, True, True])
							else:
								Slack_Client.api_call("chat.postMessage", channel=channel, text="The desired status does not contain any element :disappointed:", as_user=True)					
						else:
							Slack_Client.api_call("chat.postMessage", channel=channel, text="This list has not been created yet  :disappointed:", as_user=True)	

					#Lists status
					elif (i.upper() == "LISTA") and ("CRITICAS" not in ListComms2):
						
						#print (os.listdir(Path))
						Systems = Read_List(List_Name[0].encode("utf-8"))
						if Systems != False:
							for x in Output:
								Slack_Client.api_call("chat.postMessage", channel=channel, text=x, as_user=True)
							#print (Systems)
							df = cd.Data_List(True,Systems)
							df, Width = df_ima.Order_Df(df, ['Status', 'MFG #', 'TestCell'], [True, True, True])
							if df.shape[0] > 0:
								if len(ListComms4) > 0:
									if "PNG" in ListComms4:	
										Send_File(df, List_Name[0] + "_Status", "png",Path,List_Name[0] + " Status", "There you go " + Real_Name, ['Status', 'MFG #', 'TestCell'], [True, True, True])		
									elif "PDF" in ListComms4:
										Send_File(df, List_Name[0] + "_Status", "pdf",Path,List_Name[0] + " Status", "There you go " + Real_Name, ['Status', 'MFG #', 'TestCell'], [True, True, True])	
									elif "XLSX" in ListComms4:
										Send_File(df, List_Name[0] + "_Status", "xlsx",Path,List_Name[0] + " Status", "There you go " + Real_Name, ['Status', 'MFG #', 'TestCell'], [True, True, True])	
								else:
									Send_File(df, List_Name[0] + "_Status", "png",Path,List_Name[0] + " Status", "There you go " + Real_Name, ['Status', 'MFG #', 'TestCell'], [True, True, True])
							else:
								Slack_Client.api_call("chat.postMessage", channel=channel, text="The desired status does not contain any element :disappointed:", as_user=True)
						else:
							Slack_Client.api_call("chat.postMessage", channel=channel, text="The desired list does not exist :disappointed:", as_user=True)		

		#List section	
		elif ListComms1[0].upper() == "GENERAR":
			
			for i in ListComms2:
				if i.upper() == "LISTA":
					for x in Output:
						Slack_Client.api_call("chat.postMessage", channel=channel, text=x, as_user=True)
					if "CRITICAS" in ListComms2:
						Create_List("CRITICAS", Systems)
					else:
						Create_List(List_Name[0], Systems)
		
		#Query section (Just for demostration)				
		elif ListComms1[0].upper() == "CONSULTA":
			for i in ListComms2:
				if i.upper() == "SQL":
					Slack_Client.api_call("chat.postMessage", channel=channel, text="Consulta SQL", as_user=True)

		#Summary section
		elif ListComms1[0].upper() == "SUMARIO":
			for i in ListComms2:
				#General summary
				if i.upper() == "GENERAL":
					for x in Output:
						Slack_Client.api_call("chat.postMessage", channel=channel, text=x, as_user=True)
					df = cd.Data_Tool_General(False,False)
					df = cd.Remove_Yorders(df)
					df = cd.Summary(df)
								
					if df.shape[0] > 0:
						if len(ListComms4) > 0:
							if "PNG" in ListComms4:	
								Send_Summary(df, "General_Summary", "png",Path,"General Summary", "There you go " + Real_Name)	
							elif "PDF" in ListComms4:
								Send_Summary(df, "General_Summary", "pdf",Path,"General Summary", "There you go " + Real_Name)
							elif "XLSX" in ListComms4:
								Send_Summary(df, "General_Summary", "xlsx",Path,"General Summary", "There you go " + Real_Name)
						else:
							Send_Summary(df, "General_Summary", "png",Path,"General Summary", "There you go " + Real_Name)
					#else:
					#	Slack_Client.api_call("chat.postMessage", channel=channel, text="El estatus deseado no contiene ningun elemento", as_user=True)
				
				#Brazos summary
				elif i.upper() == "BRAZOS":
					for x in Output:
						Slack_Client.api_call("chat.postMessage", channel=channel, text=x, as_user=True)
					df = cd.Data_Tool_General(True,False)
					df, Width = df_ima.Order_Df(df, ['Status', 'MFG #', 'TestCell'], [True, True, True])
					df = cd.Filter_Data(df, ['MT'], [['9117', '9080', '9119', '9179']])
					df = cd.Summary(df)
					
					if df.shape[0] > 0:
						if len(ListComms4) > 0:
							if "PNG" in ListComms4:	
								Send_Summary(df, "Brazos_Summary", "png",Path,"Brazos Summary", "There you go " + Real_Name)	
							elif "PDF" in ListComms4:
								Send_Summary(df, "Brazos_Summary", "pdf",Path,"Brazos Summary", "There you go " + Real_Name)
							elif "XLSX" in ListComms4:
								Send_Summary(df, "Brazos_Summary", "xlsx",Path,"Brazos Summary", "There you go " + Real_Name)
							
						else:
							Send_Summary(df, "Brazos_Summary", "png",Path,"Brazos Summary", "There you go " + Real_Name)
				
				#Alpine summary
				elif i.upper() == "ALPINE":
					for x in Output:
						Slack_Client.api_call("chat.postMessage", channel=channel, text=x, as_user=True)
					df = cd.Data_Tool_General(True,False)
					df, Width = df_ima.Order_Df(df, ['Status', 'MFG #', 'TestCell'], [True, True, True])
					df = cd.Filter_Data(df, ['MT'], [['8408']])
					df = cd.Summary(df)
					
					if df.shape[0] > 0:
						if len(ListComms4) > 0:
							if "PNG" in ListComms4:	
								Send_Summary(df, "Alpine_Summary", "png",Path,"Alpine Summary", "There you go " + Real_Name)	
							elif "PDF" in ListComms4:
								Send_Summary(df, "Alpine_Summary", "pdf",Path,"Alpine Summary", "There you go " + Real_Name)
							elif "XLSX" in ListComms4:
								Send_Summary(df, "Alpine_Summary", "xlsx",Path,"Alpine Summary", "There you go " + Real_Name)
							
						else:
							Send_Summary(df, "Alpine_Summary", "png",Path,"Alpine Summary", "There you go " + Real_Name)
					
				#ZZ summary
				elif i.upper() == "ZZ":
					for x in Output:
						Slack_Client.api_call("chat.postMessage", channel=channel, text=x, as_user=True)
					df = cd.Data_Tool_General(True,False)
					df, Width = df_ima.Order_Df(df, ['Status', 'MFG #', 'TestCell'], [True, True, True])
					df = cd.Filter_Data(df, ['MT'], [['9008', '9009', '9223']])
					df = cd.Summary(df)
					
					if df.shape[0] > 0:
						if len(ListComms4) > 0:
							if "PNG" in ListComms4:	
								Send_Summary(df, "ZZ_Summary", "png",Path,"ZZ Summary", "There you go " + Real_Name)	
							elif "PDF" in ListComms4:
								Send_Summary(df, "ZZ_Summary", "pdf",Path,"ZZ Summary", "There you go " + Real_Name)
							elif "XLSX" in ListComms4:
								Send_Summary(df, "ZZ_Summary", "xlsx",Path,"ZZ Summary", "There you go " + Real_Name)
							
						else:
							Send_Summary(df, "ZZ_Summary", "png",Path,"ZZ Summary", "There you go " + Real_Name)
				
				#Tuleta summary	
				elif i.upper() == "TULETA":
					for x in Output:
						Slack_Client.api_call("chat.postMessage", channel=channel, text=x, as_user=True)
					df = cd.Data_Tool_General(True,False)
					df, Width = df_ima.Order_Df(df, ['Status', 'MFG #', 'TestCell'], [True, True, True])
					df = cd.Filter_Data(df, ['MT'], [['8286', '8284']])
					df = cd.Summary(df)
					
					if df.shape[0] > 0:
						if len(ListComms4) > 0:
							if "PNG" in ListComms4:	
								Send_Summary(df, "Tuleta_Summary", "png",Path,"Tuleta Summary", "There you go " + Real_Name)	
							elif "PDF" in ListComms4:
								Send_Summary(df, "Tuleta_Summary", "pdf",Path,"Tuleta Summary", "There you go " + Real_Name)
							elif "XLSX" in ListComms4:
								Send_Summary(df, "Tuleta_Summary", "xlsx",Path,"Tuleta Summary", "There you go " + Real_Name)
							
						else:
							Send_Summary(df, "Tuleta_Summary", "png",Path,"Tuleta Summary", "There you go " + Real_Name)

				#Solution summary
				elif i.upper() == "SOLUTION":
					for x in Output:
						Slack_Client.api_call("chat.postMessage", channel=channel, text=x, as_user=True)
					df = cd.Data_Tool_General(True,False)
					df, Width = df_ima.Order_Df(df, ['Status', 'MFG #', 'TestCell'], [True, True, True])
					df = cd.Filter_Data(df, ['MT'], [['5148', '8247', '5104']])
					df = cd.Summary(df)
					
					if df.shape[0] > 0:
						if len(ListComms4) > 0:
							if "PNG" in ListComms4:	
								Send_Summary(df, "Solution_Summary", "png",Path,"Solution Summary", "There you go " + Real_Name)	
							elif "PDF" in ListComms4:
								Send_Summary(df, "Solution_Summary", "pdf",Path,"Solution Summary", "There you go " + Real_Name)
							elif "XLSX" in ListComms4:
								Send_Summary(df, "Solution_Summary", "xlsx",Path,"Solution Summary", "There you go " + Real_Name)
							
						else:
							Send_Summary(df, "Solution_Summary", "png",Path,"Solution Summary", "There you go " + Real_Name)
					
				#Witherspoon summary
				elif i.upper() == "WITHERSPOON":
					for x in Output:
						Slack_Client.api_call("chat.postMessage", channel=channel, text=x, as_user=True)
					df = cd.Data_Tool_General(True,False)
					df, Width = df_ima.Order_Df(df, ['Status', 'MFG #', 'TestCell'], [True, True, True])
					df = cd.Filter_Data(df, ['MT'], [['8335']])
					df = cd.Summary(df)
					
					if df.shape[0] > 0:
						if len(ListComms4) > 0:
							if "PNG" in ListComms4:	
								Send_Summary(df, "Witherspoon_Summary", "png",Path,"Witherspoon Summary", "There you go " + Real_Name)	
							elif "PDF" in ListComms4:
								Send_Summary(df, "Witherspoon_Summary", "pdf",Path,"Witherspoon Summary", "There you go " + Real_Name)
							elif "XLSX" in ListComms4:
								Send_Summary(df, "Witherspoon_Summary", "xlsx",Path,"Witherspoon Summary", "There you go " + Real_Name)
						else:
							Send_Summary(df, "Witherspoon_Summary", "png",Path,"Witherspoon Summary", "There you go " + Real_Name)
					
				#TCO summary
				elif i.upper() == "TCO":
					for x in Output:
						Slack_Client.api_call("chat.postMessage", channel=channel, text=x, as_user=True)
					Tcos = Generate_TCO_List(20)
					df = cd.Data_Tool_General(True,False)
					df, Width = df_ima.Order_Df(df, ['Status', 'MFG #', 'TestCell'], [True, True, True])
					df = cd.Filter_Data(df, ['TCO'], [Tcos])
					df = cd.Remove_Yorders(df)
					df = cd.Summary(df)
					
					if df.shape[0] > 0:
						if len(ListComms4) > 0:
							if "PNG" in ListComms4:	
								Send_Summary(df, "TCO_Summary", "png",Path,"TCO Summary", "There you go " + Real_Name)	
							elif "PDF" in ListComms4:
								Send_Summary(df, "TCO_Summary", "pdf",Path,"TCO Summary", "There you go " + Real_Name)
							elif "XLSX" in ListComms4 or "EXCEL" in ListComms4:
								Send_Summary(df, "TCO_Summary", "xlsx",Path,"TCO Summary", "There you go " + Real_Name)
							
						else:
							Send_Summary(df, "TCO_Summary", "png",Path,"TCO Summary", "There you go " + Real_Name)
				
				#Window summary	
				elif i.upper() == "VENTANA":
					for x in Output:
						Slack_Client.api_call("chat.postMessage", channel=channel, text=x, as_user=True)
					Window = Generate_Window_List(7)
					df = cd.Data_Tool_General(True,False)
					df, Width = df_ima.Order_Df(df, ['Status', 'MFG #', 'TestCell'], [True, True, True])
					df = cd.Filter_Data(df, ['Ship Date'], [Window])
					df = cd.Remove_Yorders(df)
					df = cd.Summary(df)
				
					if df.shape[0] > 0:
						if len(ListComms4) > 0:
							if "PNG" in ListComms4:	
								Send_Summary(df, "Window_Summary", "png",Path,"Window Summary", "There you go " + Real_Name)	
							elif "PDF" in ListComms4:
								Send_Summary(df, "Window_Summary", "pdf",Path,"Window Summary", "There you go " + Real_Name)
							elif "XLSX" in ListComms4:
								Send_Summary(df, "Window_Summary", "xlsx",Path,"Window Summary", "There you go " + Real_Name)
							
						else:
							Send_Summary(df, "Window_Summary", "png",Path,"Window Summary", "There you go " + Real_Name)
				
				#Tool summary	
				elif i.upper() == "TOOL":
					for x in Output:
							Slack_Client.api_call("chat.postMessage", channel=channel, text=x, as_user=True)
					df = cd.Data_Tool_General(False,True)
					df = cd.Remove_Yorders(df)
					df = cd.Summary(df)
			
					if df.shape[0] > 0:
						if len(ListComms4) > 0:
							if "PNG" in ListComms4:	
								Send_Summary(df, "Tool_Summary", "png",Path,"Tool Summary", "There you go " + Real_Name)	
							elif "PDF" in ListComms4:
								Send_Summary(df, "Tool_Summary", "pdf",Path,"Tool Summary", "There you go " + Real_Name)
							elif "XLSX" in ListComms4:
								Send_Summary(df, "Tool_Summary", "xlsx",Path,"Tool Summary", "There you go " + Real_Name)
							
						else:
							Send_Summary(df, "Tool_Summary", "png",Path,"Tool Summary", "There you go " + Real_Name)

				#Missing criticas cause I need to make the code to the lists
				
		#Help section
		elif ListComms1[0].upper() == "HELP":
			for x in Output:
				Slack_Client.api_call("chat.postMessage", channel=channel, text=x, as_user=True)
		
		#Default section	
		elif (ListComms1[0].upper() not in Intents):
			for x in Output:
				Slack_Client.api_call("chat.postMessage", channel=channel, text=x, as_user=True)
	
	#Default section	
	elif (len(ListComms1) == 0):
			for x in Output:
				Slack_Client.api_call("chat.postMessage", channel=channel, text=x, as_user=True)

	print ("Terminando Interpret_Command...")

def Send_File(df, Name, Ext, Path, Title, Text, ColSort, OrdSort):
	"""
	Funtion to send a status file
	"""
	print ("Sending a file...")
	df = df_ima.Generate_Table(False, Name, df, Ext	, ColSort,OrdSort)
	Slack_Client.api_call('files.upload', channels=channel, filename=Name + "." + Ext, file=open(Path + "/" + Name + "." + Ext, 'rb'), initial_comment = Text	, title= Title)
	return True

def Send_Summary(df, Name, Ext, Path, Title, Text):
	"""
	Funtion to send a summary file
	"""
	print ("Sending a summary...")
	df_ima.Generate_Table_Summary(df, Name, Ext)
	Slack_Client.api_call('files.upload', channels=channel, filename=Name + "." + Ext, file=open(Path + "/" + Name + "." + Ext, 'rb'), initial_comment = Text	, title= Title)
	return True

def Generate_TCO_List(Hour):
	"""
	Generate a list with the TCO to use like filter
	"""
	hours = list(range(Hour,1000))
	minutes = list(range(60))
	data = []
	for x in hours:
		for y in minutes:
			data.append(str(x).zfill(3)  + ":" + str(y).zfill(2))
	return data

def Generate_Window_List(Days):
	"""
	Generate a list with the dates to use like filter
	"""
	dates = [d.strftime('%Y-%m-%d') for d in pd.date_range(pd.datetime.today(), periods=Days)]
	return dates

def Create_List(Name, Systems):
	"""
	Create a list with the interest systems
	"""
	file = open(Name.encode("utf-8") + ".bot","w") 
	[file.write(x+"\n") for x in Systems]
	file.close()
	return True

def Delete_List(ListComms2):
	"""
	Delete a list, currently it is not in use, maybe I will use this function to delete all the file after use them.
	"""
	[os.remove(x + ".bot") for x in ListComms2[1:] if os.path.isfile(x + ".bot")]
	[CommandsLvl2.remove(x) for x in ListComms2[1:] if x in CommandsLvl2]

def Read_List(Name):
	"""
	Read a file list and return a list with the systems inside 
	"""
	if os.path.exists(Name + ".bot"):
		file = open(Name + ".bot","r")
		systems = file.read()#.split()
		systems = systems.replace("\n", ", ")
		systems = systems.replace(" ", "")
		systems = systems.split(",")
		systems = systems[:-1]
		return systems 
	else:
		return False

def parse_slack_output(Slack_Rtm_Output):
	"""
		The Slack Real Time Messaging API is an events firehose.
		this parsing function returns None unless a message is
		directed at the Bot, based on its ID.
	"""
	output_list = Slack_Rtm_Output
	if output_list and len(output_list) > 0:
		for output in output_list:
			if output and 'text' in output and At_Bot in output['text']:
				# return text after the @ mention, whitespace removed
				real_name = Get_Name (output['user'])
				return output['text'].split(At_Bot)[1].strip().lower(), \
					   output['channel'], real_name
	return None, None, None

def Check_Lists():
	"""
	Check in the begin of the code if there are list and load the name intro the commands
	Not in use 
	"""
	Name = ""
	for File in os.listdir("."):
		if File.endswith(".bot"):
			Name = File.split(".")
			Name = Name[0]
			CommandsLvl2.append(Name.upper()) 


if __name__ == "__main__":
	READ_WEBSOCKET_DELAY = 1
	#Check_Lists()
	if Slack_Client.rtm_connect():
		print(Bot_Name + " connected and running!")

		while True:
			command, channel, real_name = parse_slack_output(Slack_Client.rtm_read())
			
			if command and channel:
				if real_name != Bot_Name:
					Watson_to_Bot(command,channel, real_name)
			time.sleep(READ_WEBSOCKET_DELAY)
	else:
		print("Connection failed. Invalid Slack token or bot ID?")

