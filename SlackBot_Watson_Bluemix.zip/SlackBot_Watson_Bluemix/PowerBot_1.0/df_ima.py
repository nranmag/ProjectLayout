import pandas as pd
import matplotlib.pyplot as plt
#import pandas.plotting.table 
from pandas.tools.plotting import table
import numpy as np
import xlsxwriter


def Generate_Table_Summary(df, Name, Format):
	df['Status'] = df.index
	Summary = pd.DataFrame()
	Summary['Status'] = df['Status']
	Summary['Revenue'] = "$"+ df['Revenue'].astype(str)
	Summary['Systems'] = df['Systems']  
	df = Summary
	df, Width = Order_Df(df, ['Status'], [True])
	df.reset_index(drop=True, inplace=True)
	fig, ax = plt.subplots(figsize= (8, 2.5))
	ax.xaxis.set_visible(False)
	ax.yaxis.set_visible(False)
	ax.set_frame_on(False)  # no visible frame, uncomment if size is ok
	
	Colors = [ [ "w" for i in range(df.shape[1]) ] for j in range(df.shape[0]) ]
	Colors[0][0] = '#0000FF'#Completed
	Colors[1][0] = '#FFFF00'#Hold
	Colors[2][0] = '#FF0000'#Rework
	Colors[3][0] = '#00FF00'#Running
	Colors[4][0] = '#9A2EFE'#Suspend
	
	#tabla = table(ax, df, loc='center',colWidths=[0.075*4, 0.075*4, 0.075*4], cellColours=Colors, colColours=['#A9A9F5']*df.shape[1], rowColours=['#A9A9F5']*df.shape[0])
	tabla = table(ax, df, loc='center',colWidths=[0.075*4, 0.075*4, 0.075*4], cellColours=Colors)
	tabla.auto_set_font_size(False) # Activate set fontsize manually
	tabla.set_fontsize(16) # if ++fontsize is necessary ++colWidths
	tabla.scale(1, 2) # change size table
	if Format.upper() == "XLSX":
		# Create a Pandas Excel writer using XlsxWriter as the engine.
		writer = pd.ExcelWriter(Name+'.xlsx', engine='xlsxwriter')

		# Convert the dataframe to an XlsxWriter Excel object.
		df.to_excel(writer, sheet_name='Sheet1')
		
		workbook  = writer.book
		worksheet = writer.sheets['Sheet1']
		
		# Add formats.
		reworkf = workbook.add_format({'bg_color': '#FFC7CE', 'font_color': '#9C0006'})
		runningf = workbook.add_format({'bg_color': '#C6EFCE', 'font_color': '#006100'})
		holdf = workbook.add_format({'bg_color': '#FFFF00', 'font_color': '#808000'})
		completedf = workbook.add_format({'bg_color': '#3399FF', 'font_color': '#004080'})
		suspendf = workbook.add_format({'bg_color': '#9A2EFE', 'font_color': '#730099'})
		
		# Add conditional formats
		worksheet.conditional_format('B2:C' + str(df.shape[0] + 1), {'type': 'text', 'criteria': 'containing', 'value': "REWORK",'format': reworkf})
		worksheet.conditional_format('B2:C' + str(df.shape[0] + 1), {'type': 'text', 'criteria': 'containing', 'value': "RUNNING",'format': runningf})
		worksheet.conditional_format('B2:C' + str(df.shape[0] + 1), {'type': 'text', 'criteria': 'containing', 'value': "HOLD",'format': holdf})
		worksheet.conditional_format('B2:C' + str(df.shape[0] + 1), {'type': 'text', 'criteria': 'containing', 'value': "COMPLETED",'format': completedf})
		worksheet.conditional_format('B2:C' + str(df.shape[0] + 1), {'type': 'text', 'criteria': 'containing', 'value': "SUSPEND",'format': suspendf})
		formater = workbook.add_format({'border':1})
		worksheet.set_column('B2:D7',15,formater)


		#worksheet.set_column(0, len(data), 15, formater)
		# Close the Pandas Excel writer and output the Excel file.
		writer.save()
	else:
		plt.savefig(Name+'.' + Format, transparent=True)
	

	return df


def Generate_Table(Show, Name, df, Format, ColSort, OrdSort):
	print ("Ejecutando Generate_Table...")

	df, Width = Order_Df (df,ColSort,OrdSort)	
	
	Colors = Generate_Colors (df)

	Suma = 0
	Suma = sum([x for x in Width])
	
	Height = 0

	if df.shape[0] < 10:
		Height = 3.75
	elif  df.shape[0] >= 10 and df.shape[0] < 100:
		Height = 4.75
	else:
		Height = 5.75

	df.reset_index(drop=True, inplace=True)

	fig, ax = plt.subplots(figsize= ((Suma / 8), (df.shape[0]/Height)))
	ax.xaxis.set_visible(False)
	ax.yaxis.set_visible(False)
	ax.set_frame_on(False)  # no visible frame, uncomment if size is ok
	tabla = table(ax, df, loc='center', colWidths=[0.0075*x for x in Width], cellColours=Colors, colColours=['#A9A9F5']*df.shape[1], rowColours=['#A9A9F5']*df.shape[0])

	#plt.ylabel('HOLD', color='#A9A9F5')

	tabla.auto_set_font_size(False) # Activate set fontsize manually
	tabla.set_fontsize(8) # if ++fontsize is necessary ++colWidths
	tabla.scale(1, 1) # change size table

	if Format.upper() == "XLSX":
		
		# Create a Pandas Excel writer using XlsxWriter as the engine.
		writer = pd.ExcelWriter(Name+'.xlsx', engine='xlsxwriter')

		# Convert the dataframe to an XlsxWriter Excel object.
		df.to_excel(writer, sheet_name='Sheet1')
		
		workbook  = writer.book
		worksheet = writer.sheets['Sheet1']
		
		# Add formats.
		reworkf = workbook.add_format({'bg_color': '#FFC7CE', 'font_color': '#9C0006'})
		runningf = workbook.add_format({'bg_color': '#C6EFCE', 'font_color': '#006100'})
		holdf = workbook.add_format({'bg_color': '#FFFF00', 'font_color': '#808000'})
		completedf = workbook.add_format({'bg_color': '#3399FF', 'font_color': '#004080'})
		
		# Add conditional formats
		worksheet.conditional_format('N2:M' + str(df.shape[0] + 1), {'type': 'text', 'criteria': 'containing', 'value': "REWORK",'format': reworkf})
		worksheet.conditional_format('N2:M' + str(df.shape[0] + 1), {'type': 'text', 'criteria': 'containing', 'value': "RUNNING",'format': runningf})
		worksheet.conditional_format('N2:M' + str(df.shape[0] + 1), {'type': 'text', 'criteria': 'containing', 'value': "HOLD",'format': holdf})
		worksheet.conditional_format('N2:M' + str(df.shape[0] + 1), {'type': 'text', 'criteria': 'containing', 'value': "COMPLETED",'format': completedf})
		formater = workbook.add_format({'border':1})
		worksheet.set_column('B:R',15,formater)


		#worksheet.set_column(0, len(data), 15, formater)
		# Close the Pandas Excel writer and output the Excel file.
		writer.save()
	else:
		plt.savefig(Name+'.' + Format, transparent=True)


	return df

def Generate_Colors(df):
	print ("Ejecutando Generate_Colors...")
	
	Colors = [ [ "w" for i in range(df.shape[1]) ] for j in range(df.shape[0]) ]

	Lista = list(df)
	print (list(df))
	if 'OP #' in Lista:
		X  = 13
	else:
		X  = 12
		
	Y = 0
	#Tratar de mejorar tiempos aqui despues
	for j in df["Status"]: 
		if j == 'HOLD':
			Colors[Y][X] = '#FFFF00'
		elif j == 'RUNNING':
			Colors[Y][X] = '#00FF00'
		elif j == 'REWORK':
			Colors[Y][X] = '#FF0000'
		elif j == 'COMPLETED':
			Colors[Y][X] = '#0000FF'
		elif j == 'CSC':
			Colors[Y][X] = '#538AE2'
		else:
			Colors[Y][X] = '#9A2EFE'

		Y += 1
		
	return Colors

def Order_Df(df, ColSort, OrdSort):
	print ("Ejecutando Order_Df...")
	X = 0
	Y = 0
	Width= []
	
	for i in df:
		Max = 0
		for j in df[i]: 
			if Max < len(str(j)):
				Max = len(str(j))
				
			if i == 'Status':
				if j == 'QUAL_ENG':
					df[i][df.index[df[i] == j].tolist()] = 'HOLD'
				elif j == 'ABORT': 
					df[i][df.index[df[i] == j].tolist()] = 'REWORK'
				elif j == 'ATTENTION' or j == 'ATTN' or j == 'PASS':
					if df.iat[Y,X+1] == 'TVAL':
						df.iat[Y,X] = 'COMPLETED'
					else:
						df.iat[Y,X] = 'RUNNING'
				elif j == 'START' or j == 'PASS':
					df.iat[Y,X] = 'RUNNING'
				
			Y += 1
		if Max < len (i):
			Max = len(i)
		Width.append(Max)
		Y = 0
		X += 1

	df = df.sort_values(ColSort, ascending=OrdSort)

	return df, Width