from slackclient import SlackClient
import time

#Token = "xoxb-301657063959-c4VHT8yXJKa0K9HERMeYGEMO" #Oficial token 
Token = "xoxb-267672714900-JTqqAcHQpYY51HoRlsOP6UBs"#Test token
Slack_Client = SlackClient(Token)
#Bot_Name = 'powertestbot' #Oficial name
Bot_Name = 'qrytestbot' #Test name

def Get_ID(Name):
	"""
		Get the SLack ID with the user name
	"""
	api_call = Slack_Client.api_call("users.list")
	if api_call.get('ok'):
		# retrieve all users so we can find our bot
		users = api_call.get('members')
		for user in users:
			if 'name' in user and user.get('name') == Name:
				return user.get('id')
	return "Null"

#Constants
At_Bot = "<@" + Get_ID(Bot_Name) + ">"

def parse_slack_output(Slack_Rtm_Output):
	"""
		The Slack Real Time Messaging API is an events firehose.
		this parsing function returns None unless a message is
		directed at the Bot, based on its ID.
	"""
	output_list = Slack_Rtm_Output
	if output_list and len(output_list) > 0:
		for output in output_list:
			if output and 'text' in output and At_Bot in output['text']:
				# return text after the @ mention, whitespace removed
				#real_name = Get_Name (output['user'])
				return output['text'].split(At_Bot)[1].strip().lower(), \
					   output['channel'], real_name
	return None, None, None


if __name__ == "__main__":
	READ_WEBSOCKET_DELAY = 1 # 1 second delay between reading from firehose
	if Slack_Client.rtm_connect():
		print("StarterBot connected and running!")

		while True:
			command, channel, real_name = parse_slack_output(Slack_Client.rtm_read())
			
			if command and channel:
				if real_name != 'qrytestbot':
					Slack_Client.api_call("chat.postMessage", channel=channel, text="Prueba exitosa", as_user=True)					
				#handle_command(command, channel, real_name)
			time.sleep(READ_WEBSOCKET_DELAY)
	else:
		print("Connection failed. Invalid Slack token or bot ID?")

