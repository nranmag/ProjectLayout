import matplotlib.pyplot as plt

from pandas.plotting import table

import numpy as np
import xlsxwriter
import pandas as pd
import sys

def Generate_SQL_Table(Name, df, Format, ColSort, OrdSort, Bot):
	print (Bot.Name + ": I'm generating a table")
	Width = []

	df.fillna(value="", inplace=True)
	
	Width = df.max(axis=0).str.len().tolist()
	
	Width = [7 if str(x) == 'nan' else int(x) for x in Width]
	Width = [7 if x < 7 else int(x) for x in Width]
	lista_columns = list(df)
	lista_max =  df.max(axis=0).index.tolist()
	
	for index, i in enumerate(lista_columns):
		if index < len(lista_max):
			if lista_columns[index] != lista_max[index]:
				Width.insert(index, 7)
		else:
			Width.append(7)
	
	Height = 0
	
	if df.shape[0] < 10:
		Height = 3.75
	elif  df.shape[0] >= 10 and df.shape[0] < 100:
		Height = 5
	else:
		Height = 5.75

	Plus = sum(Width)
	fig, ax = plt.subplots(figsize= (0.130*Plus, 0.4*df.shape[0]))
	ax.xaxis.set_visible(False)
	ax.yaxis.set_visible(False)
	ax.set_frame_on(False)
	tabla = table(ax, df, loc='center', colWidths=[0.0077*x for x in Width], colColours=['#A9A9F5']*len(df.keys()), rowColours=['#A9A9F5']*df.shape[0])
	tabla.auto_set_font_size(False) # Activate set fontsize manually
	tabla.set_fontsize(8) # if ++fontsize is necessary ++colWidths
	tabla.scale(1, 1) # change size table
	plt.savefig("SQL_TABLE.PNG", transparent=True)



def Generate_Table(Name, df, Format, ColSort, OrdSort, Bot):
	print (Bot.Name + ": I'm generating a table")
	sys.stdout.flush()
	df = Order_Df (df,ColSort,OrdSort, Bot)
	
	df['Revenue'].fillna(0, inplace=True)
	df['Revenue'] = df.apply(lambda x: "{:,}".format(x['Revenue']), axis=1)
	df['Revenue'] = "$" + df['Revenue'].astype(str)
	

	
	Width = []
	 
	df.reset_index(drop=True, inplace=True)
	df.fillna(value='', inplace=True)

	
	for x in  list(df):
		if int(df[x].str.len().max()) > len(x):
			Width.append(int(df[x].str.len().max()))
		else:
			Width.append(len(x))
	
	Colors = Generate_Colors (df, Bot) #Modificare colors para la presentacion WW

	

	Suma = 0
	Suma = sum([x for x in Width])
	
	Height = 0

	if df.shape[0] < 10:
		Height = 3.75
	elif  df.shape[0] >= 10 and df.shape[0] < 20:
		Height = 4.75
	else:
		Height = 5.15

	
	fig, ax = plt.subplots(figsize= ((Suma / 8), (df.shape[0]/Height)))
	ax.xaxis.set_visible(False)
	ax.yaxis.set_visible(False)
	ax.set_frame_on(False)  # no visible frame, uncomment if size is ok
	
	tabla = table(ax, df, loc='center', colWidths=[0.0055*x for x in Width], cellColours=Colors, colColours=['#A9A9F5']*df.shape[1], rowColours=['#A9A9F5']*df.shape[0])
	
	tabla.auto_set_font_size(False) # Activate set fontsize manually
	tabla.set_fontsize(8) # if ++fontsize is necessary ++colWidths
	tabla.scale(1, 1) # change size table
	if Format.upper() == "XLSX":
		
		# Create a Pandas Excel writer using XlsxWriter as the engine.
		writer = pd.ExcelWriter(Name  + '.' + Format.lower(), engine='xlsxwriter')
		
		# Convert the dataframe to an XlsxWriter Excel object.
		df.to_excel(writer, sheet_name='Sheet1')
		
		workbook  = writer.book
		worksheet = writer.sheets['Sheet1']
		
		# Add formats.
		reworkf = workbook.add_format({'bg_color': '#FFC7CE', 'font_color': '#9C0006'})
		runningf = workbook.add_format({'bg_color': '#C6EFCE', 'font_color': '#006100'})
		holdf = workbook.add_format({'bg_color': '#FFFF00', 'font_color': '#808000'})
		completedf = workbook.add_format({'bg_color': '#3399FF', 'font_color': '#004080'})
		
		# Add conditional formats
		worksheet.conditional_format('R2:S' + str(df.shape[0] + 1), {'type': 'text', 'criteria': 'containing', 'value': "REWORK",'format': reworkf})
		worksheet.conditional_format('R2:S' + str(df.shape[0] + 1), {'type': 'text', 'criteria': 'containing', 'value': "RUNNING",'format': runningf})
		worksheet.conditional_format('R2:S' + str(df.shape[0] + 1), {'type': 'text', 'criteria': 'containing', 'value': "HOLD",'format': holdf})
		worksheet.conditional_format('R2:S' + str(df.shape[0] + 1), {'type': 'text', 'criteria': 'containing', 'value': "COMPLETED",'format': completedf})
		formater = workbook.add_format({'border':1})
		worksheet.set_column('B10:W10',15,formater)


		# Close the Pandas Excel writer and output the Excel file.
		writer.save()
	else:
		plt.savefig(Name + '.' + Format.lower(), transparent=True)
	
	sys.stdout.flush()
	return df

def Generate_Colors(df, Bot):
	print (Bot.Name + ": I'm generating the colors")
	sys.stdout.flush()
	Colors = np.empty(shape=(df.shape[0], df.shape[1]), dtype=object)
	Colors[:] = "#FFFFFF"
	Colors[::2] = "#E0E0ED"
	 
	
	X  = 16 #Modificare colors para la presentacion WW
	Y = 0
	
	conditions = [
		(df["Status"] == 'HOLD      ') | (df["Status"] == 'HOLD'),
		(df["Status"] == 'RUNNING   ') | (df["Status"] == 'RUNNING'),
		(df["Status"] == 'COMPLETED ') | (df["Status"] == 'COMPLETED'),
		(df["Status"] == 'REWORK    ') | (df["Status"] == 'REWORK'), 
		(df["Status"] == 'BUILD') | (df["Status"] == 'KITTING') | (df["Status"] == 'RACK MERGE'),
		(df["Status"] == 'WAITING TEST'),
		(df["Status"] == 'CABLING') | (df["Status"] == 'CAPTIVES')
		]
	choices = ['#FFFF00', '#00FF00', '#0000FF', '#FF0000', '#602F99', '#C4ACE0', '#9EAAE2']
	Colors = pd.DataFrame(Colors)
	Colors[:][X] = np.select(conditions, choices, default='#9A2EFE')
	Colors = Colors.as_matrix()
	
	return Colors

def Generate_Table_Summary(df, Name, Format, Bot):
	print (Bot.Name + ": I'm generating a summary")
	sys.stdout.flush()
	df['Status'] = df.index
	Summary = pd.DataFrame()
	Summary['Status'] = df['Status']
	Summary['Revenue'] = df.apply(lambda x: "{:,}".format(x['Revenue']), axis=1)
	Summary['Revenue'] = "$"+ Summary['Revenue'].astype(str)
	Summary['Systems'] = df['Systems']  
	df = Summary
	
	basic_status = ['COMPLETED',  'HIPOT', 'CSC', 'RUNNING   ', 'REWORK    ', 'HOLD      ', 'DOWN      ','TOTAL']

	df['Cat'] = pd.Categorical(
    				df['Status'], 
    				categories=basic_status, 
    				ordered=False
	)
	df.sort_values('Cat', ascending=True)
	
	df.reset_index(drop=True, inplace=True)
	df = df.drop('Cat', 1)

	Colors = [ [ "w" for i in range(df.shape[1]) ] for j in range(df.shape[0]) ]
	
	for index, i in df.iterrows():
		
		if i['Status'] == 'COMPLETED':
			Colors[index][0] = '#0000FF'
		elif i['Status'] == 'HIPOT':
			Colors[index][0] = '#F9F195'
		elif i['Status'] == 'CSC':
			Colors[index][0] = '#8D6999'
		elif i['Status'] == 'RUNNING   ':
			Colors[index][0] = '#00FF00'
		elif i['Status'] == 'REWORK    ':
			Colors[index][0] = '#FF0000'
		elif i['Status'] == 'HOLD      ':
			Colors[index][0] = '#FFFF00'
		elif i['Status'] == 'DOWN      ':
			Colors[index][0] = '#DC42F4'
		elif i['Status'] == 'TOTAL':
			Colors[index][0] = 'w'
		else:
			Colors[index][0] = '#C9C9C9'
	
	fig, ax = plt.subplots(figsize= (8, 0.4*df.shape[0]))
	ax.xaxis.set_visible(False)
	ax.yaxis.set_visible(False)
	ax.set_frame_on(False)  # no visible frame, uncomment if size is ok
	
	
	
	tabla = table(ax, df, loc='center',colWidths=[0.09*4, 0.075*4, 0.075*4, ], cellColours=Colors)
	tabla.auto_set_font_size(False) # Activate set fontsize manually
	tabla.set_fontsize(16) # if ++fontsize is necessary ++colWidths
	tabla.scale(1, 2) # change size table
	if Format.upper() == "XLSX":
		# Create a Pandas Excel writer using XlsxWriter as the engine.
		writer = pd.ExcelWriter(Name+'.xlsx', engine='xlsxwriter')

		# Convert the dataframe to an XlsxWriter Excel object.
		df.to_excel(writer, sheet_name='Sheet1')
		
		workbook  = writer.book
		worksheet = writer.sheets['Sheet1']
		
		# Add formats.
		reworkf = workbook.add_format({'bg_color': '#FFC7CE', 'font_color': '#9C0006'})
		runningf = workbook.add_format({'bg_color': '#C6EFCE', 'font_color': '#006100'})
		holdf = workbook.add_format({'bg_color': '#FFFF00', 'font_color': '#808000'})
		completedf = workbook.add_format({'bg_color': '#3399FF', 'font_color': '#004080'})
		suspendf = workbook.add_format({'bg_color': '#9A2EFE', 'font_color': '#730099'})
		
		# Add conditional formats
		worksheet.conditional_format('B2:C' + str(df.shape[0] + 1), {'type': 'text', 'criteria': 'containing', 'value': "REWORK",'format': reworkf})
		worksheet.conditional_format('B2:C' + str(df.shape[0] + 1), {'type': 'text', 'criteria': 'containing', 'value': "RUNNING",'format': runningf})
		worksheet.conditional_format('B2:C' + str(df.shape[0] + 1), {'type': 'text', 'criteria': 'containing', 'value': "HOLD",'format': holdf})
		worksheet.conditional_format('B2:C' + str(df.shape[0] + 1), {'type': 'text', 'criteria': 'containing', 'value': "COMPLETED",'format': completedf})
		worksheet.conditional_format('B2:C' + str(df.shape[0] + 1), {'type': 'text', 'criteria': 'containing', 'value': "SUSPEND",'format': suspendf})
		formater = workbook.add_format({'border':1})
		worksheet.set_column('B2:D7',15,formater)


		#worksheet.set_column(0, len(data), 15, formater)
		# Close the Pandas Excel writer and output the Excel file.
		writer.save()
	else:
		plt.savefig(Name.lower()+'.' + Format.lower(), transparent=True)
	

	return df

def Order_Df(df, ColSort, OrdSort, Bot):
	print (Bot.Name + ": I'm ordering the data frame")
	sys.stdout.flush()
	X = 0
	Y = 0
	
	for i in df:
		for j in df[i]: 
			if i == 'Status':
				if j == 'QUAL_ENG':
					df[i][df.index[df[i] == j].tolist()] = 'HOLD'
				elif j == 'ABORT': 
					df[i][df.index[df[i] == j].tolist()] = 'REWORK'
				elif j == 'ATTENTION' or j == 'ATTN' or j == 'PASS' or j == 'ATTENTION ':
					if df.iat[Y,X+1] == 'TVAL':
						df.iat[Y,X] = 'COMPLETED'
					else:
						df.iat[Y,X] = 'RUNNING'
				elif j == 'START' or j == 'PASS':
					df.iat[Y,X] = 'RUNNING'

			Y += 1
		Y = 0
		X += 1

	df = df.sort_values(ColSort, ascending=OrdSort)

	return df