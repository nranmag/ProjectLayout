'''
cf_misc v1.0

@author: edurod

-------------------------------------------------------------------------------
                          IBM SYSTEMS 
                        IBM CONFIDENTIAL
-------------------------------------------------------------------------------
Miscellaneous

'''
# -*- coding: utf-8 -*-

# **********************  CHANGE HISTORY  *************************************
#   DATE      DEVELOPER    VER      CHANGE
# =============================================================================
# 10-09-2017   edurod     1.0   Initial Creation
# =============================================================================

from __future__ import print_function
import os
import json


class ClodFoundryError(Exception):
    '''
    @author: edurod
    Raised when a Cloud Foundry Error Happens
    '''
    def __init__(self, message):
        self.message = message
        super(ClodFoundryError, self).__init__(self.message)

    def __str__(self):
        return self.message

def get_credentials(instance, service='user-provided'):
    '''
        Retrieve credentials of a Bluemix service instance from VCAP_SERVICES
        env variable. 
        ***Note: The service instance must be bound to the application so the
                 credentials are present in the VCAP_SERVICES var. 
         
        Mandatory Arguments:
            - instance: (String) Service instance name.
            
        Optional Arguments:
            - service: (String) Service instance name or 'used-provided' if it
                                it is an user provided service. 
                Default: 'user-provided'

        Returns:
            Decoded JSON object (dict) containing the service instance
            credentials.

        Exceptions:
            - ClodFoundryError raised if there is a problem getting the service
              instance credentials. A comprehensive error message is provided.
    '''
    try:
        vcap_services = json.loads(os.environ['VCAP_SERVICES'])
#         print(json.dumps(vcap_services, indent=4))
    except  KeyError:
        raise  ClodFoundryError('VCAP_SERVICES env variable does not exist.')
    try:
        instance_list = vcap_services[service] 
    except  KeyError:
        raise  ClodFoundryError("'" + service + "' service not found in " +
                                "VCAP_SERVICES env variable.")
    credentials_json = None  
    for instance_json in instance_list:
        if instance_json['name'] == instance:
            credentials_json = instance_json['credentials']
            break
    if credentials_json:
        return credentials_json
    else:
        raise  ClodFoundryError("'" + instance + "' instance of '" + service + 
                                "' service not found in VCAP_SERVICES env " +
                                "variable.")

    