import os 
import json
from watson_developer_cloud import ConversationV1
import sys

#Watson information
conversation = ConversationV1(
	username='38a164e2-0e16-4a45-83de-57504f915318',
	password='RlXgqcM0zAwz',
	version='2017-05-26')

# replace with your own workspace_id
workspace_id = '4e05ead6-9cb6-4cb1-b893-9bc74af1a0e4'
if os.getenv("conversation_workspace_id") is not None:
	workspace_id = os.getenv("conversation_workspace_id")

def Watson_to_Bot(self):
	"""
	Send the input from Slack to Watson and classify the Watson output
	"""
	print (self.Name + ": I'm asking to my friend Watson")
	sys.stdout.flush()
	Intents = []
	Producto = []
	Subprod = []
	Area = []
	Formato = []
	Tiempo = []
	Output = []
	Input_R = []
	Systems = []
	Input = self.Input.upper()
	List_Name = []

	if "\n" in self.Input:
		Input = self.Input.split("\n")
		Input_R = Input[1:]
		Input = Input[0]
		 
	response = conversation.message(workspace_id=workspace_id, input={
	'text': Input})
	
	data = json.loads(json.dumps(response, indent=2))
	
	sys.stdout.flush()

	for x in data['intents']:
		Intents.append(x['intent'].upper())
	
	if len(data['entities']) == 0:
		List_Name = Input.split('"')[1::2]
		Systems = Input_R

	for x in data['entities']:
		if x['entity'] == 'Producto':
			Producto.append(x['value'].upper())

			if x['value'] == 'Lista':
				List_Items = Input[x['location'][1]:].split(" ")
				for y in List_Items:
					if len(y) > 0:
						List_Name.append(y)
				if '"' in List_Name[0]:
					List_Name = Input.split('"')[1::2]
				Systems = Input_R
			
			if x['value'] == 'System':
				Systems = Input_R

		elif x['entity'] == 'Formato':
			Formato.append(x['value'].upper())
		elif x['entity'] == 'AREA':
			Area.append(x['value'].upper())
		elif x['entity'] == 'tiempo':
			Tiempo.append(x['value'].upper())
		elif x['entity'] == 'sys-time':
			Tiempo.append(x['value'].upper())
		elif x['entity'] == 'sys-number':
			Tiempo.append(x['value'].upper())
		elif x['entity'] == 'Subprod':
			Subprod.append(x['value'].upper())
			if x['value'] == 'PN':
				List_Items = Input[x['location'][1]:].split(" ")
				for y in List_Items:
					if len(y) > 0:
						List_Name.append(y)
				if '"' in List_Name[0]:
					List_Name = Input.split('"')[1::2]
				Systems = Input_R
			if x['value'] == 'System':
				Systems = Input_R
	if len (Formato) == 0:
		Formato.append("PNG")

	for x in data['output']['text']:
		Output.append(x)
	
	if (len (Producto) > 1 and len (Area) > 0) and 'GENERAR' not in Intents :
		Producto.remove('WTEST')

	if len(Area) == 0:
		Area.append('TEST')
	sys.stdout.flush()
	
	return Intents, Producto, Subprod, Area, Formato, Tiempo, List_Name, Systems, Output