#!/usr/bin/env python
# -*- coding: utf-8 -*-


import os
from flask import Flask, jsonify
import ibm_db
import cf_misc

dsn = cf_misc.get_credentials('db2_car_test')['dsn']
conn = ibm_db.connect(dsn, '', '')
print('--> Connection established')


app = Flask(__name__)





@app.route('/')
def Welcome():
    return app.send_static_file('index.html')










port = os.getenv('PORT', '5000')
if __name__ == "__main__":
	app.run(host='0.0.0.0', port=int(port))
