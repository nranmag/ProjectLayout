import sys
import os
import csv_data as cd
import df_ima as di 

def Interpret_Command(ListComms1, ListComms2, ListComms3, ListComms4, ListComms5, List_Name, Systems, Output, Channel, Real_Name, Slack):
	"""
	Execute the commands from Watson
	"""
	#Slack.api_call("chat.postMessage", channel=Channel, text=x, as_user=True)
	print ("Ejecutando Interpret_Command...")
	Intents = ["ESTATUS", "GENERAR", "SUMARIO"]
	#Detect the OS to use the correct command
	if sys.platform == "win32":
		Path = os.path.dirname(__file__)
	elif sys.platform == "linux":
		Path = os.path.dirname(os.path.realpath(__file__))
	elif sys.platform == "linux2":
		Path = os.path.dirname(os.path.realpath(__file__)) 

	if len(ListComms1) > 0:
		#Status section
		if ListComms1[0].upper() == "ESTATUS":
			if len(ListComms2) > 0:
				for i in ListComms2:
					#General status
					for x in Output:
						Slack.api_call("chat.postMessage", channel=Channel, text=x, as_user=True)
					SQL = cd.Read_SQL("ESTATUS",i.upper(), ListComms3[0].upper())
					if i == 'LISTA' or i == 'CRITICAS': 
						if i == 'CRITICAS':
							Systems = Read_List("CRITICAS")
						else:
							List_Name[0] = str(List_Name[0])
							Systems = Read_List(List_Name[0])
						SQL += " and physical.wumfgn in ("
						if Systems == False:
							Slack.api_call("chat.postMessage", channel=Channel, text="The list does not exist :disappointed:", as_user=True)
							break

						for x in Systems:
							SQL += "'" + x + "', "
						SQL = SQL[:-2]
						SQL += ")" 
					if i == 'SYSTEM':
						if len(Systems) > 0: 
							SQL += " and physical.wumfgn in ("
							for x in Systems:
								SQL += "'" + x + "', "
							SQL = SQL[:-2]
							SQL += ")"
					df = cd.Data_DB2(SQL)
					df = cd.Add_VCC(df, False)
					if i == 'GENERAL':
						df = cd.Remove_Yorders(df)
					if df.shape[0] > 0:
						if len(ListComms4) > 0:
							if "PNG" in ListComms4:
								Send_File(Slack, Channel, df, i.upper() + "_Status", "png",Path,"Status " + i.upper(), "There you go " + Real_Name, ['Status', 'MFG #', 'Test Cell'], [True, True, True])	
							elif "PDF" in ListComms4:
								Send_File(Slack, Channel, df, i.upper() + "_Status", "pdf",Path,"Status " + i.upper(), "There you go " + Real_Name, ['Status', 'MFG #', 'Test Cell'], [True, True, True])
							elif "XLSX" in ListComms4:
								Send_File(Slack, Channel, df, i.upper() + "_Status", "xlsx",Path,"Status " + i.upper(), "There you go " + Real_Name, ['Status', 'MFG #', 'Test Cell'], [True, True, True])
						else:
							Send_File(Slack, Channel, df, i.upper() + "_Status", "png",Path,"Status " + i.upper(), "There you go " + Real_Name, ['Status', 'MFG #', 'Test Cell'], [True, True, True])
					else:
						Slack.api_call("chat.postMessage", channel=Channel, text="The desired status does not contain any element :disappointed:", as_user=True)
		elif ListComms1[0].upper() == "GENERAR":
			
			for i in ListComms2:
				if i.upper() == "LISTA":
					for x in Output:
						Slack.api_call("chat.postMessage", channel=Channel, text=x, as_user=True)
					if "CRITICAS" in ListComms2:
						Create_List("CRITICAS", Systems)
					else:
						print (List_Name[0])
						print (Systems)
						Create_List(List_Name[0], Systems)
		elif ListComms1[0].upper() == "SUMARIO":
			if len(ListComms2) > 0:
				for i in ListComms2:
					for x in Output:
						Slack.api_call("chat.postMessage", channel=Channel, text=x, as_user=True)
					SQL = cd.Read_SQL("SUMARIO",i.upper(), "TEST")
					print (SQL)
					if i == 'LISTA' or i == 'CRITICAS': 
						if i == 'CRITICAS':
							Systems = Read_List("CRITICAS")
						else:
							List_Name[0] = str(List_Name[0])
							Systems = Read_List(List_Name[0])
						SQL += " and physical.wumfgn in ("
						if Systems == False:
							Slack.api_call("chat.postMessage", channel=Channel, text="The list does not exist :disappointed:", as_user=True)
							break

						for x in Systems:
							SQL += "'" + x + "', "
						SQL = SQL[:-2]
						SQL += ")" 
					if i == 'SYSTEM':
						if len(Systems) > 0: 
							SQL += " and physical.wumfgn in ("
							for x in Systems:
								SQL += "'" + x + "', "
							SQL = SQL[:-2]
							SQL += ")"
					df = cd.Data_DB2(SQL)
					df = cd.Add_VCC(df, False)
					df = cd.Remove_Yorders(df)
					df = cd.Summary(df)


					if df.shape[0] > 0:
						if len(ListComms4) > 0:
							if "PNG" in ListComms4:
								#Send_Summary(df, "General_Summary", "png",Path,"General Summary", "There you go " + Real_Name)	
								Send_Summary(Slack, Channel, df, i.upper() + "_Status", "png",Path,"Status " + i.upper(), "There you go " + Real_Name)	
							elif "PDF" in ListComms4:
								Send_Summary(Slack, Channel, df, i.upper() + "_Status", "pdf",Path,"Status " + i.upper(), "There you go " + Real_Name)
							elif "XLSX" in ListComms4:
								Send_Summary(Slack, Channel, df, i.upper() + "_Status", "xlsx",Path,"Status " + i.upper(), "There you go " + Real_Name)
						else:
							#Send_Summary(df, "General_Summary", "png",Path,"General Summary", "There you go " + Real_Name)
							Send_Summary(Slack, Channel, df, i.upper() + "_Summary", "png",Path,"Summary " + i.upper(), "There you go " + Real_Name)
					else:
						Slack.api_call("chat.postMessage", channel=Channel, text="The desired status does not contain any element :disappointed:", as_user=True)


					
		elif ListComms1[0].upper() == "HELP":
			for x in Output:
				Slack.api_call("chat.postMessage", channel=Channel, text=x, as_user=True)
		#Default section	
		elif (ListComms1[0].upper() not in Intents):
			for x in Output:
				Slack.api_call("chat.postMessage", channel=Channel, text=x, as_user=True)

def Send_File(Slack, Channel, df, Name, Ext, Path, Title, Text, ColSort, OrdSort):
	"""
	Funtion to send a status file
	"""
	print ("Sending a file...")
	df = di.Generate_Table(False, Name, df, Ext	, ColSort,OrdSort)
	Slack.api_call('files.upload', channels=Channel, filename=Name + "." + Ext, file=open(Path + "/" + Name + "." + Ext, 'rb'), initial_comment = Text	, title= Title)
	return True

def Send_Summary(Slack, Channel, df, Name, Ext, Path, Title, Text):
	"""
	Funtion to send a summary file
	"""
	print ("Sending a summary...")
	di.Generate_Table_Summary(df, Name, Ext)
	Slack.api_call('files.upload', channels=Channel, filename=Name + "." + Ext, file=open(Path + "/" + Name + "." + Ext, 'rb'), initial_comment = Text	, title= Title)
	return True

def Create_List(Name, Systems):
	"""
	Create a list with the interest systems
	"""
	#file = open(Name.encode("utf-8") + ".bot","w")
	file = open(Name + ".bot","w") 
	[file.write(x+"\n") for x in Systems]
	file.close()
	return True

def Read_List(Name):
	"""
	Read a file list and return a list with the systems inside 
	"""
	print (Name + ".bot")
	if os.path.exists(Name + ".bot"):
		file = open(Name + ".bot","r")
		systems = file.read()#.split()
		systems = systems.replace("\n", ", ")
		systems = systems.replace(" ", "")
		systems = systems.split(",")
		systems = systems[:-1]
		return systems 
	else:
		return False