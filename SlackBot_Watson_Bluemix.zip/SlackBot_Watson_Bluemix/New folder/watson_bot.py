import os 
import json
from watson_developer_cloud import ConversationV1

#Watson information
conversation = ConversationV1(
	username='38a164e2-0e16-4a45-83de-57504f915318',
	password='RlXgqcM0zAwz',
	version='2017-05-26')

# replace with your own workspace_id
workspace_id = '4e05ead6-9cb6-4cb1-b893-9bc74af1a0e4'
if os.getenv("conversation_workspace_id") is not None:
	workspace_id = os.getenv("conversation_workspace_id")

def Watson_to_Bot(Input):
	"""
	Send the input from Slack to Watson and classify the Watson output
	"""
	ListComms1 = []
	ListComms2 = []
	ListComms3 = []
	ListComms4 = []
	ListComms5 = []
	Output = []
	Input_R = []
	Systems = []
	Input = Input.upper()
	List_Name = ""

	if "\n" in Input:
		Input = Input.split("\n")
		Input_R = Input[1:]
		Input = Input[0]
		 
	response = conversation.message(workspace_id=workspace_id, input={
	'text': Input})
	
	data = json.loads(json.dumps(response, indent=2))
	print (data) #Dejo esto para validacion quitar despues
	
	for x in data['intents']:
		ListComms1.append(x['intent'].upper())
	
	if len(data['entities']) == 0:
		List_Name = Input.split('"')[1::2]
		Systems = Input_R

	for x in data['entities']:
		if x['entity'] == 'Producto':
			ListComms2.append(x['value'].upper())
			if x['value'] == 'Lista':
				List_Name = Input.split('"')[1::2]
				Systems = Input_R
			if x['value'] == 'System':
				Systems = Input_R
				print (Systems)
			
		elif x['entity'] == 'Formato':
			ListComms4.append(x['value'].upper())
		
		if x['entity'] == 'AREA':
			ListComms3.append(x['value'].upper())
		else:
			ListComms3.append("TEST")
	for x in data['output']['text']:
		Output.append(x)
	
	#Interpret_Command(ListComms1, ListComms2, ListComms3, ListComms4, ListComms5, Real_Name, List_Name, Systems, Output)
	return ListComms1, ListComms2, ListComms3, ListComms4, ListComms5, List_Name, Systems, Output