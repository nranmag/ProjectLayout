from __future__ import print_function
import json
import os
from watson_developer_cloud import ConversationV1
import os.path
#########################
# message
#########################

if os.path.exists("CRITICAS.bot"):
	print("File exist")
else: 
	print ("File does not exist")

conversation = ConversationV1(
    username='38a164e2-0e16-4a45-83de-57504f915318',
    password='RlXgqcM0zAwz',
    version='2017-05-26')

# replace with your own workspace_id
workspace_id = '4e05ead6-9cb6-4cb1-b893-9bc74af1a0e4'
if os.getenv("conversation_workspace_id") is not None:
    workspace_id = os.getenv("conversation_workspace_id")

Texto = "Quieron generar una lista llamada 'Prueba' con los siguentes sistemas: \n1AT9LA9\n1AUDVU2"
if "\n" in Texto:
  print ("Hay saltos de linea")
  Texto = Texto.split("\n")
  Texto_N = Texto[1:]
  Texto = Texto[0]  

print (Texto_N)
response = conversation.message(workspace_id=workspace_id, input={
    'text': 'Quiero un estatus lista julanos'})
#    'text': 'Quiero estatus de brazo y zz en imagen'})

#print(json.dumps(response, indent=2))
data = json.loads(json.dumps(response, indent=2))
#print (data)
print ("Input: ")
print (data['input'])
print ("Intents: ")
print (data['intents'])
print ("Entities: ")
print (data['entities'])
print ("Output: ")
print (data['output'])
"""
print ("Input: " + data["input"]["text"]) 
print ("Intents: " + data["intents"][0]['intent']) 
print ("Entity: " + data["entities"][0]["entity"])
print ("Entity value: " + data["entities"][0]["value"])
print ("Entities: ")
"""
#print (data["entities"])
#print (len(data["entities"]))
#for x in data["output"]["text"]:
#  print (x)
#for i in data["entities"]:
#  print (i['entity'])
# When you send multiple requests for the same conversation, include the
# context object from the previous response.
# response = conversation.message(workspace_id=workspace_id, message_input={
# 'text': 'turn the wipers on'},
#                                context=response['context'])
# print(json.dumps(response, indent=2))
