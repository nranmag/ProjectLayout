import sys
import os
import multiprocessing
from multiprocessing import Pool
import csv_data as cd
import df_ima as di 
import pandas as pd

def Interpret_Command(Bot):
	"""
	Execute the commands from Watson
	"""
	print (Bot.Name + ": I'm interpreting commands")
	sys.stdout.flush()
	Intents = ["ESTATUS", "GENERAR", "SUMARIO"]
	#Detect the OS to use the correct command
	if sys.platform == "win32":
		Bot.Path = os.path.dirname(__file__)
		print (Bot.Name + ": I'm running on Windows")
		sys.stdout.flush()
	elif sys.platform == "linux":
		Bot.Path = os.path.dirname(os.path.realpath(__file__))
		print (Bot.Name + ": I'm running on Linux")
		sys.stdout.flush()
	elif sys.platform == "linux2":
		Bot.Path = os.path.dirname(os.path.realpath(__file__))
		print (Bot.Name + ": I'm running on IBM Cloud")
		sys.stdout.flush() 
	if len(Bot.Intent) > 0:
		#Status section
		if Bot.Intent[0].upper() == "ESTATUS":
			if len(Bot.Product) > 0 or len(Bot.Subprod) > 0:
				print (Bot.Name + ": I'm making a status")
				sys.stdout.flush()
				if Bot.Area[0] == "TEST":
					for i in Bot.Product:
						SQL = cd.Read_SQL("ESTATUS",i.upper(), Bot.Area[0], Bot)
						if i == 'LISTA' or i == 'CRITICAS': 
							if i == 'CRITICAS':
								Bot.Systems = Read_List("CRITICAS", Bot)
							else:
								print (Bot.List[0])
								Bot.List[0] = str(Bot.List[0])
								print ("Nombre de la lista: ")
								print (Bot.List[0])
								Bot.Systems = Read_List(Bot.List[0], Bot)
							
							SQL += " and physical.wumfgn in ("
							
							if Bot.Systems == False:
								Bot.Message_to_Dad = "The list does not exist :disappointed:"
								break

							for x in Bot.Systems:
								SQL += "'" + x.upper() + "', "
							
							SQL = SQL[:-2]
							SQL += ")" 
						
						if i == 'SYSTEM':
							if len(Bot.Systems) > 0: 
								SQL += " and physical.wumfgn in ("
								for x in Bot.Systems:
									SQL += "'" + x.upper() + "', "
								SQL = SQL[:-2]
								SQL += ")"
						
						df = cd.Data_DB2(SQL, Bot)
						
						if df.shape[0] > 0:
							df = cd.Add_VCC(df, Bot)
							if len(Bot.Format) > 0:
								Bot.File = i.upper() + "_Status"
								Bot.File_Text = "There you go " + Bot.Dad
								Bot.File_Title = "Status " + Bot.File 
								Create_File(df, Bot.File, Bot.Format[0], Bot.Path, Bot.File_Title , ['Status', 'MFG #', 'Test Cell'], [True, True, True], Bot)
						else:
							Bot.Message_to_Dad = "The desired status does not contain any element :disappointed:"

				if Bot.Area[0] == "MANUFACTURA":
					for i in Bot.Subprod:
						if i == 'PN':
							SQL = cd.Read_SQL("ESTATUS",i.upper(), Bot.Area[0], Bot)
							SQL = SQL.replace('#1#', " IN ('" + Bot.List[0].upper() + "') ")
							
							Cadena = "IN ("
							
							for x in Bot.Product:
								if x == 'SYSTEM':
									if len(Bot.Systems) > 0: 
										for y in Bot.Systems:
											Cadena += "'" + y.upper() + "', "
										
										Cadena = Cadena[:-2]
										Cadena += ")"
							
							if Cadena == "IN (":
								Cadena = "NOT IN ('')"	

							SQL = SQL.replace('#2#', Cadena)
							df = cd.Data_DB2(SQL, Bot)
							
							if df.shape[0] > 0:
								Bot.File = "SQL_TABLE"
								Bot.File_Text = "There you go " + Bot.Dad
								Bot.File_Title = "Status " + Bot.File 
								Create_File_SQL(df, Bot.File, Bot.Format[0], Bot.Path, Bot.File_Title , [], [], Bot)
							else:
								Bot.Message_to_Dad = "The desired status does not contain any element :disappointed:"

									
		#List section
		elif Bot.Intent[0].upper() == "GENERAR":
			
			for i in Bot.Product:
				if i.upper() == "LISTA":
					print (Bot.Name + ": I'm making a list")
					sys.stdout.flush()
					
					if "CRITICAS" in Bot.Product:
						Create_List("CRITICAS", Bot.Systems, Bot)
					else:
						Create_List(Bot.List[0], Bot.Systems, Bot)
		#Summary section
		elif Bot.Intent[0].upper() == "SUMARIO":
			if len(Bot.Product) > 0:
				for i in Bot.Product:
					print (Bot.Name + ": I'm making a summary")
					sys.stdout.flush()
					SQL = cd.Read_SQL("SUMARIO",i.upper(), "TEST", Bot)
					if i == 'LISTA' or i == 'CRITICAS': 
						if i == 'CRITICAS':
							Bot.Systems = Read_List("CRITICAS", Bot)
						else:
							Bot.List[0] = str(Bot.List[0])
							Bot.Systems = Read_List(Bot.List[0], Bot)
						SQL += " and physical.wumfgn in ("
						if Bot.Systems == False:
							Slack.api_call("chat.postMessage", channel=Channel, text="The list does not exist :disappointed:", as_user=True)
							Bot.Message_to_Dad = "The list does not exist :disappointed:"
							break

						for x in Bot.Systems:
							SQL += "'" + x + "', "
						SQL = SQL[:-2]
						SQL += ")" 
					if i == 'SYSTEM':
						if len(Bot.Systems) > 0: 
							SQL += " and physical.wumfgn in ("
							for x in Bot.Systems:
								SQL += "'" + x + "', "
							SQL = SQL[:-2]
							SQL += ")"
					df = cd.Data_DB2(SQL, Bot)
					df = cd.Remove_Yorders(df)
					df = cd.Add_VCC(df, Bot)
					df = cd.Summary(df, Bot)
					if df.shape[0] > 0:
						if len(Bot.Format) > 0:
							Bot.File = i.upper() + "_Status"
							Bot.File_Text = "There you go " + Bot.Dad
							Bot.File_Title = "Status " + Bot.File 
							Create_Summary(df, Bot.File, Bot.Format[0], Bot.Path, Bot.File_Title, Bot)
					else:
						Bot.Message_to_Dad = "The desired status does not contain any element :disappointed:"

		elif Bot.Intent[0].upper() == "PETICION":
			if len(Bot.Product) > 0:
				for i in Bot.Product:
					columns	= ['Index', 'Botname', 'Channel', 'Real Name', 'Intent', 'Product', 'Area', 'Format', 'List', 'Systems', 'Time', 'Hour']
					
					if i == 'VER':
						Requests = pd.read_csv('Requests.csv', names= columns, skiprows=1, index_col=0)
						Requests = cd.Filter_Data(Requests, ['Channel'], [[Bot.Channel]], Bot)
						Cadena = ""
						
						for index, i in Requests.iterrows():
							Cadena+= str(i['Index']) + ") " + str(i['Intent']) + " " + str( i['Product']) + " " + str(i['List'] if str(i['List']) != "nan" else "") + " " + str(i['Area']) + " " + str(i['Format']) +"\n"
							
						Bot.Message_to_Dad = Cadena
						
					elif i == 'BORRAR':	
						if len (Bot.Tiempo) > 0:
							Requests = pd.read_csv('Requests.csv', names= columns, skiprows=1, index_col=0)
							
							if int(Bot.Tiempo[0]) in Requests['Index'].tolist():
								Requests = Requests[Requests.Index != int(Bot.Tiempo[0])]	
								Requests.to_csv('Requests.csv')
							else: 
								Bot.Message_to_Dad = "Not valid index number to delete :disappointed:"
						else:
							Bot.Message_to_Dad = "There is not index number to delete :disappointed:"
								

def Create_File(df, Name, Ext, Path, Title, ColSort, OrdSort, Bot):
	"""
	Funtion to send a status file
	"""
	print (Bot.Name + ": I'm creating a file")
	sys.stdout.flush()
	di.Generate_Table(Name, df, Ext	, ColSort,OrdSort, Bot) 
	return True

def Create_File_SQL(df, Name, Ext, Path, Title, ColSort, OrdSort, Bot):
	"""
	Funtion to send a status file
	"""
	print (Bot.Name + ": I'm creating a file")
	sys.stdout.flush()
	di.Generate_SQL_Table(Name, df, Ext	, ColSort,OrdSort, Bot) 
	return True

def Create_Summary(df, Name, Ext, Path, Title, Bot):
	"""
	Funtion to send a summary file
	"""
	print (Bot.Name + ": I'm creating a summary")
	sys.stdout.flush()
	di.Generate_Table_Summary(df, Name, Ext, Bot)
	return True

def Send_Summary(Slack, Channel, df, Name, Ext, Path, Title, Text):
	"""
	Funtion to send a summary file
	"""
	print (Bot.Name + ": I'm creating a summary")
	sys.stdout.flush()
	di.Generate_Table_Summary(df, Name, Ext, threading)
	Slack.api_call('files.upload', channels=Channel, filename=Name + "." + Ext, file=open(Path + "/" + Name + "." + Ext, 'rb'), initial_comment = Text	, title= Title)
	return True

def Create_List(Name, Systems, Bot):
	"""
	Create a list with the interest systems
	"""
	#file = open(Name.encode("utf-8") + ".bot","w")
	print (Bot.Name + ": I'm creating a list")
	sys.stdout.flush()
	print (Name)
	file = open(Name + ".bot","w") 
	[file.write(x.upper()+"\n") for x in Systems]
	file.close()
	return True

def Read_List(Name, Bot):
	"""
	Read a file list and return a list with the systems inside 
	"""
	print (Bot.Name + ": I'm reading a list")
	sys.stdout.flush()
	if os.path.exists(Name + ".bot"):
		file = open(Name + ".bot","r")
		systems = file.read()#.split()
		systems = systems.replace("\n", ", ")
		systems = systems.replace(" ", "")
		systems = systems.split(",")
		systems = systems[:-1]
		return systems 
	else:
		return False
