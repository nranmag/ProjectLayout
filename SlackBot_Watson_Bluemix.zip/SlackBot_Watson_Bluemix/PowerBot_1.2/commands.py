import sys
import os
import csv_data as cd
import df_ima as di 

#def mensaje(Slack, Channel, Text):
#	Slack.api_call("chat.postMessage", channel=Channel, text=Text, as_user=True)

#def Interpret_Command(ListComms1, ListComms2, ListComms3, ListComms4, ListComms5, List_Name, Systems, Output, Channel, Real_Name, Slack):
def Interpret_Command(Bot):
	"""
	Execute the commands from Watson
	"""
	print (Bot.Name + ": I'm interpreting commands")
	sys.stdout.flush()
	Intents = ["ESTATUS", "GENERAR", "SUMARIO"]
	#Detect the OS to use the correct command
	if sys.platform == "win32":
		Bot.Path = os.path.dirname(__file__)
		print (Bot.Name + ": I'm running on Windows")
		sys.stdout.flush()
	elif sys.platform == "linux":
		Bot.Path = os.path.dirname(os.path.realpath(__file__))
		print (Bot.Name + ": I'm running on Linux")
		sys.stdout.flush()
	elif sys.platform == "linux2":
		Bot.Path = os.path.dirname(os.path.realpath(__file__))
		print (Bot.Name + ": I'm running on IBM Cloud")
		sys.stdout.flush() 
	if len(Bot.Intent) > 0:
		#Status section
		if Bot.Intent[0].upper() == "ESTATUS":
			if len(Bot.Product) > 0:
				print (Bot.Name + ": I'm making a status")
				sys.stdout.flush()
				for i in Bot.Product:
					
					SQL = cd.Read_SQL("ESTATUS",i.upper(), "TEST", Bot)
					if i == 'LISTA' or i == 'CRITICAS': 
						if i == 'CRITICAS':
							Bot.Systems = Read_List("CRITICAS", Bot)
						else:
							Bot.List[0] = str(Bot.List[0])
							Bot.Systems = Read_List(Bot.List[0], Bot)
						SQL += " and physical.wumfgn in ("
						if Bot.Systems == False:
							bot.Message_to_Dad = "The list does not exist :disappointed:"
							break

						for x in Bot.Systems:
							SQL += "'" + x + "', "
						SQL = SQL[:-2]
						SQL += ")" 
					if i == 'SYSTEM':
						if len(Bot.Systems) > 0: 
							SQL += " and physical.wumfgn in ("
							for x in Bot.Systems:
								SQL += "'" + x + "', "
							SQL = SQL[:-2]
							SQL += ")"
					#print (SQL)
					
					df = cd.Data_DB2(SQL, Bot)
					df = cd.Add_VCC(df, Bot)
	
					if df.shape[0] > 0:
						if len(Bot.Format) > 0:
							Bot.File = i.upper() + "_Status"
							Bot.File_Text = "There you go " + Bot.Dad
							Bot.File_Title = "Status " + Bot.File 
							Create_File(df, Bot.File, Bot.Format[0], Bot.Path, Bot.File_Title , ['Status', 'MFG #', 'Test Cell'], [True, True, True], Bot)
					else:
						bot.Message_to_Dad = "The desired status does not contain any element :disappointed:"
		#List section
		elif Bot.Intent[0].upper() == "GENERAR":
			
			for i in Bot.Product:
				if i.upper() == "LISTA":
					print (Bot.Name + ": I'm making a list")
					sys.stdout.flush()
					#for x in Output:
					#	Slack.api_call("chat.postMessage", channel=Channel, text=x, as_user=True)
					if "CRITICAS" in Bot.Product:
						Create_List("CRITICAS", Bot.Systems, Bot)
					else:
						Create_List(Bot.List[0], Bot.Systems, Bot)
		#Summary section
		elif Bot.Intent[0].upper() == "SUMARIO":
			if len(Bot.Product) > 0:
				for i in Bot.Product:
					print (Bot.Name + ": I'm making a summary")
					sys.stdout.flush()
					SQL = cd.Read_SQL("SUMARIO",i.upper(), "TEST", Bot)
					if i == 'LISTA' or i == 'CRITICAS': 
						if i == 'CRITICAS':
							Bot.Systems = Read_List("CRITICAS", Bot)
						else:
							Bot.List[0] = str(Bot.List[0])
							Bot.Systems = Read_List(Bot.List[0], Bot)
						SQL += " and physical.wumfgn in ("
						if Bot.Systems == False:
							Slack.api_call("chat.postMessage", channel=Channel, text="The list does not exist :disappointed:", as_user=True)
							Bot.Message_to_Dad = "The list does not exist :disappointed:"
							break

						for x in Bot.Systems:
							SQL += "'" + x + "', "
						SQL = SQL[:-2]
						SQL += ")" 
					if i == 'SYSTEM':
						if len(Bot.Systems) > 0: 
							SQL += " and physical.wumfgn in ("
							for x in Bot.Systems:
								SQL += "'" + x + "', "
							SQL = SQL[:-2]
							SQL += ")"
					df = cd.Data_DB2(SQL, Bot)
					df = cd.Remove_Yorders(df)
					df = cd.Add_VCC(df, Bot)
					df = cd.Summary(df, Bot)
					if df.shape[0] > 0:
						if len(Bot.Format) > 0:
							Bot.File = i.upper() + "_Status"
							Bot.File_Text = "There you go " + Bot.Dad
							Bot.File_Title = "Status " + Bot.File 
							Create_Summary(df, Bot.File, Bot.Format[0], Bot.Path, Bot.File_Title, Bot)
					else:
						bot.Message_to_Dad = "The desired status does not contain any element :disappointed:"

					
		#elif Bot.Intent[0].upper() == "HELP":
		#	for x in Output:
		#		Slack.api_call("chat.postMessage", channel=Channel, text=x, as_user=True)
		#Default section	
		#elif (Bot.Intent[0].upper() not in Intents):
		#	for x in Output:
		#		Slack.api_call("chat.postMessage", channel=Channel, text=x, as_user=True)

def Create_File(df, Name, Ext, Path, Title, ColSort, OrdSort, Bot):
	"""
	Funtion to send a status file
	"""
	print (Bot.Name + ": I'm creating a file")
	sys.stdout.flush()
	di.Generate_Table(Name, df, Ext	, ColSort,OrdSort, Bot) 
	return True

def Create_Summary(df, Name, Ext, Path, Title, Bot):
	"""
	Funtion to send a summary file
	"""
	print (Bot.Name + ": I'm creating a summary")
	sys.stdout.flush()
	di.Generate_Table_Summary(df, Name, Ext, Bot)
	return True

def Send_Summary(Slack, Channel, df, Name, Ext, Path, Title, Text):
	"""
	Funtion to send a summary file
	"""
	print (Bot.Name + ": I'm creating a summary")
	sys.stdout.flush()
	di.Generate_Table_Summary(df, Name, Ext, threading)
	Slack.api_call('files.upload', channels=Channel, filename=Name + "." + Ext, file=open(Path + "/" + Name + "." + Ext, 'rb'), initial_comment = Text	, title= Title)
	return True

def Create_List(Name, Systems, Bot):
	"""
	Create a list with the interest systems
	"""
	#file = open(Name.encode("utf-8") + ".bot","w")
	print (Bot.Name + ": I'm creating a list")
	sys.stdout.flush()
	file = open(Name + ".bot","w") 
	[file.write(x+"\n") for x in Systems]
	file.close()
	return True

def Read_List(Name, Bot):
	"""
	Read a file list and return a list with the systems inside 
	"""
	print (Bot.Name + ": I'm reading a list")
	sys.stdout.flush()
	if os.path.exists(Name + ".bot"):
		file = open(Name + ".bot","r")
		systems = file.read()#.split()
		systems = systems.replace("\n", ", ")
		systems = systems.replace(" ", "")
		systems = systems.split(",")
		systems = systems[:-1]
		return systems 
	else:
		return False