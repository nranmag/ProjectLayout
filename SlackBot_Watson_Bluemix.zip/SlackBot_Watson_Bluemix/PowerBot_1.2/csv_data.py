import pandas as pd
import numpy as np

import ibm_db
import ibm_db_dbi

import requests
import urllib3
import io

import sys
import cf_misc

pd.options.mode.chained_assignment = None 
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

def Data_DB2(SQL, Bot):
	print (Bot.Name + ": I'm executing SQL string")
	sys.stdout.flush()
	dsn = cf_misc.get_credentials('QUALITY9')['dsn']
	conn = ibm_db.connect(dsn, '', '')
	conni = ibm_db_dbi.Connection(conn)
	df = pd.read_sql(SQL, conni)
	#df.to_csv("DB2.csv")
	#print (df)
	return df

def Read_SQL(Intent,Entity,Area, Bot):
	print (Bot.Name + ": I'm reading SQL string")
	sys.stdout.flush()
	df = pd.read_csv('Queries.csv',header=0)#, names = ['MFGN', 'Order', 'Model', 'MT', 'PRLN', 'Cell', 'Status', 'OP', 'STEP', 'PROGRAM', 'P', 'TC', 'CEC', 'Ship date', 'Country', 'tco', 'ettc', 'ettc date'])
	
	df = Filter_Data(df, ['INTENT', 'ENTITY', 'AREA'], [[Intent],[Entity],[Area]], Bot)
	df = df.sort_values('ID', ascending=True)
	SQL = ""
	for x in df['SQL']:
		SQL += x
	#print (SQL)
	return SQL

def Data_Vcc(Save):
	"""
	Get all the data from VCC web
	"""

	url = "https://cio-sg-02.integration.ibmcloud.com:15370/~vccuser/prod/csv/ettc_GDA.csv"
	#url = "https://rchdist.rch.stglabs.ibm.com/~vccuser/prod/csv/ettc_GDA.csv"

	html = requests.get(url, verify=False).content
	df_list = pd.read_csv(io.StringIO(html.decode('utf-8')), error_bad_lines=False, header=None, names = ['MFGN', 'Order', 'Model', 'MT', 'PRLN', 'Cell', 'Status', 'OP', 'STEP', 'PROGRAM', 'P', 'TC', 'CEC', 'Ship date', 'Country', 'tco', 'ettc', 'ettc date'])
	df = df_list[2:]
	
	if Save == True:
		df.to_csv('data_tool.csv')
	
	df.fillna("")
	return df

def Add_VCC (df, Bot):
	print (Bot.Name + ": I'm adding VCC data")
	sys.stdout.flush()
	
	df_vcc = Data_Vcc(False)
	
	MfgnL = []
	MfgnL = df_vcc[['MFGN','Order']]
	
	for index, i in MfgnL.iterrows():
		for j in df.index[(df['MFG #'] == i['MFGN']) & (df['Order'] == i['Order'])]:
			#if j 
			df['Preload'][j] = str(df_vcc.loc[df_vcc['MFGN'].isin([i['MFGN']]) & df_vcc['Order'].isin([i['Order']])]['P'].values)[2:-2]
			df['Status'][j] = str(df_vcc.loc[df_vcc['MFGN'].isin([i['MFGN']]) & df_vcc['Order'].isin([i['Order']])]['Status'].values)[2:-2]
			df['Step'][j] = str(df_vcc.loc[df_vcc['MFGN'].isin([i['MFGN']]) & df_vcc['Order'].isin([i['Order']])]['STEP'].values)[2:-2]
			df['TCO'][j] = str(df_vcc.loc[df_vcc['MFGN'].isin([i['MFGN']]) & df_vcc['Order'].isin([i['Order']])]['tco'].values)[2:-2]
			df['ETTC'][j] = str(df_vcc.loc[df_vcc['MFGN'].isin([i['MFGN']]) & df_vcc['Order'].isin([i['Order']])]['ettc date'].values)[2:-2]
			if df['ETTC'][j] == 'a':
				df['ETTC'][j] = ""
			
	return df

def Filter_Data(df, ColsF, ValsF, Bot):
	print (Bot.Name + ": I'm filtering the data")
	sys.stdout.flush()
	if len(ColsF) > 0:
		for x in range(len(ColsF)):
			df = df.loc[df[ColsF[x]].isin(ValsF[x])]
	sys.stdout.flush()
	return df 

def Remove_Yorders(df):
	df = df[df['Order'].str.startswith("Y")==False]
	return df

def Remove_IPRorders(df):
	df = df[df['Order'].str.startswith("$")==False]
	return df

def Summary(df, Bot):
	print (Bot.Name + ": I'm creating a summary data frame")
	sys.stdout.flush()
	df.drop_duplicates(subset=['MFG #'], keep='first', inplace=True)
	df = Status_Checker(df)
	df['Revenue'] = df['Revenue'].apply(lambda x: 0 if x == '' or x == 'NaN' or np.isnan(x) else x)
	df.fillna(0)
	df['Revenue'] = df['Revenue'].astype(int)
	df = Filter_Data(df, ['Status'], [['HOLD', 'REWORK', 'COMPLETED', 'RUNNING', "DOWN"]], Bot)
	df = df.groupby(['Status'])['Revenue', 'MFG #'].agg(['sum', 'count'])
	df = df.drop(columns=[('Revenue', 'count'), ('MFG #', 'sum')])

	df.columns = ['Revenue', 'Systems']

	basic_status = ['COMPLETED', 'DOWN', 'HOLD','REWORK','RUNNING', 'SUSPEND']#Tentativo

	for i in basic_status:
		if i not in df.index.values:
			df.loc[i] = [0,0]  

	total = df.apply(np.sum)
	df.loc['TOTAL'] = [total['Revenue'], total['Systems']]
	
	return df

def Status_Checker(df):
	X = 0
	Y = 0
	Width= []
	
	for i in df:
		for j in df[i]: 
			if i == 'Status':
				if j == 'QUAL_ENG':
					df[i][df.index[df[i] == j].tolist()] = 'HOLD'
				elif j == 'ABORT': 
					df[i][df.index[df[i] == j].tolist()] = 'REWORK'
				elif j == 'ATTENTION' or j == 'ATTN' or j == 'PASS':
					if df.iat[Y,X+1] == 'TVAL':
						df.iat[Y,X] = 'COMPLETED'
					else:
						df.iat[Y,X] = 'RUNNING'
				elif j == 'START' or j == 'PASS':
					df.iat[Y,X] = 'RUNNING'
				
			Y += 1
		Y = 0
		X += 1

	return df

#df = Data_Vcc(False)
#print (df)
#SQL=Read_SQL("ESTATUS","GENERAL")
#df = Data_DB2(SQL)

#df = Add_VCC(df, False)
#print (df)
#df.to_csv("DB2.csv")
"""
sql = "select distinct physical.wumfgn, physical.wuschd, physical.wuworn, geo, custname, ctry, rev, est, commit, firm, ettc, commentc, ormatp, ormmdl, orsysn, physical.wunmbr, physical.wuopst, physical.wutwrc, test.wucell, test.wunmbr, test.wuprln "
sql += "from qryq.MFSGWU10_GRC physical "
sql += "left join qryq.MFSGOR10_GRC on physical.wumfgn = ormfgn and physical.wuworn = ororno "
sql += "left join idmq.siidmtool_IDMOUT1970_urc on physical.wumfgn = mfgn and physical.wuworn = orno "
sql += "left join qryq.MFSGWU10_GRC test on physical.wumfgn = test.wumfgn and ororno = test.wuworn and test.wuwtyp = 'X' "
sql += "where physical.wuwtyp = 'R'"
sql += "and physical.wuidss in ('0000','IPRC') "
sql += "and physical.wunmbr = 'TEST' "
sql += "and orceci = 'Y' "
df = Data_DB2(sql)


print(df)
df.to_csv("DB2.csv")
"""